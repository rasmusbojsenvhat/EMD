
from flask import Flask, request, jsonify
from flask_cors import CORS
import pyvat
from datetime import datetime
import uuid
import threading
import psycopg2
from psycopg2 import pool
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# PostgreSQL connection string
DB_URL = "postgresql://postgres:hxsVRVqoVaKsfrgPJrcAsNZEpgOHqRqy@shortline.proxy.rlwy.net:38379/railway"

# Create a connection pool
try:
    connection_pool = psycopg2.pool.SimpleConnectionPool(1, 10, DB_URL)
    print("Database connection pool created successfully")

    # Initialize database tables if they don't exist
    conn = connection_pool.getconn()
    cursor = conn.cursor()
    
    # Create entity_meta_data table if it doesn't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS entity_meta_data (
        id VARCHAR(255) PRIMARY KEY,
        vat_no VARCHAR(50) NOT NULL,
        company_name TEXT NOT NULL,
        country_code VARCHAR(10) NOT NULL,
        timestamp TIMESTAMP NOT NULL,
        goods_services_manual TEXT,
        goods_services_prediction TEXT,
        taxability_manual TEXT,
        taxability_prediction TEXT,
        pot_indicator_manual TEXT,
        pot_indicator_prediction TEXT,
        likely_right_deduct_vat_manual TEXT,
        likely_right_deduct_vat_prediction TEXT,
        branch_code TEXT,
        vhat_person TEXT,
        unique_clients TEXT,
        note TEXT,
        pending_review BOOLEAN DEFAULT FALSE,
        sent_for_review BOOLEAN DEFAULT FALSE,
        sent_to_reviewer TEXT,
        last_sent_date TIMESTAMP,
        pushed BOOLEAN DEFAULT FALSE
    )
    ''')
    conn.commit()
    
    # Check if there are any records, if not insert some sample data
    cursor.execute("SELECT COUNT(*) FROM entity_meta_data")
    count = cursor.fetchone()[0]
    
    if count == 0:
        print("Inserting sample data into entity_meta_data table")
        sample_data = [
            ("1", "25942876", "BMW FINANCIAL SERVICES DENMARK A/S", "DK", datetime.now(), 
             "Both", "Services", "Taxable", "Taxable", "Main rule", "Transmission_Services", 
             "FullDeduction", "FullDeduction", None, None, "BMW Group", 
             "Updated based on the latest company information", True, False, None, None, False),
            
            ("2", "26092183", "DUSTIN A/S", "DK", datetime.now(), 
             None, "Goods", None, "Taxable", None, "Main rule", 
             None, "FullDeduction", None, None, "Dustin Group", 
             None, False, False, None, None, False),
            
            ("3", "37897817", "CE-IT ApS", "DK", datetime.now(), 
             "Services", "Services", "Taxable", "Taxable", "Transmission_Services", "Transmission_Services", 
             "EstimatePhone", "FullDeduction", None, None, "CE-IT", 
             "Updated deduction rights based on latest service agreement", False, False, None, None, False)
        ]
        
        cursor.executemany('''
        INSERT INTO entity_meta_data (
            id, vat_no, company_name, country_code, timestamp, 
            goods_services_manual, goods_services_prediction, taxability_manual, taxability_prediction, 
            pot_indicator_manual, pot_indicator_prediction, likely_right_deduct_vat_manual, 
            likely_right_deduct_vat_prediction, branch_code, vhat_person, unique_clients, 
            note, pending_review, sent_for_review, sent_to_reviewer, last_sent_date, pushed
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ''', sample_data)
        
        conn.commit()
    
    connection_pool.putconn(conn)
except Exception as e:
    print(f"Error connecting to database: {e}")
    connection_pool = None

# In-memory storage for batches created during runtime
RUNTIME_BATCHES = []

# Keep track of which batches are currently being processed
PROCESSING_BATCHES = {}

def process_batch(batch_id, entries):
    """
    Process a batch of VAT entries in a background thread
    """
    print(f"Starting background processing for batch {batch_id} with {len(entries)} entries")
    
    # Find the batch
    batch = None
    for b in RUNTIME_BATCHES:
        if b["id"] == batch_id:
            batch = b
            break
    
    if not batch:
        print(f"Error: Batch {batch_id} not found for processing")
        return
    
    # Process each entry
    processed_entries = []
    for entry in entries:
        try:
            vat_number = entry['vatNumber']
            country_code = vat_number[:2]
            number = vat_number[2:]
            
            print(f"Processing VAT number: {vat_number}")
            
            result = pyvat.check_vat_number(number, country_code)
            entry['status'] = 'Gyldigt momsnummer' if result.is_valid else 'Ikke gyldigt momsnummer'
            entry['companyName'] = result.business_name or 'N/A'
            entry['address'] = result.business_address or 'N/A'
            processed_entries.append(entry)
            
            print(f"Processed {vat_number}: {entry['status']}")
            
        except Exception as e:
            print(f"Error processing {vat_number}: {str(e)}")
            entry['status'] = 'Validering mislykkes'
            processed_entries.append(entry)
    
    # Update the batch with processed entries
    batch['entries'] = processed_entries
    batch['status'] = 'completed'
    
    # Remove from processing list
    if batch_id in PROCESSING_BATCHES:
        del PROCESSING_BATCHES[batch_id]
    
    print(f"Completed processing batch {batch_id}")

@app.route('/batches', methods=['GET'])
def get_batches():
    print("Fetching all batches...")  # Debug log
    # Return runtime-created batches
    return jsonify(RUNTIME_BATCHES)

@app.route('/batches/<batch_id>', methods=['GET'])
def get_batch_by_id(batch_id):
    print(f"Fetching batch with ID: {batch_id}")
    
    # Check runtime batches
    for batch in RUNTIME_BATCHES:
        if batch["id"] == batch_id:
            return jsonify(batch)
    
    return jsonify({"error": "Batch not found"}), 404

@app.route('/batches/<batch_id>', methods=['DELETE'])
def delete_batch(batch_id):
    print(f"Attempting to delete batch with ID: {batch_id}")
    
    # Try to find and remove from runtime batches
    for i, batch in enumerate(RUNTIME_BATCHES):
        if batch["id"] == batch_id:
            deleted_batch = RUNTIME_BATCHES.pop(i)
            print(f"Successfully deleted batch: {deleted_batch['name']}")
            return jsonify({"success": True, "message": f"Batch {deleted_batch['name']} deleted successfully"})
    
    return jsonify({"error": "Batch not found or cannot be deleted"}), 404

@app.route('/batches', methods=['POST'])
def create_batch():
    try:
        data = request.get_json()
        batch_name = data.get('name', f'Batch {datetime.now().strftime("%Y-%m-%d")}')
        period = data.get('period', datetime.now().strftime("%b %Y"))
        entries = data.get('entries', [])
        
        print(f"Creating new batch: {batch_name} with {len(entries)} entries")  # Debug log
        
        new_batch = {
            "id": str(uuid.uuid4()),
            "name": batch_name,
            "period": period,
            "entries": entries,
            "status": "processing"  # Initial status
        }
        
        # Add to runtime batches
        RUNTIME_BATCHES.append(new_batch)
        
        # Start processing in background thread
        PROCESSING_BATCHES[new_batch["id"]] = True
        thread = threading.Thread(target=process_batch, args=(new_batch["id"], entries))
        thread.daemon = True
        thread.start()
        
        print(f"Batch {batch_name} created and processing started in background")
        
        return jsonify({
            "success": True,
            "message": "Batch created and processing started",
            "data": new_batch
        }), 201
        
    except Exception as e:
        print(f"Error creating batch: {str(e)}")  # Error log
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500

@app.route('/batches/<batch_id>/entries', methods=['POST'])
def add_entry_to_batch(batch_id):
    try:
        data = request.get_json()
        print(f"Adding entry to batch {batch_id}: {data}")
        
        # Find the batch
        target_batch = None
        
        for batch in RUNTIME_BATCHES:
            if batch["id"] == batch_id:
                target_batch = batch
                break
        
        if not target_batch:
            return jsonify({"error": "Batch not found"}), 404
            
        # If it was a batch with no entries, initialize the entries list
        if 'entries' not in target_batch or not target_batch['entries']:
            target_batch['entries'] = []
            
        # Add entry ID if not present
        if 'id' not in data:
            data['id'] = str(uuid.uuid4())
            
        # Add request time if not present
        if 'requestTime' not in data:
            data['requestTime'] = datetime.now().isoformat()
            
        # Add the entry to the batch
        target_batch['entries'].append(data)
        
        return jsonify({
            "success": True,
            "message": "Entry added to batch successfully",
            "data": target_batch
        })
        
    except Exception as e:
        print(f"Error adding entry to batch: {str(e)}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500

@app.route('/batches/<batch_id>/retry', methods=['POST'])
def retry_batch_entries(batch_id):
    print(f"Retrying failed entries for batch: {batch_id}")
    
    # Find the batch
    target_batch = None
    for batch in RUNTIME_BATCHES:
        if batch["id"] == batch_id:
            target_batch = batch
            break
    
    if not target_batch:
        return jsonify({"error": "Batch not found"}), 404
    
    # Find entries with failed validation
    failed_entries = [e for e in target_batch["entries"] if e["status"] == "Validering mislykkes"]
    
    if not failed_entries:
        return jsonify({"message": "No failed entries to retry"}), 200
    
    # Mark batch as processing
    target_batch['status'] = 'processing'
    PROCESSING_BATCHES[batch_id] = True
    
    # Start processing in background thread
    thread = threading.Thread(target=process_batch, args=(batch_id, target_batch["entries"]))
    thread.daemon = True
    thread.start()
    
    print(f"Started retry process for batch {batch_id}")
    return jsonify({
        "success": True,
        "message": f"Retrying {len(failed_entries)} failed entries",
        "data": target_batch
    })

@app.route('/batches/status', methods=['GET'])
def get_batch_status():
    """Endpoint to get the processing status of all batches"""
    statuses = {
        batch_id: "processing" 
        for batch_id in PROCESSING_BATCHES.keys()
    }
    return jsonify(statuses)

@app.route('/vat-entries', methods=['GET'])
def get_vat_entries():
    batch_id = request.args.get('batchId')
    
    print(f"Fetching entries for batch: {batch_id}")  # Debug log
    
    # If a batch ID is provided, find entries for that batch
    if batch_id:
        for batch in RUNTIME_BATCHES:
            if batch["id"] == batch_id:
                return jsonify(batch["entries"])
                
        print(f"No entries found for batch: {batch_id}")  # Debug log
        return jsonify([])
    
    # If no batch ID is provided, return all entries
    all_entries = []
    for batch in RUNTIME_BATCHES:
        all_entries.extend(batch["entries"])
    
    return jsonify(all_entries)

@app.route('/validate-vat', methods=['POST'])
def validate_vat():
    try:
        data = request.get_json()
        vat_number = data.get('vatNumber')
        requestor_vat_id = data.get('requestorVatId')
        
        print(f"Validating VAT number: {vat_number}")
        
        if not vat_number or len(vat_number) < 3:
            return jsonify({
                "success": False,
                "message": "Invalid VAT number format",
                "data": {
                    "id": str(uuid.uuid4()),
                    "vatNumber": vat_number,
                    "companyName": "Invalid Format",
                    "address": "N/A",
                    "requestTime": datetime.now().isoformat(),
                    "status": "Ikke gyldigt momsnummer"
                }
            })
        
        try:
            country_code = vat_number[:2]
            number = vat_number[2:]
            
            result = pyvat.check_vat_number(number, country_code)
            
            if result.is_valid:
                return jsonify({
                    "success": True,
                    "message": "VAT number is valid",
                    "data": {
                        "id": str(uuid.uuid4()),
                        "vatNumber": vat_number,
                        "companyName": result.business_name or "Unknown",
                        "address": result.business_address or "Unknown",
                        "requestTime": datetime.now().isoformat(),
                        "status": "Gyldigt momsnummer"
                    }
                })
            else:
                return jsonify({
                    "success": False,
                    "message": "VAT number is not valid",
                    "data": {
                        "id": str(uuid.uuid4()),
                        "vatNumber": vat_number,
                        "companyName": "Invalid VAT",
                        "address": "N/A",
                        "requestTime": datetime.now().isoformat(),
                        "status": "Ikke gyldigt momsnummer"
                    }
                })
                
        except Exception as e:
            return jsonify({
                "success": False,
                "message": f"Error validating VAT number: {str(e)}",
                "data": {
                    "id": str(uuid.uuid4()),
                    "vatNumber": vat_number,
                    "companyName": "Validation Error",
                    "address": "N/A",
                    "requestTime": datetime.now().isoformat(),
                    "status": "Validering mislykkes"
                }
            })
            
    except Exception as e:
        print(f"Error in validate_vat endpoint: {str(e)}")
        return jsonify({
            "success": False,
            "message": str(e)
        }), 500

# New API endpoints for Entity Meta Database

@app.route('/api/entities', methods=['GET'])
def get_entities():
    """Get all entity meta data or filtered by search/parameters"""
    try:
        if connection_pool is None:
            return jsonify({"error": "Database connection not available"}), 500
            
        search_term = request.args.get('search')
        country_code = request.args.get('country')
        unique_clients = request.args.get('client')
        status = request.args.get('status')
        
        conn = connection_pool.getconn()
        cursor = conn.cursor()
        
        query = "SELECT * FROM entity_meta_data"
        conditions = []
        params = []
        
        if search_term:
            conditions.append("(vat_no ILIKE %s OR company_name ILIKE %s)")
            params.extend([f'%{search_term}%', f'%{search_term}%'])
            
        if country_code:
            conditions.append("country_code = %s")
            params.append(country_code)
            
        if unique_clients:
            conditions.append("unique_clients = %s")
            params.append(unique_clients)
            
        if status == 'pendingReview':
            conditions.append("pending_review = TRUE")
        
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
            
        cursor.execute(query, params)
        rows = cursor.fetchall()
        
        columns = [desc[0] for desc in cursor.description]
        entities = []
        
        for row in rows:
            entity = {}
            for i, col in enumerate(columns):
                # Convert column names from snake_case to camelCase for frontend
                if col == "pending_review":
                    entity["pendingReview"] = row[i]
                elif col == "sent_for_review":
                    entity["sentForReview"] = row[i]
                elif col == "sent_to_reviewer":
                    entity["sentToReviewer"] = row[i]
                elif col == "last_sent_date":
                    entity["lastSentDate"] = row[i].isoformat() if row[i] else None
                else:
                    entity[col] = row[i]
                    
                if isinstance(row[i], datetime):
                    entity[col] = row[i].isoformat()
            
            entities.append(entity)
            
        connection_pool.putconn(conn)
        return jsonify(entities)
        
    except Exception as e:
        print(f"Error fetching entities: {e}")
        try:
            connection_pool.putconn(conn)
        except:
            pass
        return jsonify({"error": str(e)}), 500

@app.route('/api/entities/<entity_id>', methods=['GET'])
def get_entity(entity_id):
    """Get a single entity by ID"""
    try:
        if connection_pool is None:
            return jsonify({"error": "Database connection not available"}), 500
            
        conn = connection_pool.getconn()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM entity_meta_data WHERE id = %s", (entity_id,))
        row = cursor.fetchone()
        
        if not row:
            connection_pool.putconn(conn)
            return jsonify({"error": "Entity not found"}), 404
            
        columns = [desc[0] for desc in cursor.description]
        entity = {}
        
        for i, col in enumerate(columns):
            if col == "pending_review":
                entity["pendingReview"] = row[i]
            elif col == "sent_for_review":
                entity["sentForReview"] = row[i]
            elif col == "sent_to_reviewer":
                entity["sentToReviewer"] = row[i]
            elif col == "last_sent_date":
                entity["lastSentDate"] = row[i].isoformat() if row[i] else None
            else:
                entity[col] = row[i]
                
            if isinstance(row[i], datetime):
                entity[col] = row[i].isoformat()
        
        connection_pool.putconn(conn)
        return jsonify(entity)
        
    except Exception as e:
        print(f"Error fetching entity: {e}")
        try:
            connection_pool.putconn(conn)
        except:
            pass
        return jsonify({"error": str(e)}), 500

@app.route('/api/entities/<entity_id>/field', methods=['POST'])
def update_entity_field(entity_id):
    """Update a specific field of an entity"""
    try:
        if connection_pool is None:
            return jsonify({"error": "Database connection not available"}), 500
            
        data = request.get_json()
        field = data.get('field')
        value = data.get('value')
        note = data.get('note', '')
        user = data.get('user', 'system')
        
        # Validate input
        if not field or value is None:
            return jsonify({"error": "Field and value are required"}), 400
            
        conn = connection_pool.getconn()
        cursor = conn.cursor()
        
        # Convert camelCase field names to snake_case for database
        db_field = field
        if field == "pendingReview":
            db_field = "pending_review"
        elif field == "sentForReview":
            db_field = "sent_for_review"
        elif field == "sentToReviewer":
            db_field = "sent_to_reviewer"
        elif field == "lastSentDate":
            db_field = "last_sent_date"
            
        # Update the field and the timestamp
        cursor.execute(
            f"UPDATE entity_meta_data SET {db_field} = %s, note = %s, timestamp = %s WHERE id = %s",
            (value, note, datetime.now(), entity_id)
        )
        
        if cursor.rowcount == 0:
            connection_pool.putconn(conn)
            return jsonify({"error": "Entity not found"}), 404
            
        conn.commit()
        connection_pool.putconn(conn)
        
        return jsonify({
            "success": True,
            "message": f"Updated {field} for entity {entity_id}",
            "data": {
                "entityId": entity_id,
                "field": field,
                "value": value,
                "note": note,
                "user": user,
                "timestamp": datetime.now().isoformat()
            }
        })
        
    except Exception as e:
        print(f"Error updating entity field: {e}")
        try:
            connection_pool.putconn(conn)
        except:
            pass
        return jsonify({"error": str(e)}), 500

@app.route('/api/entities/<entity_id>/reset', methods=['POST'])
def reset_entity_manual_values(entity_id):
    """Reset all manual values for an entity"""
    try:
        if connection_pool is None:
            return jsonify({"error": "Database connection not available"}), 500
            
        conn = connection_pool.getconn()
        cursor = conn.cursor()
        
        cursor.execute(
            """
            UPDATE entity_meta_data 
            SET goods_services_manual = NULL,
                taxability_manual = NULL,
                pot_indicator_manual = NULL,
                likely_right_deduct_vat_manual = NULL,
                timestamp = %s
            WHERE id = %s
            """,
            (datetime.now(), entity_id)
        )
        
        if cursor.rowcount == 0:
            connection_pool.putconn(conn)
            return jsonify({"error": "Entity not found"}), 404
            
        conn.commit()
        connection_pool.putconn(conn)
        
        return jsonify({
            "success": True,
            "message": f"Reset manual values for entity {entity_id}"
        })
        
    except Exception as e:
        print(f"Error resetting entity manual values: {e}")
        try:
            connection_pool.putconn(conn)
        except:
            pass
        return jsonify({"error": str(e)}), 500

@app.route('/api/entities/<entity_id>/changes', methods=['POST'])
def reset_entity_changes(entity_id):
    """Reset entity changes (set pendingReview to false)"""
    try:
        if connection_pool is None:
            return jsonify({"error": "Database connection not available"}), 500
            
        conn = connection_pool.getconn()
        cursor = conn.cursor()
        
        cursor.execute(
            "UPDATE entity_meta_data SET pending_review = FALSE, timestamp = %s WHERE id = %s",
            (datetime.now(), entity_id)
        )
        
        if cursor.rowcount == 0:
            connection_pool.putconn(conn)
            return jsonify({"error": "Entity not found"}), 404
            
        conn.commit()
        connection_pool.putconn(conn)
        
        return jsonify({
            "success": True,
            "message": f"Reset entity changes for entity {entity_id}"
        })
        
    except Exception as e:
        print(f"Error resetting entity changes: {e}")
        try:
            connection_pool.putconn(conn)
        except:
            pass
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    import os
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
