
import { format } from 'date-fns';
import type { Batch, VatEntry } from '@/types/vat';

export const useBatchExport = () => {
  // Format date for CSV export
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd/MM/yyyy HH:mm");
    } catch (error) {
      return dateString;
    }
  };

  const exportBatchToCsv = (batch: Batch) => {
    if (batch && batch.entries.length > 0) {
      const link = document.createElement("a");
      
      // Format the data for CSV
      const csvData = [
        // Header row
        ["Momsnummer", "Virksomhedsnavn", "Adresse", "Tid for forespørgsel", "Status", "Request ID"],
        // Data rows
        ...batch.entries.map((entry: VatEntry) => [
          entry.vatNumber,
          entry.companyName,
          entry.address,
          formatDate(entry.requestTime),
          entry.status,
          entry.requestId || ""
        ])
      ];

      // Convert to CSV string
      const csvContent = csvData
        .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
        .join("\n");

      // Create a blob and download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      
      // Current timestamp for the filename
      const timestamp = format(new Date(), "yyyy-MM-dd_HH-mm");
      const batchInfo = batch.name ? `-${batch.name.replace(/\s/g, '_')}` : '';
      
      link.setAttribute("href", url);
      link.setAttribute("download", `vat-data${batchInfo}-${timestamp}.csv`);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return { exportBatchToCsv };
};
