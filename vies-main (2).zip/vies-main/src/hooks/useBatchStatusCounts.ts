
import type { VatEntry } from '@/types/vat';

export interface StatusCounts {
  valid: number;
  invalid: number;
  failed: number;
  total: number;
}

export const useBatchStatusCounts = (entries: VatEntry[] = []): StatusCounts => {
  const counts = {
    valid: entries.filter(e => e.status.includes("Gyldigt momsnummer")).length,
    invalid: entries.filter(e => e.status.includes("Ikke gyldigt momsnummer")).length,
    failed: entries.filter(e => e.status.includes("Validering mislykkes")).length,
    total: entries.length
  };
  
  return counts;
};
