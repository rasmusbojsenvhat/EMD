import { VatEntry, VatValidationResponse, mockVatEntries, mockCompanyInfo, Batch } from '../types/vat';
import { loadVatEntriesFromCsv } from '../utils/csvLoader';

// Determine the API URL based on the current environment
const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
// Use the public URL from Railway for production
const PRODUCTION_API_URL = 'https://vies-python.up.railway.app'; 
const API_URL = isLocalhost ? 'http://localhost:5000' : PRODUCTION_API_URL;
const USE_MOCK_DATA = false; // We're using the real backend API

// Initialize local storage for validation history if it doesn't exist
const initValidationHistory = () => {
  if (!localStorage.getItem('vatValidationHistory')) {
    localStorage.setItem('vatValidationHistory', JSON.stringify([]));
  }
};

// Add a validation attempt to the history
const addToValidationHistory = (entry: VatEntry) => {
  initValidationHistory();
  const history = JSON.parse(localStorage.getItem('vatValidationHistory') || '[]');
  history.unshift(entry); // Add to the beginning of the array
  
  // Keep only the last 100 entries to prevent localStorage from growing too large
  const trimmedHistory = history.slice(0, 100);
  localStorage.setItem('vatValidationHistory', JSON.stringify(trimmedHistory));
};

// Store loaded batches in memory
let loadedEntries: VatEntry[] | null = null;
let loadedBatches: Batch[] = [];

export const vatApi = {
  // Get current company information (the requestor)
  getCompanyInfo() {
    if (USE_MOCK_DATA) {
      return mockCompanyInfo;
    }
    
    // In a real implementation, this would fetch from backend
    // return await fetch(`${API_URL}/company-info`).then(res => res.json());
    return mockCompanyInfo;
  },
  
  // Fetch available batches
  async fetchBatches(): Promise<Batch[]> {
    if (USE_MOCK_DATA) {
      console.log('Using mock data for batches');
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 500));
      return loadedBatches;
    }
    
    try {
      const response = await fetch(`${API_URL}/batches`);
      if (!response.ok) {
        throw new Error(`Failed to fetch batches: ${response.status}`);
      }
      const backendBatches = await response.json();
      
      // Combine backend batches with any locally created batches
      const allBatches = [...loadedBatches, ...backendBatches];
      return allBatches;
    } catch (error) {
      console.error('Error fetching batches:', error);
      return loadedBatches;
    }
  },
  
  // Fetch a single batch by ID
  async fetchBatchById(batchId: string): Promise<Batch | null> {
    if (USE_MOCK_DATA) {
      console.log('Using mock data for batch details');
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Find batch in local batches
      const localBatch = loadedBatches.find(b => b.id === batchId);
      if (localBatch) return localBatch;
      
      return null;
    }
    
    try {
      // First check locally created batches
      const localBatch = loadedBatches.find(b => b.id === batchId);
      if (localBatch) return localBatch;
      
      // Then check backend
      const response = await fetch(`${API_URL}/batches/${batchId}`);
      if (!response.ok) {
        if (response.status === 404) {
          return null;
        }
        throw new Error(`Failed to fetch batch: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error fetching batch details:', error);
      return null;
    }
  },
  
  // Delete a batch by ID
  async deleteBatch(batchId: string): Promise<boolean> {
    if (USE_MOCK_DATA) {
      console.log('Using mock data for batch deletion');
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Remove from local batches if found
      const index = loadedBatches.findIndex(b => b.id === batchId);
      if (index !== -1) {
        loadedBatches.splice(index, 1);
        return true;
      }
      
      return false;
    }
    
    try {
      // First check if it's a local batch
      const localIndex = loadedBatches.findIndex(b => b.id === batchId);
      if (localIndex !== -1) {
        loadedBatches.splice(localIndex, 1);
        return true;
      }
      
      // Otherwise delete from backend
      const response = await fetch(`${API_URL}/batches/${batchId}`, {
        method: 'DELETE'
      });
      
      if (!response.ok) {
        throw new Error(`Failed to delete batch: ${response.status}`);
      }
      
      return true;
    } catch (error) {
      console.error('Error deleting batch:', error);
      return false;
    }
  },
  
  // Retry failed entries in a batch
  async retryFailedEntries(batchId: string): Promise<Batch | null> {
    if (USE_MOCK_DATA) {
      console.log('Using mock data for retry failed entries');
      await new Promise(resolve => setTimeout(resolve, 800));
      
      return null; // Not implemented for mock data
    }
    
    try {
      const response = await fetch(`${API_URL}/batches/${batchId}/retry`, {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error(`Failed to retry entries: ${response.status}`);
      }
      
      const result = await response.json();
      return result.data;
    } catch (error) {
      console.error('Error retrying failed entries:', error);
      return null;
    }
  },
  
  // Fetch VAT entries for a specific batch
  async fetchVatEntriesForBatch(batchId?: string): Promise<VatEntry[]> {
    if (USE_MOCK_DATA) {
      console.log('Using mock or CSV data for VAT entries', batchId ? `for batch ${batchId}` : '');
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network delay
      
      // Get validation history from localStorage
      const history = JSON.parse(localStorage.getItem('vatValidationHistory') || '[]');
      
      // If we have a local batch with this ID, use its entries
      const localBatch = loadedBatches.find(b => b.id === batchId);
      if (localBatch) {
        return localBatch.entries;
      }
      
      return history;
    }

    try {
      // Check for locally created batches first
      const localBatch = loadedBatches.find(b => b.id === batchId);
      if (localBatch) {
        return localBatch.entries;
      }
      
      // Otherwise fetch from backend
      const url = batchId 
        ? `${API_URL}/vat-entries?batchId=${batchId}`
        : `${API_URL}/vat-entries`;
        
      console.log('Fetching VAT entries from:', url);
      const response = await fetch(url);
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Server responded with:', response.status, errorText);
        throw new Error(`Failed to fetch VAT entries: ${response.status} ${errorText}`);
      }
      const data = await response.json();
      console.log('Received VAT entries:', data);
      return data;
    } catch (error) {
      console.error('Error fetching VAT entries:', error);
      return [];
    }
  },

  // Alias for backward compatibility
  async fetchVatEntries(): Promise<VatEntry[]> {
    return this.fetchVatEntriesForBatch();
  },

  async validateVatNumber(vatNumber: string, requestorVatId?: string): Promise<VatValidationResponse> {
    if (USE_MOCK_DATA) {
      console.log('Using mock validation for:', vatNumber, 'Requestor:', requestorVatId);
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      let response: VatValidationResponse;
      
      // Simple mock validation logic
      if (vatNumber.startsWith('DK') || vatNumber.startsWith('SE') || vatNumber.startsWith('FI')) {
        response = {
          success: true,
          message: 'VAT number is valid',
          data: {
            id: Date.now().toString(),
            vatNumber,
            companyName: `${vatNumber.slice(0, 2)} Test Company`,
            address: `Test Address, ${vatNumber.slice(0, 2)}`,
            requestTime: new Date().toISOString(),
            status: 'Gyldigt momsnummer'
          }
        };
      } else if (vatNumber.includes('FAIL')) {
        response = {
          success: false,
          message: 'Validation service failed',
          data: {
            id: Date.now().toString(),
            vatNumber,
            companyName: 'Failed Validation',
            address: 'N/A',
            requestTime: new Date().toISOString(),
            status: 'Validering mislykkes'
          }
        };
      } else if (!vatNumber.match(/^[A-Z]{2}\d+$/)) {
        response = {
          success: false,
          message: 'Not an EU VAT number',
          data: {
            id: Date.now().toString(),
            vatNumber,
            companyName: 'Invalid VAT',
            address: 'N/A',
            requestTime: new Date().toISOString(),
            status: 'Ikke et EU-momsnummer'
          }
        };
      } else {
        response = {
          success: false,
          message: 'VAT number is not valid',
          data: {
            id: Date.now().toString(),
            vatNumber,
            companyName: 'Invalid VAT',
            address: 'N/A',
            requestTime: new Date().toISOString(),
            status: 'Ikke gyldigt momsnummer'
          }
        };
      }
      
      // Add to validation history
      if (response.data) {
        addToValidationHistory(response.data);
      }
      
      return response;
    }

    try {
      const response = await fetch(`${API_URL}/validate-vat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          vatNumber,
          requestorVatId 
        }),
      });
      
      if (!response.ok) {
        throw new Error(`VAT validation failed: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Add to validation history
      if (data.data) {
        addToValidationHistory(data.data);
      }
      
      return data;
    } catch (error) {
      console.error('Error validating VAT number:', error);
      const errorResponse = {
        success: false,
        message: 'Kunne ikke validere momsnummer. Tjek venligst din internetforbindelse.',
        data: {
          id: Date.now().toString(),
          vatNumber,
          companyName: 'Validation Error',
          address: 'N/A',
          requestTime: new Date().toISOString(),
          status: 'Validering mislykkes'
        }
      };
      
      // Add to validation history
      if (errorResponse.data) {
        addToValidationHistory(errorResponse.data);
      }
      
      return errorResponse;
    }
  },

  // Get validation history from localStorage
  getValidationHistory(): VatEntry[] {
    initValidationHistory();
    return JSON.parse(localStorage.getItem('vatValidationHistory') || '[]');
  },

  // Clear validation history
  clearValidationHistory(): void {
    localStorage.setItem('vatValidationHistory', JSON.stringify([]));
  },
  
  // Preview CSV file to get count without processing
  async previewCsvFile(file: File): Promise<VatEntry[]> {
    try {
      console.log("[previewCsvFile] Starting CSV preview");
      const entries = await loadVatEntriesFromCsv(file);
      console.log("[previewCsvFile] Loaded entries:", entries.length);
      return entries;
    } catch (error) {
      console.error('[previewCsvFile] Error previewing CSV:', error);
      throw error;
    }
  },

  // Load entries from CSV and create a new batch
  async loadEntriesFromCsv(file: File, batchName: string = ""): Promise<boolean> {
    try {
      console.log("[loadEntriesFromCsv] Loading CSV file", file.name);
      const entries = await loadVatEntriesFromCsv(file);
      console.log("[loadEntriesFromCsv] Parsed", entries.length, "entries from CSV");
      
      if (entries.length > 0) {
        if (USE_MOCK_DATA) {
          // Create a local batch for mock mode
          const newBatch: Batch = {
            id: `local-${Date.now()}`,
            name: batchName || `Batch ${new Date().toLocaleDateString()}`,
            period: `${new Date().toLocaleDateString()} - ${new Date().toLocaleDateString()}`,
            entries: entries,
            status: 'processing'
          };
          
          // Add the batch to our local collection
          loadedBatches.unshift(newBatch);
          
          return true;
        } else {
          // Send to backend API
          console.log(`[loadEntriesFromCsv] Creating new batch on backend with ${entries.length} entries, API URL: ${API_URL}`);
          
          try {
            const response = await fetch(`${API_URL}/batches`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                name: batchName || `Batch ${new Date().toLocaleDateString()}`,
                period: `${new Date().toLocaleDateString()} - ${new Date().toLocaleDateString()}`,
                entries: entries
              }),
            });
            
            console.log("[loadEntriesFromCsv] Response status:", response.status);
            
            if (!response.ok) {
              const errorText = await response.text();
              console.error('[loadEntriesFromCsv] Server error:', response.status, errorText);
              throw new Error(`Failed to create batch: ${response.status} ${errorText}`);
            }
            
            const result = await response.json();
            console.log('[loadEntriesFromCsv] Batch created successfully:', result);
            
            return result.success || true; // Assume success if no explicit success field
          } catch (networkError) {
            console.error('[loadEntriesFromCsv] Network error:', networkError);
            throw networkError;
          }
        }
      }
      return false;
    } catch (error) {
      console.error('[loadEntriesFromCsv] Error loading CSV:', error);
      return false;
    }
  },
  
  // Add entry to batch
  async addEntryToBatch(batchId: string, entry: VatEntry): Promise<boolean> {
    if (USE_MOCK_DATA) {
      console.log('Using mock data for adding entry to batch:', batchId);
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Add to local batch if found
      const localBatchIndex = loadedBatches.findIndex(b => b.id === batchId);
      if (localBatchIndex !== -1) {
        loadedBatches[localBatchIndex].entries.push(entry);
        return true;
      }
      
      return false;
    }
    
    try {
      // First check if it's a local batch
      const localBatchIndex = loadedBatches.findIndex(b => b.id === batchId);
      if (localBatchIndex !== -1) {
        loadedBatches[localBatchIndex].entries.push(entry);
        return true;
      }
      
      // Otherwise add to backend
      const response = await fetch(`${API_URL}/batches/${batchId}/entries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(entry),
      });
      
      if (!response.ok) {
        throw new Error(`Failed to add entry to batch: ${response.status}`);
      }
      
      return true;
    } catch (error) {
      console.error('Error adding entry to batch:', error);
      return false;
    }
  }
};
