
import { EntityMetaData } from "@/types/emd";

// Determine the API URL based on the current environment
const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
// Use the public URL from Railway for production
const PRODUCTION_API_URL = 'https://vies-python.up.railway.app'; 
const API_URL = isLocalhost ? 'http://localhost:5000' : PRODUCTION_API_URL;

// Flag to use mock data instead of real API - set to true by default
const USE_MOCK_DATA = true; 

// Mock entity data for development and testing
const mockEntities: EntityMetaData[] = [
  {
    id: "30248104",
    vat_no: "30248104",
    company_name: "DANSK SPLITLEASING A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "Both",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: null,
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "LeasingVehicles",
    likely_right_deduct_vat_prediction: null,
    branch_code: "649100",
    vhat_person: "Rasmus",
    unique_clients: null,
    note: null,
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "27906486",
    vat_no: "27906486",
    company_name: "FLEXLEAS ApS",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "Both",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: null,
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "LeasingVehicles",
    likely_right_deduct_vat_prediction: null,
    branch_code: "649100",
    vhat_person: "Rasmus",
    unique_clients: null,
    note: null,
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "25942876",
    vat_no: "25942876",
    company_name: "BMW FINANCIAL SERVICES DENMARK A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "Both",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: null,
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "LeasingVehicles",
    likely_right_deduct_vat_prediction: null,
    branch_code: "649230",
    vhat_person: "Rasmus",
    unique_clients: "2",
    note: null,
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "40861246",
    vat_no: "40861246",
    company_name: "Volkswagen Semler Finans Danmark A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "Both",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: null,
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "LeasingVehicles",
    likely_right_deduct_vat_prediction: null,
    branch_code: "649230",
    vhat_person: "Rasmus",
    unique_clients: "2",
    note: null,
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "26092183",
    vat_no: "26092183",
    company_name: "DUSTIN A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "Local_RC",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "465000",
    vhat_person: "Rasmus",
    unique_clients: "5",
    note: "Har både RC og ikke RC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "28511345",
    vat_no: "28511345",
    company_name: "Lenovo (Danmark) ApS",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "Local_RC",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "465000",
    vhat_person: "Rasmus",
    unique_clients: "2",
    note: "Har både RC og ikke RC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "26686091",
    vat_no: "26686091",
    company_name: "DCS ApS",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "Local_RC",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "465000",
    vhat_person: "Rasmus",
    unique_clients: "4",
    note: "Har både RC og ikke RC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "37897817",
    vat_no: "37897817",
    company_name: "CE-IT ApS",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "Local_RC",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "629000",
    vhat_person: "Rasmus",
    unique_clients: "3",
    note: "Har både RC og ikke RC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "18759136",
    vat_no: "18759136",
    company_name: "Foxway A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "Local_RC",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "465000",
    vhat_person: "Rasmus",
    unique_clients: "2",
    note: "Har både RC og ikke RC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "25511484",
    vat_no: "25511484",
    company_name: "Atea A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "Local_RC",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "465000",
    vhat_person: "Rasmus",
    unique_clients: "7",
    note: "Har både RC og ikke RC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "25380088",
    vat_no: "25380088",
    company_name: "POWER A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "475400",
    vhat_person: "Rasmus",
    unique_clients: "11",
    note: "Har ikke LRC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "17237977",
    vat_no: "17237977",
    company_name: "Elgiganten A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "475400",
    vhat_person: "Rasmus",
    unique_clients: "9",
    note: "Har ikke LRC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "18966239",
    vat_no: "18966239",
    company_name: "Proshop A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "475400",
    vhat_person: "Rasmus",
    unique_clients: "4",
    note: "Har ikke LRC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "20366532",
    vat_no: "20366532",
    company_name: "CS-Online A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "475400",
    vhat_person: "Rasmus",
    unique_clients: "2",
    note: "Har ikke LRC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "30583442",
    vat_no: "30583442",
    company_name: "ADMIRE ApS",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "G",
    goods_services_prediction: null,
    taxability_manual: "Local_RC",
    taxability_prediction: null,
    pot_indicator_manual: "Main rule",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "EstimatePhone",
    likely_right_deduct_vat_prediction: null,
    branch_code: "629000",
    vhat_person: "Rasmus",
    unique_clients: "15",
    note: "Har både RC og ikke RC",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "19055108",
    vat_no: "19055108",
    company_name: "APCOA DANMARK A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "S",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: "Real_estate",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "CarRelatedExpenses",
    likely_right_deduct_vat_prediction: null,
    branch_code: "522120",
    vhat_person: "Rasmus",
    unique_clients: "7",
    note: "Parkering",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  },
  {
    id: "26454484",
    vat_no: "26454484",
    company_name: "EASY PARK A/S",
    country_code: "DK",
    timestamp: new Date().toISOString(),
    goods_services_manual: "S",
    goods_services_prediction: null,
    taxability_manual: "T",
    taxability_prediction: null,
    pot_indicator_manual: "Real_estate",
    pot_indicator_prediction: null,
    likely_right_deduct_vat_manual: "CarRelatedExpenses",
    likely_right_deduct_vat_prediction: null,
    branch_code: "619000",
    vhat_person: "Rasmus",
    unique_clients: "9",
    note: "Parkering",
    pendingReview: false,
    sentForReview: false,
    sentToReviewer: null,
    lastSentDate: null,
    pushed: false
  }
];

// Helper to determine if a request was successful
const checkResponse = async (response: Response) => {
  if (!response.ok) {
    const errorText = await response.text();
    console.error(`API Error (${response.status}): ${errorText}`);
    throw new Error(`API request failed with status ${response.status}: ${errorText}`);
  }
  return response.json();
};

// Helper to simulate network latency for mock data
const simulateNetworkDelay = async (ms = 500) => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

// Helper to filter mock entities based on params
const filterMockEntities = (entities: EntityMetaData[], searchTerm?: string, filters?: any[]): EntityMetaData[] => {
  if (!searchTerm && (!filters || filters.length === 0)) return [...entities];
  
  return entities.filter(entity => {
    // Apply search term filtering
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchesVatNo = entity.vat_no.toLowerCase().includes(term);
      const matchesCompanyName = entity.company_name.toLowerCase().includes(term);
      if (!matchesVatNo && !matchesCompanyName) return false;
    }
    
    // Apply advanced filters if any
    if (filters && filters.length > 0) {
      return filters.every(filter => {
        const fieldValue = entity[filter.field as keyof EntityMetaData];
        
        if (fieldValue === null || fieldValue === undefined) return false;
        
        switch (filter.operator) {
          case "equals":
            return fieldValue === filter.value;
          case "contains":
            return String(fieldValue).toLowerCase().includes(String(filter.value).toLowerCase());
          case "startsWith":
            return String(fieldValue).toLowerCase().startsWith(String(filter.value).toLowerCase());
          case "endsWith":
            return String(fieldValue).toLowerCase().endsWith(String(filter.value).toLowerCase());
          default:
            return true;
        }
      });
    }
    
    return true;
  });
};

// PostgreSQL connection string placeholder for future activation
const POSTGRES_CONNECTION_STRING = "postgresql://postgres:hxsVRVqoVaKsfrgPJrcAsNZEpgOHqRqy@shortline.proxy.rlwy.net:38379/railway";

export const emdApi = {
  // Gets the configured API URL for logging/debugging
  getApiUrl() {
    return API_URL;
  },
  
  // Function to toggle mock data on/off - placeholder for future use
  toggleMockData(useMock: boolean) {
    // This is just a placeholder for now - in a real implementation
    // we would modify the USE_MOCK_DATA flag dynamically
    console.log(`Mock data ${useMock ? 'enabled' : 'disabled'}`);
    return useMock;
  },
  
  // Function to test PostgreSQL connection - placeholder for future use
  async testPostgresConnection() {
    if (USE_MOCK_DATA) {
      await simulateNetworkDelay(1000);
      console.log("PostgreSQL connection test skipped in mock mode");
      return {
        success: true,
        message: "Mock mode active - no actual database connection"
      };
    }
    
    try {
      console.log(`Testing PostgreSQL connection to: ${POSTGRES_CONNECTION_STRING.substring(0, 20)}...`);
      const response = await fetch(`${API_URL}/api/test-postgres-connection`);
      return await checkResponse(response);
    } catch (error) {
      console.error("PostgreSQL connection test failed:", error);
      return {
        success: false,
        message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  },
  
  // Fetch all entities or filtered by parameters
  async fetchEntities(params?: Record<string, string>): Promise<EntityMetaData[]> {
    if (USE_MOCK_DATA) {
      console.log("Using mock data for entities");
      await simulateNetworkDelay(800); // Simulate network delay
      
      // Filter mock entities based on params
      let filteredEntities = [...mockEntities];
      if (params) {
        filteredEntities = filterMockEntities(mockEntities, params['search'], undefined);
      }
      
      console.log(`Fetched ${filteredEntities.length} mock entities`);
      return filteredEntities;
    }
    
    try {
      console.log(`Fetching entities from API: ${API_URL}/api/entities`);
      
      const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
      const response = await fetch(`${API_URL}/api/entities${queryString}`);
      
      console.log(`Response status: ${response.status}`);
      const entities = await checkResponse(response);
      
      console.log(`Fetched ${entities.length} entities from API`);
      if (entities.length > 0) {
        console.log('Sample entity:', entities[0]);
      }
      
      return entities;
    } catch (error) {
      console.error('Error fetching entities:', error);
      throw error;
    }
  },
  
  // Fetch entities with filters
  async fetchFilteredEntities(searchTerm?: string, filters?: any[]): Promise<EntityMetaData[]> {
    if (USE_MOCK_DATA) {
      console.log(`Using mock data for filtered entities, search term: ${searchTerm}, filters: ${JSON.stringify(filters)}`);
      await simulateNetworkDelay(600);
      
      const filteredEntities = filterMockEntities(mockEntities, searchTerm, filters);
      
      console.log(`Fetched ${filteredEntities.length} filtered mock entities`);
      return filteredEntities;
    }
    
    try {
      console.log(`Fetching filtered entities from API`);
      
      // Construct query parameters
      const params = new URLSearchParams();
      if (searchTerm) params.append('search', searchTerm);
      if (filters && filters.length > 0) {
        params.append('filters', JSON.stringify(filters));
      }
      
      const url = `${API_URL}/api/entities?${params.toString()}`;
      console.log(`Request URL: ${url}`);
      
      const response = await fetch(url);
      console.log(`Response status: ${response.status}`);
      
      const entities = await checkResponse(response);
      console.log(`Fetched ${entities.length} filtered entities from API`);
      
      return entities;
    } catch (error) {
      console.error(`Error fetching filtered entities:`, error);
      throw error;
    }
  },
  
  // Fetch a single entity by ID
  async fetchEntityById(id: string): Promise<EntityMetaData> {
    if (USE_MOCK_DATA) {
      console.log(`Using mock data for entity with ID: ${id}`);
      await simulateNetworkDelay(300);
      
      const entity = mockEntities.find(e => e.id === id);
      if (!entity) {
        throw new Error(`Entity with ID ${id} not found in mock data`);
      }
      
      return entity;
    }
    
    try {
      console.log(`Fetching entity with ID: ${id}`);
      const response = await fetch(`${API_URL}/api/entities/${id}`);
      return await checkResponse(response);
    } catch (error) {
      console.error(`Error fetching entity ${id}:`, error);
      throw error;
    }
  },
  
  // Update a specific field of an entity
  async updateEntityField(
    entityId: string, 
    field: keyof EntityMetaData, 
    value: any, 
    note: string = "", 
    user: string = "system"
  ): Promise<any> {
    if (USE_MOCK_DATA) {
      console.log(`Using mock data to update field ${field} for entity ${entityId}`);
      await simulateNetworkDelay(400);
      
      // Find the entity in our mock data
      const entityIndex = mockEntities.findIndex(e => e.id === entityId);
      if (entityIndex === -1) {
        throw new Error(`Entity with ID ${entityId} not found in mock data`);
      }
      
      // Update the entity's field
      mockEntities[entityIndex] = {
        ...mockEntities[entityIndex],
        [field]: value,
        note: note || mockEntities[entityIndex].note,
        timestamp: new Date().toISOString()
      };
      
      return {
        success: true,
        message: `Updated ${field} for entity ${entityId}`,
        data: {
          entityId,
          field,
          value,
          note,
          user,
          timestamp: new Date().toISOString()
        }
      };
    }
    
    try {
      console.log(`Updating field ${field} for entity ${entityId} to ${value}`);
      const response = await fetch(`${API_URL}/api/entities/${entityId}/field`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          field,
          value,
          note,
          user
        }),
      });
      return await checkResponse(response);
    } catch (error) {
      console.error(`Error updating entity ${entityId} field ${field}:`, error);
      throw error;
    }
  },
  
  // Reset all manual values for an entity
  async resetEntityManualValues(entityId: string): Promise<any> {
    if (USE_MOCK_DATA) {
      console.log(`Using mock data to reset manual values for entity ${entityId}`);
      await simulateNetworkDelay(300);
      
      // Find the entity in our mock data
      const entityIndex = mockEntities.findIndex(e => e.id === entityId);
      if (entityIndex === -1) {
        throw new Error(`Entity with ID ${entityId} not found in mock data`);
      }
      
      // Reset manual values
      mockEntities[entityIndex] = {
        ...mockEntities[entityIndex],
        goods_services_manual: null,
        taxability_manual: null,
        pot_indicator_manual: null,
        likely_right_deduct_vat_manual: null,
        timestamp: new Date().toISOString()
      };
      
      return {
        success: true,
        message: `Reset manual values for entity ${entityId}`
      };
    }
    
    try {
      console.log(`Resetting manual values for entity ${entityId}`);
      const response = await fetch(`${API_URL}/api/entities/${entityId}/reset`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return await checkResponse(response);
    } catch (error) {
      console.error(`Error resetting entity ${entityId} manual values:`, error);
      throw error;
    }
  },
  
  // Reset entity changes (set pendingReview to false)
  async resetEntityChanges(entityId: string): Promise<any> {
    if (USE_MOCK_DATA) {
      console.log(`Using mock data to reset changes for entity ${entityId}`);
      await simulateNetworkDelay(300);
      
      // Find the entity in our mock data
      const entityIndex = mockEntities.findIndex(e => e.id === entityId);
      if (entityIndex === -1) {
        throw new Error(`Entity with ID ${entityId} not found in mock data`);
      }
      
      // Reset pending review status
      mockEntities[entityIndex] = {
        ...mockEntities[entityIndex],
        pendingReview: false,
        timestamp: new Date().toISOString()
      };
      
      return {
        success: true,
        message: `Reset entity changes for entity ${entityId}`
      };
    }
    
    try {
      console.log(`Resetting changes for entity ${entityId}`);
      const response = await fetch(`${API_URL}/api/entities/${entityId}/changes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return await checkResponse(response);
    } catch (error) {
      console.error(`Error resetting entity ${entityId} changes:`, error);
      throw error;
    }
  },
  
  // Mock function for loading entities from CSV (used by EMDCsvLoader)
  async loadEntitiesFromCsv(file: File): Promise<EntityMetaData[] | boolean> {
    if (USE_MOCK_DATA) {
      console.log(`Using mock data to load entities from CSV: ${file.name}`);
      await simulateNetworkDelay(1500);
      
      // Simulate adding new mock entities
      const newEntities: EntityMetaData[] = [
        {
          id: `new-${Date.now()}-1`,
          vat_no: "98765432",
          company_name: "CSV Import Company 1",
          country_code: "DK",
          timestamp: new Date().toISOString(),
          goods_services_manual: null,
          goods_services_prediction: "Goods",
          taxability_manual: null,
          taxability_prediction: "Taxable",
          pot_indicator_manual: null,
          pot_indicator_prediction: "Main rule",
          likely_right_deduct_vat_manual: null,
          likely_right_deduct_vat_prediction: "FullDeduction",
          branch_code: null,
          vhat_person: null,
          unique_clients: "CSV Import",
          note: `Imported from ${file.name}`,
          pendingReview: false,
          sentForReview: false,
          sentToReviewer: null,
          lastSentDate: null,
          pushed: false
        },
        {
          id: `new-${Date.now()}-2`,
          vat_no: "87654321",
          company_name: "CSV Import Company 2",
          country_code: "DK",
          timestamp: new Date().toISOString(),
          goods_services_manual: null,
          goods_services_prediction: "Services",
          taxability_manual: null,
          taxability_prediction: "Taxable",
          pot_indicator_manual: null,
          pot_indicator_prediction: "Electronic_Services",
          likely_right_deduct_vat_manual: null,
          likely_right_deduct_vat_prediction: "PartialDeduction",
          branch_code: null,
          vhat_person: null,
          unique_clients: "CSV Import",
          note: `Imported from ${file.name}`,
          pendingReview: false,
          sentForReview: false,
          sentToReviewer: null,
          lastSentDate: null,
          pushed: false
        }
      ];
      
      // Add the new entities to our mock data
      mockEntities.push(...newEntities);
      
      return newEntities;
    }
    
    // If not using mock data, this function would need to be implemented
    // to call the real API endpoint for CSV import
    console.error("CSV import is only available in mock mode");
    return false;
  },
  
  // Mock function for exporting entities to CSV
  async exportEntitiesToCsv(entities: EntityMetaData[]): Promise<string> {
    console.log(`Exporting ${entities.length} entities to CSV`);
    
    // Create CSV content
    const headers = [
      "ID", "VAT Number", "Company Name", "Country", "Goods/Services",
      "Taxability", "POT Indicator", "Deduction Rights", "Client", "Notes"
    ];
    
    const rows = entities.map(entity => [
      entity.id,
      entity.vat_no,
      entity.company_name,
      entity.country_code,
      entity.goods_services_manual || entity.goods_services_prediction || "",
      entity.taxability_manual || entity.taxability_prediction || "",
      entity.pot_indicator_manual || entity.pot_indicator_prediction || "",
      entity.likely_right_deduct_vat_manual || entity.likely_right_deduct_vat_prediction || "",
      entity.unique_clients || "",
      entity.note || ""
    ]);
    
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
    ].join("\n");
    
    return csvContent;
  }
};
