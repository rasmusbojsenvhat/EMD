
// Types for the Entity Meta Database

export type GoodsServicesType = 'Goods' | 'Services' | 'Both' | string;

export type TaxabilityType = 
  'T' | 
  'Ex_no_credit' | 
  'Ex_w_credit' | 
  'Local_RC' | 
  'UsedGoods' | 
  string;

export type POTIndicatorType = 
  'Teleservice' |
  'Broadcasting' |
  'Copyrights_etc' |
  'Advertisement' |
  'Consultants' |
  'Engineers' |
  'Accountants' |
  'Lawyers' |
  'Data_processing' |
  'Providing_information' |
  'Financial_Services' |
  'Staff_hire' |
  'Leasing_movable_property_no_means_of_transport' |
  'Transmission_Services' |
  'Real_Estate' |
  'Passenger_Transport' |
  'Access_to_Events' |
  'Restaurant_Catering' |
  'Short_term_rent_means_of_transport' |
  'Intermediary' |
  'Goods_transport' |
  'valuation, reparation  of movable property' |
  'AccesstoEvents, i.e. activitites connected to events, also as facilitator etc' |
  'long term rent not leisure_means_of_transport' |
  'long term rent leisure_means_of_transport' |
  'Electronic Services' |
  'Activities connected to transport' |
  'New_Means_of_Transport' |
  'Manual' |
  'Main rule' |
  'OSS' |
  string;

export type LikelyDeductType = 
  'LeasingVehicles' | 
  'Restaurant' | 
  'MealsForStaff' | 
  'EstimatePhone' | 
  'EstimateEntertainment' |
  'FixedPhoneLine' | 
  'CarRelatedExpenses' | 
  'NoDeductionEntertainment' | 
  'BusinessOrPrivateUse' |
  'FullDeduction' | 
  'NoDeductionExempt' | 
  'NoDeductionFringeBenefits' | 
  'NoDeductionGifts' |
  string;

export interface EntityMetaData {
  id: string;
  vat_no: string;
  company_name: string;
  country_code: string;
  timestamp: string;
  goods_services_manual?: string;
  goods_services_prediction?: string;
  taxability_manual?: string;
  taxability_prediction?: string;
  pot_indicator_manual?: string;
  pot_indicator_prediction?: string;
  likely_right_deduct_vat_manual?: string;
  likely_right_deduct_vat_prediction?: string;
  branch_code?: string;
  vhat_person?: string;
  unique_clients?: string;
  note?: string;
  pendingReview?: boolean;
  sentForReview?: boolean;
  sentToReviewer?: string;
  lastSentDate?: string;
  pushed?: boolean;
}

export interface EntityReviewItem {
  entityId: string;
  vat_no: string;
  company_name: string;
  changes: {
    field: string;
    oldValue: string | null;
    newValue: string | null;
  }[];
  vhat_person: string;
  note: string;
  timestamp: string;
  batchId?: string;
  status?: "pending" | "approved" | "rejected" | "pushed";
  feedbackNote?: string;
}

export type SortConfigEMD = {
  key: keyof EntityMetaData;
  direction: 'ascending' | 'descending';
};

export interface FilterOption {
  id: string;
  label: string;
  field: keyof EntityMetaData;
}
