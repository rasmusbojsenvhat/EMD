
export interface VatEntry {
  id: string;
  vatNumber: string;
  companyName: string;
  address: string;
  requestTime: string;
  status: string;
  requestId?: string; // Adding requestId field as optional since existing data might not have it
}

export interface VatValidationResponse {
  success: boolean;
  message: string;
  data?: VatEntry;
}

export interface SortConfig {
  key: keyof VatEntry;
  direction: 'ascending' | 'descending';
}

export interface Batch {
  id: string;
  name: string;
  period: string;
  entries: VatEntry[];
  status?: 'ready' | 'processing' | 'completed'; // Adding status property as optional
}

// Mock data to use until backend is connected
export const mockVatEntries: VatEntry[] = [
  {
    id: "1",
    vatNumber: "DK12345678",
    companyName: "Danish Company A/S",
    address: "Hovedgaden 1, 2800 Kongens Lyngby, Denmark",
    requestTime: new Date().toISOString(),
    status: "Gyldigt momsnummer"
  },
  {
    id: "2",
    vatNumber: "SE123456789101",
    companyName: "Swedish Company AB",
    address: "Storgatan 1, 11464 Stockholm, Sweden",
    requestTime: new Date(Date.now() - 86400000).toISOString(),
    status: "Gyldigt momsnummer"
  },
  {
    id: "3",
    vatNumber: "INVALID123",
    companyName: "Invalid VAT",
    address: "N/A",
    requestTime: new Date(Date.now() - 172800000).toISOString(),
    status: "Ikke gyldigt momsnummer"
  },
  {
    id: "4",
    vatNumber: "NOTEU123",
    companyName: "Invalid VAT",
    address: "N/A",
    requestTime: new Date(Date.now() - 259200000).toISOString(),
    status: "Ikke et EU-momsnummer"
  },
  {
    id: "5",
    vatNumber: "FI12345678",
    companyName: "Failed Validation",
    address: "N/A",
    requestTime: new Date(Date.now() - 345600000).toISOString(),
    status: "Validering mislykkes"
  }
];

// Mock company/requestor information
export const mockCompanyInfo = {
  name: "Din Virksomhed A/S",
  vatId: "DK87654321"
};
