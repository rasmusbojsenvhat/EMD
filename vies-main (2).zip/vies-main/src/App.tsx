
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import './App.css'
import { Toaster } from "@/components/ui/toaster"
import VatValidation from './pages/VatValidation'
import BatchDetails from './pages/BatchDetails'
import VatHistory from './pages/VatHistory'
import NotFound from './pages/NotFound'
import AdminPanel from './pages/AdminPanel'
import ReviewPanel from './pages/ReviewPanel'
import EntityMetaDatabasePage from './pages/EntityMetaDatabasePage'
import PreEntityMetaDatabasePage from './pages/PreEntityMetaDatabasePage'
import PasswordProtection from './components/auth/PasswordProtection'

function App() {
  return (
    <PasswordProtection>
      <Router>
        <Routes>
          <Route path="/" element={<Navigate to="/validation" replace />} />
          <Route path="/validation" element={<VatValidation />} />
          <Route path="/batch/:batchId" element={<BatchDetails />} />
          <Route path="/history" element={<VatHistory />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/admin/emd" element={<EntityMetaDatabasePage />} />
          <Route path="/admin/emd/pre" element={<PreEntityMetaDatabasePage />} />
          <Route path="/admin/review" element={<ReviewPanel />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Toaster />
      </Router>
    </PasswordProtection>
  )
}

export default App
