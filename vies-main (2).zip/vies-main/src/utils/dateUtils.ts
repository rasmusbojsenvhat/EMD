
import { format } from "date-fns";

/**
 * Returns the current date formatted as DD.MM.YYYY
 */
export const getCurrentFormattedDate = (): string => {
  return format(new Date(), "dd.MM.yyyy");
};

/**
 * Formats a date string into a readable format
 */
export const formatDate = (dateString: string | undefined): string => {
  if (!dateString) return "-";
  
  try {
    const date = new Date(dateString);
    return format(date, "dd MMM yyyy, HH:mm");
  } catch (e) {
    return dateString;
  }
};

/**
 * Formats a date string into a short format (dd/MM/yyyy)
 */
export const formatShortDate = (dateString: string | undefined): string => {
  if (!dateString) return "-";
  
  try {
    const date = new Date(dateString);
    return format(date, "dd/MM/yyyy");
  } catch (e) {
    return dateString;
  }
};
