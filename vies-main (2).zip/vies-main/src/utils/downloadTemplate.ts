
/**
 * Creates and downloads a CSV template file for VAT validation
 * The template includes headers and optional example data
 */
export const downloadTemplate = () => {
  // Define the CSV headers and an optional example row
  const csvData = [
    // Headers for the CSV template
    ["vatNumber", "companyName", "address"],
    // Example data row (optional)
    ["DK12345678", "Example Company A/S", "Example Street 123, 1234 City, Denmark"]
  ];

  // Convert to CSV format
  const csvContent = csvData
    .map(row => row.join(","))
    .join("\n");

  // Create a Blob and generate a download link
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  
  // Set filename and attributes
  link.setAttribute("href", url);
  link.setAttribute("download", "vat-validation-template.csv");
  link.style.visibility = "hidden";
  
  // Trigger download and cleanup
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
