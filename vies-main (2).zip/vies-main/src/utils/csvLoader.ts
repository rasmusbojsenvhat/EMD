
import { VatEntry } from "@/types/vat";

export const loadVatEntriesFromCsv = async (file: File): Promise<VatEntry[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (event) => {
      try {
        const csv = event.target?.result as string;
        const lines = csv.split('\n');
        
        // Skip header row and parse data
        const entries = lines.slice(1).map((line, index) => {
          const [countryCode, vatId] = line
            .split(',')
            .map(field => field.trim().replace(/^"|"$/g, '')); // Remove quotes
          
          // Combine country code and VAT ID to form the full VAT number
          const vatNumber = countryCode && vatId ? `${countryCode}${vatId}` : '';
          
          return {
            id: String(index + 1),
            vatNumber,
            companyName: '', // These fields will be populated after validation
            address: '',
            requestTime: new Date().toISOString(),
            status: '',
            requestId: String(Date.now()) + index
          };
        }).filter(entry => entry.vatNumber); // Filter out empty rows
        
        resolve(entries);
      } catch (error) {
        reject(new Error('Failed to parse CSV file'));
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read CSV file'));
    };
    
    reader.readAsText(file);
  });
};
