
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Play } from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { vatApi } from '@/services/vatApi';
import VatHistoryList from '@/components/vat-history/VatHistoryList';
import { useToast } from '@/hooks/use-toast';

const VatHistory = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const { data: batches = [], isLoading } = useQuery({
    queryKey: ['batches'],
    queryFn: vatApi.fetchBatches,
    refetchInterval: 5000, // Auto-refresh every 5 seconds
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await queryClient.invalidateQueries({ queryKey: ['batches'] });
      toast({
        title: "Opdateret",
        description: "Status er blevet opdateret",
      });
    } catch (error) {
      toast({
        title: "Fejl",
        description: "Kunne ikke opdatere status",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-semibold">Historiske og igangværende</h1>
          <Button
            variant="brand"
            onClick={() => navigate('/validation')}
            className="flex items-center gap-2"
          >
            <Play className="h-4 w-4" />
            Start ny VIES tjek
          </Button>
        </div>
        
        {isLoading ? (
          <div className="bg-white rounded-lg p-8 text-center">
            <p className="text-gray-500">Indlæser batches...</p>
          </div>
        ) : (
          <VatHistoryList 
            batches={batches} 
            isRefreshing={isRefreshing}
            onRefresh={handleRefresh}
          />
        )}
      </div>
    </MainLayout>
  );
};

export default VatHistory;
