
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import VatTable from '@/components/dashboard/VatTable';
import MainLayout from '@/components/layout/MainLayout';
import { vatApi } from '@/services/vatApi';
import { useBatchExport } from '@/hooks/useBatchExport';
import { useBatchStatusCounts } from '@/hooks/useBatchStatusCounts';
import BatchHeader from '@/components/batch/BatchHeader';
import BatchInfo from '@/components/batch/BatchInfo';
import DeleteBatchDialog from '@/components/batch/DeleteBatchDialog';
import LoadingState from '@/components/batch/LoadingState';
import ErrorState from '@/components/batch/ErrorState';
import type { SortConfig, VatEntry } from '@/types/vat';

const BatchDetails = () => {
  const { batchId } = useParams<{ batchId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { exportBatchToCsv } = useBatchExport();
  const [sortConfig, setSortConfig] = useState<SortConfig | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Get batch details
  const { 
    data: batch, 
    isLoading: isLoadingBatch,
    error: batchError,
    refetch: refetchBatch
  } = useQuery({
    queryKey: ['batch', batchId],
    queryFn: () => vatApi.fetchBatchById(batchId || ''),
    enabled: !!batchId,
    refetchInterval: () => isProcessing ? 3000 : false,
    meta: {
      onError: (err: Error) => {
        toast({
          title: "Error",
          description: `Failed to load batch details: ${err.message}`,
          variant: "destructive",
        });
      }
    }
  });

  // Update isProcessing state whenever batch data changes
  useEffect(() => {
    if (batch) {
      setIsProcessing(batch.status === 'processing');
    }
  }, [batch]);

  // Mutation for retrying failed entries
  const retryMutation = useMutation({
    mutationFn: () => vatApi.retryFailedEntries(batchId || ''),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['batch', batchId] });
      toast({
        title: "Success",
        description: "Failed entries have been retried",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to retry entries: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Mutation for deleting batch
  const deleteMutation = useMutation({
    mutationFn: () => vatApi.deleteBatch(batchId || ''),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['batches'] });
      toast({
        title: "Success",
        description: "Batch has been deleted",
      });
      navigate('/');
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete batch: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Show notification when processing completes
  useEffect(() => {
    let previousStatus = batch?.status;
    
    if (previousStatus === 'processing' && batch?.status === 'completed') {
      toast({
        title: "Behandling fuldført",
        description: "Momsnumre er blevet valideret",
      });
    }
    
    previousStatus = batch?.status;
  }, [batch?.status, toast]);

  const handleRetryFailed = () => {
    retryMutation.mutate();
  };

  const handleDeleteBatch = () => {
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    deleteMutation.mutate();
    setShowDeleteDialog(false);
  };

  const handleExport = () => {
    if (batch) {
      exportBatchToCsv(batch);
    }
  };

  const handleRefresh = () => {
    refetchBatch();
    toast({
      title: "Opdateret",
      description: "Batch status er blevet opdateret",
    });
  };

  // Handle sorting
  const requestSort = (key: keyof VatEntry) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    
    if (sortConfig?.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    
    setSortConfig({ key, direction });
  };

  // Loading state
  if (isLoadingBatch) {
    return (
      <MainLayout>
        <LoadingState />
      </MainLayout>
    );
  }

  // Error state
  if (batchError || !batch) {
    return (
      <MainLayout>
        <ErrorState />
      </MainLayout>
    );
  }

  // Calculate status counts
  const statusCounts = useBatchStatusCounts(batch.entries);
  const hasFailed = statusCounts.failed > 0;
  
  // Get sorted entries
  const sortedEntries = batch?.entries ? [...batch.entries].sort((a, b) => {
    if (!sortConfig) return 0;
    
    if (a[sortConfig.key] < b[sortConfig.key]) {
      return sortConfig.direction === 'ascending' ? -1 : 1;
    }
    if (a[sortConfig.key] > b[sortConfig.key]) {
      return sortConfig.direction === 'ascending' ? 1 : -1;
    }
    return 0;
  }) : [];

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <BatchHeader 
          onExport={handleExport}
          onDeleteBatch={handleDeleteBatch}
          onRetryFailed={handleRetryFailed}
          onRefresh={handleRefresh}
          hasFailed={hasFailed}
          isProcessing={isProcessing}
          retryPending={retryMutation.isPending}
        />

        <BatchInfo 
          batch={batch} 
          statusCounts={statusCounts}
          hasFailed={hasFailed}
        />

        <VatTable 
          entries={sortedEntries} 
          sortConfig={sortConfig} 
          onSort={requestSort} 
        />
      </div>

      <DeleteBatchDialog
        isOpen={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        onConfirm={confirmDelete}
        batch={batch}
        totalEntries={statusCounts.total}
      />
    </MainLayout>
  );
};

export default BatchDetails;
