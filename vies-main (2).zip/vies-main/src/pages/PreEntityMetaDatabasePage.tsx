import React, { useState, useEffect } from "react";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Plus, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import EntityMetaNavigation from "@/components/admin/EntityMetaNavigation";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { 
  GoodsServicesType, 
  TaxabilityType, 
  POTIndicatorType, 
  LikelyDeductType,
  EntityMetaData
} from "@/types/emd";
import { emdApi } from "@/services/emdApi";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

type CompanyFormData = {
  vat_no: string;
  company_name: string;
  country_code: string;
  goods_services_manual: GoodsServicesType;
  taxability_manual: TaxabilityType;
  pot_indicator_manual: POTIndicatorType;
  likely_right_deduct_vat_manual: LikelyDeductType;
  vhat_person: string;
}

const PreEntityMetaDatabasePage: React.FC = () => {
  const navigate = useNavigate();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [pendingCompanies, setPendingCompanies] = useState<EntityMetaData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const form = useForm<CompanyFormData>({
    defaultValues: {
      vat_no: "",
      company_name: "",
      country_code: "",
      goods_services_manual: "",
      taxability_manual: "",
      pot_indicator_manual: "",
      likely_right_deduct_vat_manual: "",
      vhat_person: "",
    }
  });

  useEffect(() => {
    const fetchPendingCompanies = async () => {
      try {
        setIsLoading(true);
        const entities = await emdApi.fetchFilteredEntities();
        const pendingEntities = entities.filter(e => e.pendingReview);
        setPendingCompanies(pendingEntities);
      } catch (error) {
        console.error("Error fetching pending companies:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPendingCompanies();
  }, []);

  const onSubmit = (data: CompanyFormData) => {
    console.log("Form submitted:", data);
    
    const newCompany: EntityMetaData = {
      id: `temp-${Date.now()}`,
      vat_no: data.vat_no,
      company_name: data.company_name,
      country_code: data.country_code,
      timestamp: new Date().toISOString(),
      goods_services_manual: data.goods_services_manual,
      taxability_manual: data.taxability_manual,
      pot_indicator_manual: data.pot_indicator_manual,
      likely_right_deduct_vat_manual: data.likely_right_deduct_vat_manual,
      vhat_person: data.vhat_person,
      pendingReview: true,
      sentForReview: false
    };
    
    setPendingCompanies([...pendingCompanies, newCompany]);
    
    toast.success("Company added successfully and pending review");
    
    setIsDialogOpen(false);
    form.reset();
  };
  
  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-start mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/admin')} 
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Go to Admin Panel
          </Button>
        </div>
        
        <EntityMetaNavigation />
        
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">New entities</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="blue" className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Add Company Manual
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Add Company Manually</DialogTitle>
                  <DialogDescription>
                    Enter company details to add to the Pre-Entity Meta Database.
                  </DialogDescription>
                </DialogHeader>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="vat_no"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>VAT Number</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. 25942876" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="country_code"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country Code</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. DK" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="company_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Company name" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="goods_services_manual"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Goods/Services</FormLabel>
                            <FormControl>
                              <Input placeholder="Goods, Services, Both" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="taxability_manual"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Taxability</FormLabel>
                            <FormControl>
                              <Input placeholder="T, Ex_no_credit, Local_RC..." {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="pot_indicator_manual"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>POT Indicator</FormLabel>
                            <FormControl>
                              <Input placeholder="Main Rule, Teleservice..." {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="likely_right_deduct_vat_manual"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Likely Right to Deduct</FormLabel>
                            <FormControl>
                              <Input placeholder="FullDeduction, LeasingVehicles..." {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="vhat_person"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>VhAT Person</FormLabel>
                          <FormControl>
                            <Input placeholder="Person responsible" {...field} />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <DialogFooter>
                      <Button type="submit" variant="blue">Add Company</Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          <Alert className="mb-6" variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Under Construction</AlertTitle>
            <AlertDescription>
              This feature is currently under development. Basic functionality is available 
              but some features may not work as expected.
            </AlertDescription>
          </Alert>

          <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
            <p className="text-sm text-gray-500 mb-4">
              The Pre-Entity Meta Database allows you to manually add companies before they are validated 
              and added to the main Entity Meta Database.
            </p>
            
            {isLoading ? (
              <div className="flex justify-center p-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
              </div>
            ) : pendingCompanies.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="py-2 px-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">VAT No</th>
                      <th className="py-2 px-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company Name</th>
                      <th className="py-2 px-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Country</th>
                      <th className="py-2 px-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">VhAT Person</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {pendingCompanies.map((company) => (
                      <tr key={company.id} className="hover:bg-gray-50">
                        <td className="py-2 px-3 text-sm text-gray-500">{company.vat_no}</td>
                        <td className="py-2 px-3 text-sm">{company.company_name}</td>
                        <td className="py-2 px-3 text-sm text-gray-500">{company.country_code}</td>
                        <td className="py-2 px-3 text-sm text-gray-500">{company.vhat_person}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-4 border border-dashed border-gray-300 rounded-lg text-center">
                <p className="text-gray-400">No companies have been added yet.</p>
                <p className="text-gray-400 text-sm mt-2">Use the "Add Company Manual" button to get started.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default PreEntityMetaDatabasePage;
