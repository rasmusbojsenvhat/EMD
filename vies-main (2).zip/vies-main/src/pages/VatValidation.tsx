import React, { useState, useMemo, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import MainLayout from "@/components/layout/MainLayout";
import StatisticsCard from "@/components/dashboard/StatisticsCard";
import FilterBar from "@/components/dashboard/FilterBar";
import VatTable from "@/components/dashboard/VatTable";
import VatValidationForm from "@/components/dashboard/VatValidationForm";
import TabNavigation, { TabValue } from "@/components/dashboard/TabNavigation";
import SearchBar from "@/components/dashboard/SearchBar";
import ExportButton from "@/components/dashboard/ExportButton";
import CsvLoader from '@/components/dashboard/CsvLoader';
import { vatApi } from "@/services/vatApi";
import type { VatEntry, SortConfig } from "@/types/vat";
import { Button } from "@/components/ui/button";
import { Download, RefreshCw } from "lucide-react";
import { downloadTemplate } from "@/utils/downloadTemplate";

// Import component-specific styles
import "@/components/dashboard/styles/VatTable.css";
import "@/components/dashboard/styles/FilterBar.css";
import "@/components/dashboard/styles/SearchBar.css";
import "@/components/dashboard/styles/ExportButton.css";
import "@/components/dashboard/styles/TabNavigation.css";

const VatValidation = () => {
  const [activeTab, setActiveTab] = useState<TabValue>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortConfig, setSortConfig] = useState<SortConfig | null>(null);
  const [selectedBatchId, setSelectedBatchId] = useState<string>("");
  const [isRetrying, setIsRetrying] = useState(false);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch available batches
  const { 
    data: batches = [], 
    isLoading: isLoadingBatches 
  } = useQuery({
    queryKey: ['batches'],
    queryFn: vatApi.fetchBatches,
    meta: {
      onError: (err: Error) => {
        toast({
          title: "Error",
          description: `Failed to load batches: ${err.message}`,
          variant: "destructive",
        });
      }
    }
  });

  // Set the default batch ID once batches are loaded
  useEffect(() => {
    if (batches.length > 0 && !selectedBatchId) {
      setSelectedBatchId(batches[0].id);
    }
  }, [batches, selectedBatchId]);

  // Get the current batch object
  const currentBatch = useMemo(() => {
    return batches.find(batch => batch.id === selectedBatchId) || batches[0] || {
      id: "0",
      name: "Ingen batch",
      period: "Ingen perioder tilgængelige",
      entries: []
    };
  }, [batches, selectedBatchId]);

  // Fetch VAT entries for the selected batch
  const { 
    data: vatEntries = [], 
    isLoading: isLoadingEntries,
    error
  } = useQuery({
    queryKey: ['vat-entries', selectedBatchId],
    queryFn: () => vatApi.fetchVatEntriesForBatch(selectedBatchId),
    enabled: !!selectedBatchId,
    meta: {
      onError: (err: Error) => {
        toast({
          title: "Error",
          description: `Failed to load VAT entries: ${err.message}`,
          variant: "destructive",
        });
      }
    }
  });

  const isLoading = isLoadingBatches || isLoadingEntries;

  // Handle batch change
  const handleBatchChange = (batchId: string) => {
    setSelectedBatchId(batchId);
  };

  // Handle sorting
  const requestSort = (key: keyof VatEntry) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    
    if (sortConfig?.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    
    setSortConfig({ key, direction });
  };

  // Apply filtering, searching and sorting
  const processedEntries = useMemo(() => {
    // First filter by tab
    let result = vatEntries.filter((entry: VatEntry) => {
      if (activeTab === "all") {
        return true;
      } else if (activeTab === "validated") {
        return entry.status.includes("Gyldigt momsnummer");
      } else if (activeTab === "not-validated") {
        return entry.status.includes("Ikke gyldigt momsnummer");
      } else if (activeTab === "validation-failed") {
        return entry.status.includes("Validering mislykkes");
      }
      return true;
    });

    // Then apply search
    if (searchTerm) {
      const lowerCaseSearchTerm = searchTerm.toLowerCase();
      result = result.filter(
        (entry) =>
          entry.vatNumber.toLowerCase().includes(lowerCaseSearchTerm) ||
          entry.companyName.toLowerCase().includes(lowerCaseSearchTerm) ||
          entry.address.toLowerCase().includes(lowerCaseSearchTerm) ||
          entry.status.toLowerCase().includes(lowerCaseSearchTerm)
      );
    }

    // Finally sort
    if (sortConfig) {
      result.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }

    return result;
  }, [vatEntries, activeTab, searchTerm, sortConfig]);

  // Calculate tab counts
  const tabCounts = useMemo(() => {
    const validatedCount = vatEntries.filter(entry => entry.status.includes("Gyldigt momsnummer")).length;
    const notValidatedCount = vatEntries.filter(entry => entry.status.includes("Ikke gyldigt momsnummer")).length;
    const validationFailedCount = vatEntries.filter(entry => entry.status.includes("Validering mislykkes")).length;
    const readyForPushCount = 0; // This would depend on your business logic

    return {
      all: vatEntries.length,
      validated: validatedCount,
      notValidated: notValidatedCount,
      validationFailed: validationFailedCount,
      readyForPush: readyForPushCount
    };
  }, [vatEntries]);

  // Handle retrying failed validations
  const handleRetryFailed = async () => {
    if (!selectedBatchId) return;
    
    setIsRetrying(true);
    try {
      await vatApi.retryFailedEntries(selectedBatchId);
      queryClient.invalidateQueries({ queryKey: ['vat-entries', selectedBatchId] });
      toast({
        title: "Succes",
        description: "Genkørsel af fejlede valideringer startet",
      });
    } catch (error) {
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved genkørsel af valideringer",
        variant: "destructive",
      });
    } finally {
      setIsRetrying(false);
    }
  };

  // Count failed and invalid validations
  const failedValidationsCount = vatEntries.filter(
    entry => entry.status.includes("Validering mislykkes") || entry.status.includes("Ikke gyldigt momsnummer")
  ).length;

  return (
    <MainLayout>
      <StatisticsCard entries={vatEntries} />
      <VatValidationForm />
      
      <div className="flex justify-between items-center mb-4">
        <FilterBar 
          currentBatch={currentBatch}
          batches={batches}
          onBatchChange={handleBatchChange}
        />
        <div className="flex gap-2">
          {failedValidationsCount > 0 && (
            <Button
              variant="outline"
              onClick={handleRetryFailed}
              disabled={isRetrying}
              className="flex items-center gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isRetrying ? 'animate-spin' : ''}`} />
              Forsøg kørsel igen
            </Button>
          )}
          <Button
            variant="outline"
            onClick={downloadTemplate}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Download CSV skabelon
          </Button>
          <CsvLoader />
          <ExportButton 
            entries={processedEntries} 
            batchName={currentBatch.name}
          />
        </div>
      </div>
      
      <SearchBar searchTerm={searchTerm} onSearchChange={setSearchTerm} />
      <TabNavigation 
        activeTab={activeTab} 
        onTabChange={setActiveTab} 
        counts={tabCounts}
      />
      
      {isLoading ? (
        <div className="flex justify-center py-10">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-500"></div>
        </div>
      ) : error ? (
        <div className="p-8 text-center text-red-500 bg-red-50 rounded-lg">
          <p>Der opstod en fejl under indlæsning af data.</p>
          <p className="text-sm mt-2">Prøv at genindlæse siden, eller kontakt support hvis problemet fortsætter.</p>
        </div>
      ) : (
        <VatTable 
          entries={processedEntries} 
          sortConfig={sortConfig} 
          onSort={requestSort}
          currentBatchId={selectedBatchId}
        />
      )}
    </MainLayout>
  );
};

export default VatValidation;
