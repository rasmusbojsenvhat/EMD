import React, { useState, useEffect } from "react";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarIcon, Check, CheckCircle, X, ArrowLeft, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { getCurrentFormattedDate, formatDate } from "@/utils/dateUtils";

interface EntityReviewItem {
  id: string;
  batchId: string;
  batchName: string;
  entityId: string;
  vatNo: string;
  companyName: string;
  fieldName: string;
  oldValue: string;
  newValue: string;
  note: string;
  reviewer: string | null;
  reviewerNote: string | null;
  status: "pending" | "approved" | "rejected" | "ready-for-push";
  createdAt: string;
  updatedAt: string;
}

interface BatchInfo {
  id: string;
  name: string;
}

const generateMockBatches = () => {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  const lastWeek = new Date(today);
  lastWeek.setDate(lastWeek.getDate() - 7);
  
  return [
    { id: "batch1", name: format(today, "dd.MM.yyyy") },
    { id: "batch2", name: format(yesterday, "dd.MM.yyyy") },
    { id: "batch3", name: format(lastWeek, "dd.MM.yyyy") }
  ];
};

const generateMockReviewItems = () => {
  const batches = generateMockBatches();
  const statuses: ("pending" | "approved" | "rejected" | "ready-for-push")[] = ["pending", "approved", "rejected", "ready-for-push"];
  const fields = ["goods_services_manual", "taxability_manual", "pot_indicator_manual", "likely_right_deduct_vat_manual"];
  
  const items: EntityReviewItem[] = [];
  
  for (let i = 0; i < 20; i++) {
    const batchIndex = i % batches.length;
    const statusIndex = i % statuses.length;
    const fieldIndex = i % fields.length;
    
    items.push({
      id: `review${i + 1}`,
      batchId: batches[batchIndex].id,
      batchName: batches[batchIndex].name,
      entityId: `entity${i + 1}`,
      vatNo: `DK${12345678 + i}`,
      companyName: `Test Company ${i + 1}`,
      fieldName: fields[fieldIndex],
      oldValue: "Old Value",
      newValue: "New Value",
      note: "This is a note explaining the change.",
      reviewer: statuses[statusIndex] !== "pending" ? "Thomas Jensen" : null,
      reviewerNote: statuses[statusIndex] === "rejected" ? "This change doesn't look right." : null,
      status: statuses[statusIndex],
      createdAt: new Date(Date.now() - i * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - i * 43200000).toISOString()
    });
  }
  
  return items;
};

const ReviewPanel: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [mockBatches] = useState<BatchInfo[]>(generateMockBatches());
  const [mockReviewItems] = useState<EntityReviewItem[]>(generateMockReviewItems());
  const [currentBatch, setCurrentBatch] = useState<BatchInfo>(mockBatches[0]);
  const [reviewItems, setReviewItems] = useState<EntityReviewItem[]>(mockReviewItems);
  const [selectedItem, setSelectedItem] = useState<EntityReviewItem | null>(null);
  const [feedbackNote, setFeedbackNote] = useState("");
  const [isRejecting, setIsRejecting] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "pending" | "rejected" | "ready-for-push">("all");
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isFilterByDateEnabled, setIsFilterByDateEnabled] = useState(false);
  const [approveAllDialogOpen, setApproveAllDialogOpen] = useState(false);
  
  const handleApprove = (item: EntityReviewItem) => {
    markAsReadyForPush(item);
  };
  
  const approveItem = (item: EntityReviewItem) => {
    setReviewItems(items => 
      items.map(i => 
        i.id === item.id 
          ? { 
              ...i, 
              status: "approved", 
              reviewer: "Thomas Jensen",
              updatedAt: new Date().toISOString()
            } 
          : i
      )
    );
    
    toast({
      title: "Success",
      description: `Approved change for ${item.vatNo}`,
    });
  };
  
  const handleApproveAll = () => {
    setApproveAllDialogOpen(true);
  };
  
  const handleReject = (item: EntityReviewItem) => {
    setSelectedItem(item);
    setFeedbackNote("");
    setIsRejecting(true);
    setIsDialogOpen(true);
  };
  
  const handleSelectBatch = (batchId: string) => {
    const batch = mockBatches.find(b => b.id === batchId) || mockBatches[0];
    setCurrentBatch(batch);
  };
  
  const confirmApproveAll = () => {
    const pendingItems = reviewItems.filter(
      item => item.batchId === currentBatch.id && item.status === "pending"
    );
    
    setReviewItems(items => 
      items.map(item => {
        if (item.batchId === currentBatch.id && item.status === "pending") {
          return {
            ...item,
            status: "approved",
            reviewer: "Thomas Jensen",
            updatedAt: new Date().toISOString()
          };
        }
        return item;
      })
    );
    
    toast({
      title: "Success",
      description: `Approved ${pendingItems.length} changes in batch ${currentBatch.name}`,
    });
    
    setApproveAllDialogOpen(false);
    
    if (pendingItems.length === 0) {
      toast({
        title: "No Pending Changes",
        description: "There are no pending changes to approve in this batch.",
        variant: "destructive",
      });
    }
  };
  
  const submitFeedback = () => {
    if (!selectedItem) return;
    
    if (isRejecting) {
      if (!feedbackNote.trim()) {
        toast({
          title: "Feedback Required",
          description: "Please provide feedback about why you're rejecting this change.",
          variant: "destructive",
        });
        return;
      }
      
      setReviewItems(items => 
        items.map(i => 
          i.id === selectedItem.id 
            ? { 
                ...i, 
                status: "rejected", 
                reviewer: "Thomas Jensen",
                reviewerNote: feedbackNote,
                updatedAt: new Date().toISOString()
              } 
            : i
        )
      );
      
      toast({
        title: "Change Rejected",
        description: `Rejected change for ${selectedItem.vatNo} with feedback.`,
      });
    }
    
    setIsDialogOpen(false);
  };
  
  const markAsReadyForPush = (item: EntityReviewItem) => {
    setReviewItems(items => 
      items.map(i => 
        i.id === item.id 
          ? { 
              ...i, 
              status: "ready-for-push",
              reviewer: "Thomas Jensen",
              updatedAt: new Date().toISOString()
            } 
          : i
      )
    );
    
    toast({
      title: "Marked as Ready",
      description: `Change for ${item.vatNo} is now ready for push.`,
    });
  };
  
  const filteredItems = reviewItems.filter(item => {
    if (item.batchId !== currentBatch.id) {
      return false;
    }
    
    if (filter !== "all" && item.status !== filter) {
      return false;
    }
    
    if (isFilterByDateEnabled && date) {
      const itemDate = new Date(item.createdAt);
      return (
        itemDate.getDate() === date.getDate() &&
        itemDate.getMonth() === date.getMonth() &&
        itemDate.getFullYear() === date.getFullYear()
      );
    }
    
    return true;
  });
  
  const tabCounts = {
    all: reviewItems.filter(item => item.batchId === currentBatch.id).length,
    pending: reviewItems.filter(item => item.batchId === currentBatch.id && item.status === "pending").length,
    approved: reviewItems.filter(item => item.batchId === currentBatch.id && item.status === "approved").length,
    rejected: reviewItems.filter(item => item.batchId === currentBatch.id && item.status === "rejected").length,
    readyForPush: reviewItems.filter(item => item.batchId === currentBatch.id && item.status === "ready-for-push").length
  };
  
  const formatFieldName = (name: string) => {
    return name
      .replace(/_/g, ' ')
      .replace(/manual/g, '')
      .trim()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };
  
  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/admin')} 
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Admin Panel
          </Button>
          
          <div className="flex gap-2 items-center">
            <Select defaultValue={currentBatch.id} onValueChange={handleSelectBatch}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select batch" />
              </SelectTrigger>
              <SelectContent>
                {mockBatches.map(batch => (
                  <SelectItem key={batch.id} value={batch.id}>
                    Batch: {batch.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant={isFilterByDateEnabled ? "default" : "outline"}
                  className={cn(
                    "w-[240px] justify-start text-left font-normal",
                    !date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={(date) => {
                    setDate(date);
                    setIsFilterByDateEnabled(!!date);
                    setIsCalendarOpen(false);
                  }}
                  initialFocus
                />
                <div className="p-3 border-t border-border">
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-left text-red-500 hover:text-red-600"
                    onClick={() => {
                      setIsFilterByDateEnabled(false);
                      setIsCalendarOpen(false);
                    }}
                  >
                    Clear date filter
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Review Panel</CardTitle>
            <CardDescription>
              Review, approve, or reject entity metadata changes for batch: {currentBatch.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" onValueChange={(value) => setFilter(value as any)}>
              <div className="flex justify-between items-center mb-4">
                <TabsList>
                  <TabsTrigger value="all">
                    All
                    <Badge variant="outline" className="ml-2">{tabCounts.all}</Badge>
                  </TabsTrigger>
                  <TabsTrigger value="pending">
                    Pending
                    <Badge variant="outline" className="ml-2">{tabCounts.pending}</Badge>
                  </TabsTrigger>
                  <TabsTrigger value="rejected">
                    Rejected
                    <Badge variant="outline" className="ml-2">{tabCounts.rejected}</Badge>
                  </TabsTrigger>
                  <TabsTrigger value="ready-for-push">
                    Ready for Push
                    <Badge variant="outline" className="ml-2">{tabCounts.readyForPush}</Badge>
                  </TabsTrigger>
                </TabsList>
                
                {filter === "pending" && tabCounts.pending > 0 && (
                  <Button 
                    variant="default" 
                    onClick={handleApproveAll}
                    className="flex items-center gap-2"
                  >
                    <CheckCircle className="h-4 w-4" />
                    Approve All
                  </Button>
                )}
                {filter !== "pending" && <div></div>}
                <div></div>
              </div>
              
              <TabsContent value="all">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">VAT Number</TableHead>
                        <TableHead className="w-[150px]">Company</TableHead>
                        <TableHead className="w-[120px]">Field</TableHead>
                        <TableHead className="w-[120px]">Old Value</TableHead>
                        <TableHead className="w-[120px]">New Value</TableHead>
                        <TableHead className="w-[150px]">Date</TableHead>
                        <TableHead className="w-[100px]">Status</TableHead>
                        <TableHead className="w-[120px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="h-24 text-center">No results found.</TableCell>
                        </TableRow>
                      ) : (
                        filteredItems.map(item => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">{item.vatNo}</TableCell>
                            <TableCell>{item.companyName}</TableCell>
                            <TableCell>{formatFieldName(item.fieldName)}</TableCell>
                            <TableCell>{item.oldValue || <span className="text-gray-400">Empty</span>}</TableCell>
                            <TableCell className="font-medium">{item.newValue}</TableCell>
                            <TableCell>{format(new Date(item.createdAt), "dd/MM/yyyy")}</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  item.status === "approved" ? "secondary" :
                                  item.status === "rejected" ? "destructive" :
                                  item.status === "ready-for-push" ? "outline" :
                                  "default"
                                }
                              >
                                {item.status === "ready-for-push" ? "Ready" : item.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                {item.status === "pending" && (
                                  <>
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      className="h-8 w-8 p-0 text-green-500 hover:text-green-700"
                                      onClick={() => handleApprove(item)}
                                    >
                                      <Check className="h-4 w-4" />
                                      <span className="sr-only">Approve</span>
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                                      onClick={() => handleReject(item)}
                                    >
                                      <X className="h-4 w-4" />
                                      <span className="sr-only">Reject</span>
                                    </Button>
                                  </>
                                )}
                                {item.status === "approved" && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-8 w-8 p-0 text-blue-500 hover:text-blue-700"
                                    onClick={() => markAsReadyForPush(item)}
                                  >
                                    <CheckCircle className="h-4 w-4" />
                                    <span className="sr-only">Ready for Push</span>
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
              
              <TabsContent value="pending">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">VAT Number</TableHead>
                        <TableHead className="w-[150px]">Company</TableHead>
                        <TableHead className="w-[120px]">Field</TableHead>
                        <TableHead className="w-[120px]">Old Value</TableHead>
                        <TableHead className="w-[120px]">New Value</TableHead>
                        <TableHead className="w-[150px]">Date</TableHead>
                        <TableHead className="w-[120px]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="h-24 text-center">No pending items found.</TableCell>
                        </TableRow>
                      ) : (
                        filteredItems.map(item => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">{item.vatNo}</TableCell>
                            <TableCell>{item.companyName}</TableCell>
                            <TableCell>{formatFieldName(item.fieldName)}</TableCell>
                            <TableCell>{item.oldValue || <span className="text-gray-400">Empty</span>}</TableCell>
                            <TableCell className="font-medium">{item.newValue}</TableCell>
                            <TableCell>{format(new Date(item.createdAt), "dd/MM/yyyy")}</TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0 text-green-500 hover:text-green-700"
                                  onClick={() => handleApprove(item)}
                                >
                                  <Check className="h-4 w-4" />
                                  <span className="sr-only">Approve</span>
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0 text-red-500 hover:text-red-700"
                                  onClick={() => handleReject(item)}
                                >
                                  <X className="h-4 w-4" />
                                  <span className="sr-only">Reject</span>
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
              
              <TabsContent value="rejected">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">VAT Number</TableHead>
                        <TableHead className="w-[150px]">Company</TableHead>
                        <TableHead className="w-[120px]">Field</TableHead>
                        <TableHead className="w-[120px]">Old Value</TableHead>
                        <TableHead className="w-[120px]">New Value</TableHead>
                        <TableHead className="w-[150px]">Date</TableHead>
                        <TableHead className="w-[200px]">Rejection Reason</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="h-24 text-center">No rejected items found.</TableCell>
                        </TableRow>
                      ) : (
                        filteredItems.map(item => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">{item.vatNo}</TableCell>
                            <TableCell>{item.companyName}</TableCell>
                            <TableCell>{formatFieldName(item.fieldName)}</TableCell>
                            <TableCell>{item.oldValue || <span className="text-gray-400">Empty</span>}</TableCell>
                            <TableCell className="font-medium">{item.newValue}</TableCell>
                            <TableCell>{format(new Date(item.createdAt), "dd/MM/yyyy")}</TableCell>
                            <TableCell className="text-red-500">{item.reviewerNote}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
              
              <TabsContent value="ready-for-push">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">VAT Number</TableHead>
                        <TableHead className="w-[150px]">Company</TableHead>
                        <TableHead className="w-[120px]">Field</TableHead>
                        <TableHead className="w-[120px]">Old Value</TableHead>
                        <TableHead className="w-[120px]">New Value</TableHead>
                        <TableHead className="w-[150px]">Date</TableHead>
                        <TableHead className="w-[120px]">Updated By</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="h-24 text-center">No items ready for push found.</TableCell>
                        </TableRow>
                      ) : (
                        filteredItems.map(item => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">{item.vatNo}</TableCell>
                            <TableCell>{item.companyName}</TableCell>
                            <TableCell>{formatFieldName(item.fieldName)}</TableCell>
                            <TableCell>{item.oldValue || <span className="text-gray-400">Empty</span>}</TableCell>
                            <TableCell className="font-medium">{item.newValue}</TableCell>
                            <TableCell>{format(new Date(item.createdAt), "dd/MM/yyyy")}</TableCell>
                            <TableCell>{item.reviewer}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {isRejecting ? "Reject Change" : "Approve Change"}
              </DialogTitle>
              <DialogDescription>
                {isRejecting 
                  ? "Please provide feedback about why you're rejecting this change." 
                  : "Add a note (optional) for why you're approving this change."}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              {selectedItem && (
                <>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="font-medium">VAT Number:</div>
                    <div>{selectedItem.vatNo}</div>
                    
                    <div className="font-medium">Company:</div>
                    <div>{selectedItem.companyName}</div>
                    
                    <div className="font-medium">Field:</div>
                    <div>{formatFieldName(selectedItem.fieldName)}</div>
                    
                    <div className="font-medium">Old Value:</div>
                    <div>{selectedItem.oldValue || <span className="text-gray-400">Empty</span>}</div>
                    
                    <div className="font-medium">New Value:</div>
                    <div className="font-medium">{selectedItem.newValue}</div>
                    
                    <div className="font-medium">Submitter Note:</div>
                    <div>{selectedItem.note || <span className="text-gray-400">No note provided</span>}</div>
                  </div>
                  
                  <div className="mt-2">
                    <label htmlFor="feedback" className="text-sm font-medium block mb-1">
                      {isRejecting ? "Rejection Feedback" : "Approval Note"}
                      {isRejecting && <span className="text-red-500">*</span>}
                    </label>
                    <Textarea
                      id="feedback"
                      value={feedbackNote}
                      onChange={(e) => setFeedbackNote(e.target.value)}
                      placeholder={isRejecting 
                        ? "Explain why you're rejecting this change..." 
                        : "Add an optional note..."}
                      className={isRejecting && !feedbackNote.trim() ? "border-red-300" : ""}
                    />
                    {isRejecting && !feedbackNote.trim() && (
                      <p className="text-red-500 text-xs mt-1">Feedback is required for rejection</p>
                    )}
                  </div>
                </>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                variant={isRejecting ? "destructive" : "default"}
                onClick={submitFeedback}
                disabled={isRejecting && !feedbackNote.trim()}
              >
                {isRejecting ? "Reject" : "Approve"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        <AlertDialog open={approveAllDialogOpen} onOpenChange={setApproveAllDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                Are you sure?
              </AlertDialogTitle>
              <AlertDialogDescription>
                You need to validate all lines before pushing. This will approve all pending changes in the current batch.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmApproveAll}>
                Approve All
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </MainLayout>
  );
};

export default ReviewPanel;
