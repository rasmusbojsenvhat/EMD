
import React from "react";
import MainLayout from "@/components/layout/MainLayout";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const AdminPanel: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-start mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')} 
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Tilbage
          </Button>
        </div>
        
        <h1 className="text-2xl font-bold mb-6">Admin Panel</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Button 
            onClick={() => navigate('/admin/emd')} 
            variant="outline"
            className="h-40 flex flex-col items-center justify-center p-6 hover:bg-gray-50"
          >
            <div className="px-2 w-full">
              <h3 className="text-lg font-medium text-center mb-2">Entity Meta Database</h3>
              <p className="text-sm text-gray-500 text-center break-words">
                Manage and edit entity metadata for VAT validation
              </p>
            </div>
          </Button>
          
          <Button 
            onClick={() => navigate('/admin/partner')} 
            variant="outline" 
            className="h-40 flex flex-col items-center justify-center p-6 hover:bg-gray-50"
          >
            <div className="px-2 w-full">
              <h3 className="text-lg font-medium text-center mb-2">Partner Access</h3>
              <p className="text-sm text-gray-500 text-center break-words">
                Manage partner access and permissions
              </p>
            </div>
          </Button>
        </div>
      </div>
    </MainLayout>
  );
};

export default AdminPanel;
