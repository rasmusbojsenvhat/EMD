
import React, { useState, useEffect } from "react";
import MainLayout from "@/components/layout/MainLayout";
import EntityMetaDatabase from "@/components/admin/EntityMetaDatabase";
import EntityMetaNavigation from "@/components/admin/EntityMetaNavigation";
import { Button } from "@/components/ui/button";
import { ArrowLeft, AlertCircle, Loader2, Database, ServerOff, RefreshCw, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import "../components/dashboard/styles/VatTable.css"; // Import the same styles used for VIES table
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { emdApi } from "@/services/emdApi";
import { EntityMetaData } from "@/types/emd";

const EntityMetaDatabasePage: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [connectionStatus, setConnectionStatus] = useState<'checking' | 'connected' | 'mock' | 'failed'>('checking');
  const [entityCount, setEntityCount] = useState<number>(0);
  const [entities, setEntities] = useState<EntityMetaData[]>([]);
  
  // Check database connection on component mount
  useEffect(() => {
    const checkConnection = async () => {
      try {
        console.log("Checking connection to database API...");
        setIsLoading(true);
        
        // Let's make this explicit to force USE_MOCK_DATA to take effect
        // This is in case window.USE_MOCK_DATA was set somewhere else
        (window as any).USE_MOCK_DATA = true;
        
        const fetchedEntities = await emdApi.fetchEntities();
        setEntities(fetchedEntities);
        setEntityCount(fetchedEntities.length);
        
        // Check if we're using mock data or real API
        const isMockData = true; // Force mock data
        setConnectionStatus(isMockData ? 'mock' : 'connected');
        
        setIsLoading(false);
        
        console.log(`Successfully connected to ${isMockData ? 'mock data' : 'database API at ' + emdApi.getApiUrl()}`);
        console.log(`Found ${fetchedEntities.length} entities.`);
        
        // Log a sample entity for debugging
        if (fetchedEntities.length > 0) {
          console.log("Sample entity:", fetchedEntities[0]);
        } else {
          console.log("No entities found in the response");
        }
        
        toast({
          title: isMockData ? "Using Mock Data" : "Database Connected",
          description: `Successfully ${isMockData ? 'loaded mock data' : 'connected to the Railway PostgreSQL database'}. Found ${fetchedEntities.length} entities.`,
        });
      } catch (err) {
        console.error("Database connection error:", err);
        setConnectionStatus('failed');
        setError("Failed to connect to the database API. Using mock data instead.");
        setIsLoading(false);
        toast({
          title: "Database Connection Failed",
          description: "Could not connect to the database. Using mock data instead.",
          variant: "destructive",
        });
      }
    };
    
    checkConnection();
  }, [toast]);
  
  const handleError = (errorMsg: string) => {
    setError(errorMsg);
    console.error("Error in EntityMetaDatabase:", errorMsg);
  };
  
  const handleLoadingChange = (loading: boolean) => {
    setIsLoading(loading);
  };

  const handleDataRefresh = async () => {
    setIsLoading(true);
    try {
      const refreshedEntities = await emdApi.fetchEntities();
      console.log("Refreshed entities:", refreshedEntities.length, refreshedEntities);
      setEntities(refreshedEntities);
      setEntityCount(refreshedEntities.length);
      
      const isMockData = true; // Force mock data
      setConnectionStatus(isMockData ? 'mock' : 'connected');
      
      toast({
        title: "Data Refreshed",
        description: `Successfully refreshed data. Found ${refreshedEntities.length} entities.`,
      });
    } catch (err) {
      console.error("Error refreshing data:", err);
      setConnectionStatus('failed');
      setError("Failed to refresh data from the database API.");
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh entity data. Check console for details.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between mb-6">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/admin')} 
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Go to Admin Panel
          </Button>
          
          <Button
            onClick={handleDataRefresh}
            disabled={isLoading || connectionStatus === 'checking'}
            className="flex items-center gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            Refresh Data
          </Button>
        </div>
        
        <div className="mb-4">
          {connectionStatus === 'checking' && (
            <Alert variant="default" className="bg-blue-50 border-blue-200">
              <Loader2 className="h-4 w-4 animate-spin text-blue-500 mr-2" />
              <AlertTitle>Connecting to database...</AlertTitle>
              <AlertDescription>
                Attempting to connect to the Railway PostgreSQL database at {emdApi.getApiUrl()}
              </AlertDescription>
            </Alert>
          )}
          
          {connectionStatus === 'connected' && (
            <Alert variant="default" className="bg-green-50 border-green-200">
              <Database className="h-4 w-4 text-green-500 mr-2" />
              <AlertTitle>Database Connected</AlertTitle>
              <AlertDescription>
                Successfully connected to the Railway PostgreSQL database API at {emdApi.getApiUrl()}.
                Found {entityCount} entities.
              </AlertDescription>
            </Alert>
          )}
          
          {connectionStatus === 'mock' && (
            <Alert variant="default" className="bg-yellow-50 border-yellow-200">
              <Clock className="h-4 w-4 text-yellow-500 mr-2" />
              <AlertTitle>Using Mock Data</AlertTitle>
              <AlertDescription>
                Currently using mock data for development. Found {entityCount} entities.
              </AlertDescription>
            </Alert>
          )}
          
          {connectionStatus === 'failed' && (
            <Alert variant="default" className="bg-orange-50 border-orange-200">
              <ServerOff className="h-4 w-4 text-orange-500 mr-2" />
              <AlertTitle>Connection Failed - Using Mock Data</AlertTitle>
              <AlertDescription>
                Could not connect to the database API at {emdApi.getApiUrl()}.
                Using mock data instead.
              </AlertDescription>
            </Alert>
          )}
        </div>
        
        <EntityMetaNavigation />
        
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        {isLoading && (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
            <span className="ml-2 text-gray-600">Loading data...</span>
          </div>
        )}
        
        <div className="my-4">
          <EntityMetaDatabase 
            onError={handleError} 
            onLoadingChange={handleLoadingChange}
            initialEntities={entities}
          />
        </div>
      </div>
    </MainLayout>
  );
};

export default EntityMetaDatabasePage;
