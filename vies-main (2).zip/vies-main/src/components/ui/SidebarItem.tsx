
import React from "react";
import { cn } from "@/lib/utils";
import StatusBadge from "./StatusBadge";
import { Loader } from "lucide-react";

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  badge?: {
    text: string;
    variant?: "primary" | "secondary" | "count" | "comingSoon";
    loading?: boolean;
  };
  isActive?: boolean;
  onClick?: () => void;
  className?: string;
}

export const SidebarItem: React.FC<SidebarItemProps> = ({
  icon,
  label,
  badge,
  isActive = false,
  onClick,
  className,
}) => {
  return (
    <div
      className={cn(
        "flex items-center gap-3 cursor-pointer text-slate-700 px-3 py-2 rounded-lg hover:bg-slate-50 transition-colors",
        isActive && "bg-indigo-50 text-indigo-900",
        className,
      )}
      onClick={onClick}
    >
      <div className={cn(
        "text-slate-600",
        isActive && "text-indigo-600"
      )}>
        {icon}
      </div>
      <div className={cn(
        "text-sm font-medium",
        isActive && "font-semibold"
      )}>
        {label}
      </div>
      {badge && badge.variant === "count" && (
        <div className="ml-auto">
          {badge.loading ? (
            <div className="flex items-center justify-center">
              <Loader className="w-4 h-4 text-indigo-500 animate-spin" />
            </div>
          ) : (
            <StatusBadge variant="count">{badge.text}</StatusBadge>
          )}
        </div>
      )}
      {badge && badge.variant === "comingSoon" && (
        <StatusBadge variant="comingSoon">{badge.text}</StatusBadge>
      )}
    </div>
  );
};

export default SidebarItem;
