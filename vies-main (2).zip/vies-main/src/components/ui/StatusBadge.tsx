
import React from "react";
import { cn } from "@/lib/utils";

type StatusBadgeVariant = "primary" | "secondary" | "count" | "comingSoon";

interface StatusBadgeProps {
  variant?: StatusBadgeVariant;
  children: React.ReactNode;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  variant = "primary",
  children,
  className,
}) => {
  const baseStyles = "text-xs px-2 py-1 rounded-full inline-flex items-center justify-center";

  const variantStyles = {
    primary: "bg-indigo-400 text-white",
    secondary: "bg-slate-200 text-slate-500",
    count: "bg-indigo-400 text-white font-medium min-w-[28px]",
    comingSoon: "bg-slate-200 text-slate-500",
  };

  return (
    <div className={cn(baseStyles, variantStyles[variant], className)}>
      {children}
    </div>
  );
};

export default StatusBadge;
