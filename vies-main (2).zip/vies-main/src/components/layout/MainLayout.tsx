import React from "react";
import Sidebar from "./Sidebar";

interface MainLayoutProps {
  children: React.ReactNode;
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  return (
    <div className="flex min-h-screen bg-[#f8f7ff] max-sm:flex-col">
      <Sidebar />
      <div className="flex-1 px-8 py-6 max-md:p-4 max-sm:p-2">{children}</div>
    </div>
  );
};

export default MainLayout;
