
import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import SidebarItem from "../ui/SidebarItem";
import { vatApi } from "@/services/vatApi";
import { Home, FileText, Zap, Globe, Settings } from "lucide-react";

export const Sidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [companyInfo, setCompanyInfo] = useState({ name: "", vatId: "" });

  // Get batch data to determine if we have any processing batches
  const { data: batches = [], isLoading: isLoadingBatches } = useQuery({
    queryKey: ['batches'],
    queryFn: vatApi.fetchBatches
  });

  // Calculate number of entries in processing batches
  const processingEntries = batches
    .filter(batch => batch.status === 'processing')
    .reduce((total, batch) => total + (batch.entries?.length || 0), 0);

  useEffect(() => {
    const info = vatApi.getCompanyInfo();
    setCompanyInfo(info);
  }, []);

  return (
    <div className="w-60 bg-white flex flex-col gap-6 px-4 py-6 max-md:w-[200px] max-sm:max-w-full max-sm:px-2 max-sm:py-4">
      <div className="text-2xl font-semibold text-black mb-6">VhAT<sup className="text-xs">®</sup></div>

      <div className="flex flex-col gap-4 max-sm:flex-row max-sm:overflow-x-auto">
        <SidebarItem 
          icon={<Home className="w-5 h-5" />} 
          label="Overblik"
          onClick={() => navigate('/')}
          isActive={location.pathname === '/'}
        />

        <SidebarItem 
          icon={<FileText className="w-5 h-5" />} 
          label="Momsoplysninger" 
        />

        <SidebarItem 
          icon={<Zap className="w-5 h-5" />} 
          label="VhAT momstjek" 
        />

        <SidebarItem
          icon={<Globe className="w-5 h-5" />}
          label="VIES validering"
          badge={processingEntries > 0 ? 
            { text: processingEntries.toString(), variant: "count", loading: true } : 
            batches.length > 0 ? 
              { text: batches.reduce((total, batch) => total + (batch.entries?.length || 0), 0).toString(), variant: "count" } : 
              undefined}
          isActive={location.pathname === '/validation'}
          onClick={() => navigate('/validation')}
        />
        
        <SidebarItem 
          icon={<Settings className="w-5 h-5" />}
          label="Admin Panel"
          isActive={location.pathname.startsWith('/admin')}
          onClick={() => navigate('/admin')}
        />
      </div>

      <div className="flex items-center gap-3 text-slate-500 cursor-pointer px-3 py-2 mt-auto">
        <i className="ti ti-settings" />
        <div>Indstillinger</div>
      </div>

      <div className="flex flex-col gap-1 text-slate-500 cursor-pointer border-t-slate-200 px-3 py-2 border-t border-solid">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <i className="ti ti-building" />
            <div>{companyInfo.name}</div>
          </div>
          <i className="ti ti-chevron-down" />
        </div>
        <div className="text-xs text-slate-400 ml-7">
          VAT ID: {companyInfo.vatId}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
