import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
const CORRECT_PASSWORD = "VhAT_2025";
const LOCAL_STORAGE_KEY = "vat_auth_status";
const PasswordProtection: React.FC<{
  children: React.ReactNode;
}> = ({
  children
}) => {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const {
    toast
  } = useToast();
  useEffect(() => {
    // Check if user is already authenticated
    const authStatus = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (authStatus === 'authenticated') {
      setIsAuthenticated(true);
    }
  }, []);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate network delay
    setTimeout(() => {
      if (password === CORRECT_PASSWORD) {
        localStorage.setItem(LOCAL_STORAGE_KEY, 'authenticated');
        setIsAuthenticated(true);
        toast({
          title: "Authentication successful",
          description: "Welcome to VAT Validation System"
        });
      } else {
        toast({
          title: "Authentication failed",
          description: "Incorrect password. Please try again.",
          variant: "destructive"
        });
      }
      setIsLoading(false);
    }, 600);
  };
  if (isAuthenticated) {
    return <>{children}</>;
  }
  return <div className="flex items-center justify-center min-h-screen bg-[#f8f7ff] p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-center">VhAT the fuck?</CardTitle>
          <CardDescription className="text-center">Please enter the password to our private space</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent>
            <div className="space-y-4">
              <Input type="password" placeholder="Enter password" value={password} onChange={e => setPassword(e.target.value)} className="w-full" autoFocus />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full" variant="brand" disabled={isLoading}>
              {isLoading ? "Verifying..." : "Login"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>;
};
export default PasswordProtection;