
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface LoadingStateProps {
  returnPath?: string;
  backText?: string;
}

const LoadingState: React.FC<LoadingStateProps> = ({ 
  returnPath = '/validation',
  backText = 'Tilbage'
}) => {
  const navigate = useNavigate();
  
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-start mb-6">
        <Button variant="ghost" onClick={() => navigate(returnPath)} className="flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          {backText}
        </Button>
      </div>
      <div className="flex justify-center py-10">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-500"></div>
      </div>
    </div>
  );
};

export default LoadingState;
