
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, RefreshCw, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface BatchHeaderProps {
  onExport: () => void;
  onDeleteBatch: () => void;
  onRetryFailed: () => void;
  onRefresh: () => void;
  hasFailed: boolean;
  isProcessing: boolean;
  retryPending: boolean;
}

const BatchHeader: React.FC<BatchHeaderProps> = ({
  onExport,
  onDeleteBatch,
  onRetryFailed,
  onRefresh,
  hasFailed,
  isProcessing,
  retryPending
}) => {
  const navigate = useNavigate();

  return (
    <div className="flex justify-between mb-6">
      <Button variant="ghost" onClick={() => navigate('/validation')} className="flex items-center gap-2">
        <ArrowLeft className="h-4 w-4" />
        Tilbage til oversigt
      </Button>
      <div className="flex gap-2">
        {hasFailed && (
          <Button 
            variant="outline" 
            onClick={onRetryFailed}
            disabled={retryPending}
            className="flex items-center gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${retryPending ? 'animate-spin' : ''}`} />
            Genforsøg fejlede
          </Button>
        )}
        <Button
          variant="outline"
          onClick={onRefresh}
          disabled={!isProcessing}
          className="flex items-center gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          Opdater status
        </Button>
        <Button 
          variant="brand" 
          onClick={onExport}
          className="flex items-center gap-2"
        >
          <Download className="h-4 w-4" />
          Eksportér
        </Button>
        <Button 
          variant="outline"
          onClick={onDeleteBatch}
          className="flex items-center gap-2 text-red-500 hover:bg-red-50"
        >
          <Trash2 className="h-4 w-4" />
          Slet batch
        </Button>
      </div>
    </div>
  );
};

export default BatchHeader;
