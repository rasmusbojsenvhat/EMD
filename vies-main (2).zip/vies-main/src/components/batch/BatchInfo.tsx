
import React from 'react';
import { AlertTriangle, Loader } from 'lucide-react';
import type { Batch } from '@/types/vat';

interface StatusCountsType {
  valid: number;
  invalid: number;
  failed: number;
  total: number;
}

interface BatchInfoProps {
  batch: Batch;
  statusCounts: StatusCountsType;
  hasFailed: boolean;
}

const BatchInfo: React.FC<BatchInfoProps> = ({ batch, statusCounts, hasFailed }) => {
  const isProcessing = batch.status === 'processing';
  
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
      <div className="flex justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold">{batch.name}</h2>
          <p className="text-gray-500">{batch.period}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={`px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1 ${
            batch.status === 'completed' 
              ? 'bg-green-100 text-green-800' 
              : batch.status === 'processing'
              ? 'bg-blue-100 text-blue-800'
              : 'bg-gray-100 text-gray-800'
          }`}>
            {isProcessing && <Loader className="h-3 w-3 animate-spin" />}
            {batch.status === 'completed' ? 'Gennemført' : 
             batch.status === 'processing' ? 'Behandler' : 'Klar'}
          </span>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-4 gap-4 mt-4">
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-sm text-gray-500">Totale indgange</p>
          <p className="text-2xl font-semibold">{statusCounts.total}</p>
        </div>
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-sm text-green-500">Gyldige</p>
          <p className="text-2xl font-semibold text-green-700">{statusCounts.valid}</p>
        </div>
        <div className="bg-red-50 p-4 rounded-lg">
          <p className="text-sm text-red-500">Ugyldige</p>
          <p className="text-2xl font-semibold text-red-700">{statusCounts.invalid}</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg">
          <p className="text-sm text-yellow-500">Fejlede</p>
          <p className="text-2xl font-semibold text-yellow-700">{statusCounts.failed}</p>
        </div>
      </div>

      {/* Processing indication */}
      {isProcessing && (
        <div className="mt-4 p-4 bg-blue-50 rounded-lg flex items-start gap-3">
          <Loader className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5 animate-spin" />
          <div>
            <h3 className="font-medium text-blue-800">Behandler anmodning</h3>
            <p className="text-sm text-blue-700">
              Systemet behandler dine momsnumre. Opdater siden for at se status.
            </p>
          </div>
        </div>
      )}

      {/* Warning for failed validations */}
      {!isProcessing && hasFailed && (
        <div className="mt-4 p-4 bg-yellow-50 rounded-lg flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-medium text-yellow-800">Der er {statusCounts.failed} fejlede validationer</h3>
            <p className="text-sm text-yellow-700">Nogle momsnumre kunne ikke valideres. Prøv at genkøre valideringen for at løse problemet.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default BatchInfo;
