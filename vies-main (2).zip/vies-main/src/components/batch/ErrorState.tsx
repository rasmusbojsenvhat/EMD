
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ErrorState: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-start mb-6">
        <Button variant="ghost" onClick={() => navigate('/validation')} className="flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Tilbage
        </Button>
      </div>
      <div className="p-8 text-center text-red-500 bg-red-50 rounded-lg">
        <p>Der opstod en fejl under indlæsning af batch-detaljerne.</p>
        <p className="text-sm mt-2">Prøv at genindlæse siden, eller kontakt support hvis problemet fortsætter.</p>
      </div>
    </div>
  );
};

export default ErrorState;
