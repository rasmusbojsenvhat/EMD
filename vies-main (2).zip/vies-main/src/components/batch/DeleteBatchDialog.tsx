
import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { Batch } from '@/types/vat';

interface DeleteBatchDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  batch: Batch;
  totalEntries: number;
}

const DeleteBatchDialog: React.FC<DeleteBatchDialogProps> = ({
  isOpen,
  onOpenChange,
  onConfirm,
  batch,
  totalEntries
}) => {
  return (
    <AlertDialog open={isOpen} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Er du sikker på at du vil slette denne batch?</AlertDialogTitle>
          <AlertDialogDescription>
            Denne handling kan ikke fortrydes. Dette vil permanent slette batchen "{batch.name}" og alle dens {totalEntries} momsnumre.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={() => onOpenChange(false)}>Annuller</AlertDialogCancel>
          <AlertDialogAction 
            onClick={onConfirm}
            className="bg-red-500 hover:bg-red-600"
          >
            Slet batch
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default DeleteBatchDialog;
