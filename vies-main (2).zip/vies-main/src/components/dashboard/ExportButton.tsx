
import React from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { VatEntry } from "@/types/vat";
import { format } from "date-fns";

interface ExportButtonProps {
  entries: VatEntry[];
  batchName?: string;
}

export const ExportButton: React.FC<ExportButtonProps> = ({ entries, batchName }) => {
  const exportToExcel = () => {
    // Format the data for CSV
    const csvData = [
      // Header row - added "Request ID" column
      ["Momsnummer", "Virksomhedsnavn", "Adresse", "Tid for forespørgsel", "Status", "Request ID"],
      // Data rows - added requestId (with fallback to empty string if not present)
      ...entries.map(entry => [
        entry.vatNumber,
        entry.companyName,
        entry.address,
        formatDate(entry.requestTime),
        entry.status,
        entry.requestId || "" // Include requestId in the export, with fallback to empty string
      ])
    ];

    // Convert to CSV string
    const csvContent = csvData
      .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
      .join("\n");

    // Create a blob and download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    
    // Current timestamp for the filename
    const timestamp = format(new Date(), "yyyy-MM-dd_HH-mm");
    const batchInfo = batchName ? `-${batchName.replace(/\s/g, '_')}` : '';
    
    link.setAttribute("href", url);
    link.setAttribute("download", `vat-data${batchInfo}-${timestamp}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Format date for the CSV export
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd/MM/yyyy HH:mm");
    } catch (error) {
      return dateString;
    }
  };

  return (
    <Button 
      onClick={exportToExcel}
      variant="brand" 
      className="flex items-center gap-2"
    >
      <Download className="h-4 w-4" />
      <span>Rapport</span>
    </Button>
  );
};

export default ExportButton;
