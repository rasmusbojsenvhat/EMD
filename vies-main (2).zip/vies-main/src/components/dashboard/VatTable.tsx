
import React from "react";
import { format } from "date-fns";
import { ArrowUp2, ArrowDown2 } from "iconsax-react";
import { RefreshCw } from "lucide-react";
import type { VatEntry, SortConfig } from "@/types/vat";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { vatApi } from "@/services/vatApi";
import { useQueryClient } from "@tanstack/react-query";
import "./styles/VatTable.css";

interface VatTableProps {
  entries: VatEntry[];
  sortConfig: SortConfig | null;
  onSort: (key: keyof VatEntry) => void;
  currentBatchId?: string;
}

export const VatTable: React.FC<VatTableProps> = ({ 
  entries, 
  sortConfig, 
  onSort,
  currentBatchId
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [revalidatingIds, setRevalidatingIds] = React.useState<Set<string>>(new Set());
  
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd/MM/yyyy HH:mm");
    } catch (error) {
      console.error("Invalid date format:", dateString, error);
      return dateString;
    }
  };

  const renderSortableHeader = (label: string, key: keyof VatEntry) => {
    const isSorted = sortConfig?.key === key;
    
    return (
      <Button
        variant="ghost"
        onClick={() => onSort(key)}
        className="h-8 font-medium p-0 hover:bg-transparent"
      >
        {label}
        {isSorted && (
          <span className="ml-2">
            {sortConfig.direction === 'ascending' 
              ? <ArrowUp2 size={16} className="text-indigo-600" /> 
              : <ArrowDown2 size={16} className="text-indigo-600" />
            }
          </span>
        )}
      </Button>
    );
  };

  const getStatusBadgeClass = (status: string) => {
    if (status.includes("Gyldigt momsnummer")) return "vat-status-badge vat-status-valid";
    if (status.includes("Ikke gyldigt momsnummer")) return "vat-status-badge vat-status-invalid";
    if (status.includes("Validering mislykkes")) return "vat-status-badge vat-status-failed";
    if (status.includes("Ikke et EU-momsnummer")) return "vat-status-badge vat-status-noteu";
    return "vat-status-badge";
  };

  const getErrorDescription = (errorText: string): string => {
    if (errorText.includes("MS_UNAVAILABLE") || errorText.includes("MS:UNAVAILABLE")) {
      return "Medlemslandets database er pt. ikke tilgængelig";
    } else if (errorText.includes("TIMEOUT")) {
      return "Forespørgslen til medlemslandets database tog for lang tid";
    } else if (errorText.includes("SERVICE_UNAVAILABLE")) {
      return "VIES valideringstjenesten er pt. ikke tilgængelig";
    } else if (errorText.includes("INVALID_INPUT")) {
      return "Momsnummeret har et ugyldigt format";
    } else if (errorText.includes("SERVER_BUSY")) {
      return "VIES serveren er overbelastet - prøv igen senere";
    } else {
      return `Fejlbeskrivelse: ${errorText || "Ingen yderligere detaljer"}`;
    }
  };

  const handleRevalidate = async (entry: VatEntry) => {
    if (!currentBatchId) {
      toast({
        title: "Fejl",
        description: "Kunne ikke genkøre validering - ingen batch valgt",
        variant: "destructive"
      });
      return;
    }

    setRevalidatingIds(prev => new Set(prev).add(entry.id));

    try {
      const result = await vatApi.validateVatNumber(entry.vatNumber);
      
      if (result.success && result.data) {
        if (entry.requestId) {
          result.data.requestId = entry.requestId;
        }
        
        await vatApi.addEntryToBatch(currentBatchId, result.data);
        
        queryClient.invalidateQueries({ queryKey: ['vat-entries', currentBatchId] });
        
        toast({
          title: "Succes",
          description: `Momsnummer ${entry.vatNumber} er blevet valideret igen.`,
        });
      } else {
        toast({
          title: "Validering fejlede",
          description: result.message || "Kunne ikke validere momsnummeret",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error revalidating VAT number:", error);
      toast({
        title: "Fejl",
        description: "Der opstod en fejl under genvalideringen",
        variant: "destructive",
      });
    } finally {
      setRevalidatingIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(entry.id);
        return newSet;
      });
    }
  };

  const parseVatNumber = (vatNumber: string) => {
    const match = vatNumber.match(/^([A-Z]{2})(.*)/);
    return match ? { countryCode: match[1], vatId: match[2] } : { countryCode: "", vatId: vatNumber };
  };

  const getCountryName = (countryCode: string): string => {
    const countryMap: Record<string, string> = {
      AT: "Østrig",
      BE: "Belgien",
      BG: "Bulgarien",
      CY: "Cypern",
      CZ: "Tjekkiet",
      DE: "Tyskland",
      DK: "Danmark",
      EE: "Estland",
      EL: "Grækenland",
      ES: "Spanien",
      FI: "Finland",
      FR: "Frankrig",
      GB: "Storbritannien",
      HR: "Kroatien",
      HU: "Ungarn",
      IE: "Irland",
      IT: "Italien",
      LT: "Litauen",
      LU: "Luxembourg",
      LV: "Letland",
      MT: "Malta",
      NL: "Holland",
      PL: "Polen",
      PT: "Portugal",
      RO: "Rumænien",
      SE: "Sverige",
      SI: "Slovenien",
      SK: "Slovakiet",
    };
    
    return countryMap[countryCode] || countryCode;
  };

  return (
    <TooltipProvider>
      <div className="vat-table-container">
        <div className="vat-table-header">
          <div className="vat-id-column min-w-[70px]">
            <div>{renderSortableHeader("Momsnummer", "vatNumber")}</div>
            <div className="mt-1">
              <Button
                variant="ghost" 
                onClick={() => onSort('vatNumber')}
                className="h-6 font-medium p-0 text-xs hover:bg-transparent"
              >
                Land
              </Button>
            </div>
          </div>
          <div className="company-name-column min-w-[70px]">
            <div>{renderSortableHeader("Kundenavn (VIES)", "companyName")}</div>
            <div className="mt-1">
              <Button
                variant="ghost" 
                className="h-6 font-medium p-0 text-xs hover:bg-transparent"
                disabled
              >
                Kundenavn
              </Button>
            </div>
          </div>
          <div className="address-column min-w-[70px]">
            <div>{renderSortableHeader("Adresse (VIES)", "address")}</div>
            <div className="mt-1">
              <Button
                variant="ghost" 
                className="h-6 font-medium p-0 text-xs hover:bg-transparent"
                disabled
              >
                Adresse
              </Button>
            </div>
          </div>
          <div className="min-w-[70px]">{renderSortableHeader("Tid for forespørgsel", "requestTime")}</div>
          <div className="min-w-[70px]">{renderSortableHeader("Baggrund", "status")}</div>
        </div>

        {entries.length === 0 ? (
          <div className="vat-table-empty">
            Ingen resultater at vise for denne kategori
          </div>
        ) : (
          <div className="vat-table-scroll-container">
            {entries.map((entry) => {
              const { countryCode, vatId } = parseVatNumber(entry.vatNumber);
              const countryName = getCountryName(countryCode);
              const isInvalid = entry.status.includes("Ikke gyldigt momsnummer");
              const isFailed = entry.status.includes("Validering mislykkes");
              const isGerman = countryCode === "DE";
              
              const errorInfoMatch = entry.status.match(/\(([^)]+)\)/);
              const errorInfo = errorInfoMatch ? errorInfoMatch[1] : "";
              
              return (
                <div key={entry.id} className="vat-table-row">
                  <div className="vat-table-cell vat-id-cell min-w-[70px]">
                    <div>
                      <div className="font-medium">{vatId}</div>
                      <div className="text-xs text-gray-500 mt-1">{countryName}</div>
                    </div>
                  </div>
                  <div className="vat-table-cell company-name-cell min-w-[70px]">
                    <div className="font-medium">{isGerman && !entry.companyName ? "N/A" : entry.companyName}</div>
                    <div className="text-xs text-gray-500 mt-1">{isGerman && !entry.companyName ? "N/A" : entry.companyName}</div>
                  </div>
                  <div className="vat-table-cell address-cell min-w-[70px]">
                    {isGerman ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div>
                            <div className="font-medium">Ingen adresse</div>
                            <div className="text-xs text-gray-500 mt-1">Ingen adresse</div>
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Oplysningerne er ikke tilgængelige i VIES for tyske virksomheder</p>
                        </TooltipContent>
                      </Tooltip>
                    ) : (
                      <>
                        <div className="font-medium">{entry.address || "---"}</div>
                        <div className="text-xs text-gray-500 mt-1">{entry.address || "---"}</div>
                      </>
                    )}
                  </div>
                  <div className="vat-table-cell min-w-[70px]">{formatDate(entry.requestTime)}</div>
                  <div className="vat-table-cell status-cell min-w-[70px]">
                    <div className="flex flex-col">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className={getStatusBadgeClass(entry.status)}>
                            {entry.status}
                          </span>
                        </TooltipTrigger>
                        <TooltipContent>
                          {isFailed ? (
                            <div>
                              <p className="font-medium">Årsag til fejlet validering:</p>
                              <p>{getErrorDescription(errorInfo)}</p>
                              <p className="text-xs mt-1">Forespørgsel ID: {entry.requestId || "N/A"}</p>
                            </div>
                          ) : (
                            <p>Forespørgsel ID: {entry.requestId || "N/A"}</p>
                          )}
                        </TooltipContent>
                      </Tooltip>
                      
                      {(isInvalid || isFailed) && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-6 w-fit p-1 mt-2 flex items-center gap-1"
                              onClick={() => handleRevalidate(entry)}
                              disabled={revalidatingIds.has(entry.id)}
                            >
                              <RefreshCw 
                                className={`h-3 w-3 ${revalidatingIds.has(entry.id) ? 'animate-spin' : ''}`} 
                              />
                              <span className="text-xs">Prøv igen</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Genvalider momsnummer</p>
                          </TooltipContent>
                        </Tooltip>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </TooltipProvider>
  );
};

export default VatTable;
