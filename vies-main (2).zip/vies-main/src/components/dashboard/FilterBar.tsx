
import React, { useState } from "react";
import { ChevronDown, Send } from "lucide-react";
import { Batch } from "@/types/vat";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import "./styles/FilterBar.css";

interface FilterBarProps {
  currentBatch: Batch;
  batches: Batch[];
  onBatchChange: (batchId: string) => void;
  onSubmitToReview?: () => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({ 
  currentBatch, 
  batches, 
  onBatchChange,
  onSubmitToReview
}) => {
  return (
    <div className="filter-bar">
      <div className="filter-controls">
        <Select 
          value={currentBatch.id} 
          onValueChange={onBatchChange}
        >
          <SelectTrigger className="filter-dropdown" aria-label="Select batch">
            <SelectValue>{currentBatch.name}</SelectValue>
            <ChevronDown className="h-4 w-4" />
          </SelectTrigger>
          <SelectContent className="filter-dropdown-content bg-white">
            {batches.map(batch => (
              <SelectItem 
                key={batch.id} 
                value={batch.id}
                className="filter-dropdown-item"
              >
                {batch.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {onSubmitToReview && (
        <Button 
          onClick={onSubmitToReview}
          className="submit-button"
          variant="default"
        >
          <Send className="h-4 w-4 mr-2" />
          Submit to Review
        </Button>
      )}
    </div>
  );
};

export default FilterBar;
