
import React, { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Upload, AlertTriangle } from "lucide-react";
import { vatApi } from '@/services/vatApi';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert } from "@/components/ui/alert";

export const CsvLoader: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [batchName, setBatchName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [entriesCount, setEntriesCount] = useState(0);
  const [processingStatus, setProcessingStatus] = useState('');
  const [error, setError] = useState('');

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setError('');
    
    if (!file.name.endsWith('.csv')) {
      toast({
        title: "Fejl",
        description: "Vælg venligst en CSV-fil",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    
    try {
      console.log("Previewing CSV file:", file.name);
      setProcessingStatus('Analyserer CSV fil...');
      const entries = await vatApi.previewCsvFile(file);
      console.log("CSV preview successful, found entries:", entries.length);
      setEntriesCount(entries.length);
      setProcessingStatus('');
      
      const defaultName = file.name.replace('.csv', '');
      setBatchName(defaultName);
      
      setIsDialogOpen(true);
    } catch (error) {
      console.error("CSV preview failed:", error);
      setError('Kunne ikke læse CSV-filen. Kontroller venligst formatet.');
      toast({
        title: "Fejl",
        description: "Kunne ikke læse CSV-filen",
        variant: "destructive",
      });
    }
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleProcessCsv = async () => {
    if (!selectedFile || !batchName.trim()) return;
    
    setIsLoading(true);
    setProcessingStatus('Indlæser og behandler CSV fil...');
    setError('');
    
    try {
      console.log("Processing CSV file, creating batch:", batchName);
      const success = await vatApi.loadEntriesFromCsv(selectedFile, batchName);
      
      if (success) {
        setProcessingStatus('CSV fil er blevet behandlet og gemt.');
        toast({
          title: "Success",
          description: `Batch "${batchName}" med ${entriesCount} poster er blevet oprettet og valideret.`,
        });
        
        // Invalidate the batches query to refresh the list
        queryClient.invalidateQueries({ queryKey: ['batches'] });
        
        setIsDialogOpen(false);
        setSelectedFile(null);
        setBatchName('');
      } else {
        console.error("CSV processing failed, no success response");
        setError('Der opstod en fejl under behandlingen.');
        setProcessingStatus('Der opstod en fejl under behandlingen.');
        toast({
          title: "Fejl",
          description: "Kunne ikke indlæse CSV-filen",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("CSV processing error:", error);
      setError('Der opstod en fejl ved forbindelse til API. Kontroller venligst netværksforbindelsen.');
      setProcessingStatus('Behandling mislykkedes.');
      toast({
        title: "Fejl",
        description: "Der opstod en fejl under behandling af filen",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <input
        type="file"
        accept=".csv"
        onChange={handleFileChange}
        className="hidden"
        ref={fileInputRef}
      />
      <Button
        variant="outline"
        onClick={() => fileInputRef.current?.click()}
        className="flex items-center gap-2"
      >
        <Upload className="h-4 w-4" />
        <span>Indlæs CSV</span>
      </Button>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Opret ny batch</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="batchName">Batch navn</Label>
              <Input 
                id="batchName" 
                value={batchName} 
                onChange={(e) => setBatchName(e.target.value)} 
                placeholder="Indtast et navn til denne batch"
              />
            </div>
            <div className="text-sm text-gray-500">
              <p>Filen indeholder {entriesCount} moms-numre til validering.</p>
              <p className="mt-2">Ved at oprette denne batch, vil alle moms-numre blive indsendt til validering.</p>
              {processingStatus && (
                <p className="mt-2 font-medium text-brand">{processingStatus}</p>
              )}
              {error && (
                <Alert variant="destructive" className="mt-2">
                  <AlertTriangle className="h-4 w-4" />
                  <span>{error}</span>
                </Alert>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Annuller</Button>
            <Button 
              onClick={handleProcessCsv} 
              disabled={!batchName.trim() || isLoading}
            >
              {isLoading ? 'Behandler...' : 'Opret batch'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CsvLoader;
