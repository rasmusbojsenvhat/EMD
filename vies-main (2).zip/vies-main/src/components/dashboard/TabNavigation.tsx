
import React from "react";
import {
  Tabs,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";

export type TabValue = "all" | "validated" | "not-validated" | "validation-failed" | "ready-for-push";

interface TabNavigationProps {
  activeTab: TabValue;
  onTabChange: (value: TabValue) => void;
  counts?: {
    all: number;
    validated: number;
    notValidated: number;
    validationFailed: number;
    readyForPush: number;
  };
}

export const TabNavigation: React.FC<TabNavigationProps> = ({
  activeTab,
  onTabChange,
  counts = { all: 0, validated: 0, notValidated: 0, validationFailed: 0, readyForPush: 0 }
}) => {
  return (
    <div className="mb-6">
      <Tabs value={activeTab} onValueChange={(value) => onTabChange(value as TabValue)} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all">
            Alle {counts.all > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{counts.all}</span>}
          </TabsTrigger>
          <TabsTrigger value="validated">
            Momsnumre - valideret {counts.validated > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{counts.validated}</span>}
          </TabsTrigger>
          <TabsTrigger value="not-validated">
            Valideret - ugyldige {counts.notValidated > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{counts.notValidated}</span>}
          </TabsTrigger>
          <TabsTrigger value="validation-failed">
            Validering - mislykkes {counts.validationFailed > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{counts.validationFailed}</span>}
          </TabsTrigger>
          <TabsTrigger value="ready-for-push">
            Klar til push {counts.readyForPush > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{counts.readyForPush}</span>}
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
};

export default TabNavigation;
