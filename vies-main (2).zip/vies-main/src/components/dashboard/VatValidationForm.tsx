
import React, { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { vatApi } from "@/services/vatApi";
import { Plus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { VatEntry } from "@/types/vat";

export const VatValidationForm: React.FC = () => {
  const [vatNumber, setVatNumber] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationResult, setValidationResult] = useState<VatEntry | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!vatNumber.trim()) {
      toast({
        title: "Fejl",
        description: "Indtast venligst et momsnummer",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Get the requestor's VAT ID from the company info
      const companyInfo = vatApi.getCompanyInfo();
      const requestorVatId = companyInfo.vatId;
      
      // Generate a unique request ID (timestamp + random number)
      const requestId = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
      
      const response = await vatApi.validateVatNumber(vatNumber.trim(), requestorVatId);
      
      if (response.success) {
        // Add the requestId to the response data
        const dataWithRequestId = {
          ...response.data,
          requestId
        };
        
        setValidationResult(dataWithRequestId);
        toast({
          title: "Succes",
          description: "Momsnummeret er valideret",
        });
      } else {
        toast({
          title: "Advarsel",
          description: response.message || "Momsnummeret er ikke gyldigt",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved validering af momsnummeret",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const addToTable = async () => {
    if (!validationResult) return;
    
    try {
      // Get the current batch ID from the query client
      const currentBatches = queryClient.getQueryData(['batches']) as any[];
      const currentBatchId = currentBatches && currentBatches.length > 0 ? currentBatches[0].id : null;
      
      if (!currentBatchId) {
        toast({
          title: "Fejl",
          description: "Kunne ikke finde et aktivt batch at tilføje til",
          variant: "destructive",
        });
        return;
      }
      
      // Add the validation result to the current batch
      await vatApi.addEntryToBatch(currentBatchId, validationResult);
      
      // Refresh the vat entries list
      queryClient.invalidateQueries({ queryKey: ['vat-entries'] });
      queryClient.invalidateQueries({ queryKey: ['batch', currentBatchId] });
      
      toast({
        title: "Succes",
        description: "Momsnummeret er tilføjet til tabellen",
      });
      
      // Reset the validation result
      setValidationResult(null);
      setVatNumber("");
    } catch (error) {
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved tilføjelse til tabellen",
        variant: "destructive",
      });
    }
  };

  const getStatusClass = (status: string) => {
    if (status.includes("Gyldigt momsnummer")) return "bg-green-100 text-green-800";
    if (status.includes("Ikke gyldigt momsnummer")) return "bg-yellow-100 text-yellow-800";
    if (status.includes("Validering mislykkes")) return "bg-red-100 text-red-800";
    return "bg-gray-100 text-gray-800";
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
      <h2 className="text-lg font-medium mb-4">Valider momsnummer manuelt</h2>
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          value={vatNumber}
          onChange={(e) => setVatNumber(e.target.value)}
          placeholder="Indtast momsnummer (f.eks. DK12345678)"
          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
          disabled={isSubmitting}
        />
        <button
          type="submit"
          disabled={isSubmitting}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md transition-colors disabled:opacity-50"
        >
          {isSubmitting ? (
            <span className="flex items-center justify-center">
              <Loader2 className="animate-spin h-4 w-4 mr-2" />
              Validerer...
            </span>
          ) : (
            "Valider"
          )}
        </button>
      </form>

      {/* Validation Result */}
      {validationResult && (
        <div className="mt-4 p-4 border border-gray-200 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-medium">{validationResult.vatNumber}</h3>
              <p className="text-sm text-gray-600">{validationResult.companyName}</p>
              <p className="text-sm text-gray-600">{validationResult.address}</p>
              <span className={`mt-2 inline-block px-2 py-1 text-xs rounded ${getStatusClass(validationResult.status)}`}>
                {validationResult.status}
                {validationResult.requestId && (
                  <span className="sr-only"> (Request ID: {validationResult.requestId})</span>
                )}
              </span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1 text-indigo-600 border-indigo-200 hover:bg-indigo-50"
              onClick={addToTable}
              title="Tilføj til tabellen"
            >
              <Plus className="h-4 w-4" />
              Tilføj til tabellen
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default VatValidationForm;
