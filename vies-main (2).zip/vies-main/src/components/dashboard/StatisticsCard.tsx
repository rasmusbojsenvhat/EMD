
import React from "react";
import { Check, AlertTriangle, XCircle } from "lucide-react";
import type { VatEntry } from "@/types/vat";

interface StatisticItemProps {
  icon: React.ReactNode;
  text: string;
  count: number;
}

const StatisticItem: React.FC<StatisticItemProps> = ({ icon, text, count }) => {
  return (
    <div className="flex items-center gap-2 text-sm px-3 py-1 rounded-2xl">
      {icon}
      <div>
        {count} {text}
      </div>
    </div>
  );
};

interface StatisticsCardProps {
  entries: VatEntry[];
}

export const StatisticsCard: React.FC<StatisticsCardProps> = ({ entries }) => {
  // Only show the card if there are entries
  if (!entries || entries.length === 0) {
    return null;
  }

  // Count entries by status
  const validCount = entries.filter(e => e.status.includes("Gyldigt momsnummer")).length;
  const invalidCount = entries.filter(e => e.status.includes("Ikke gyldigt momsnummer")).length;
  const failedCount = entries.filter(e => e.status.includes("Validering mislykkes")).length;
  const totalCount = entries.length;

  return (
    <div className="bg-white mb-6 p-6 rounded-lg max-sm:p-4">
      <div>
        <div className="text-2xl font-semibold text-black">{totalCount}</div>
        <div className="text-slate-500 text-sm">momsnumre gennemgået</div>
      </div>

      <div className="flex gap-4 mt-4 max-md:flex-wrap">
        <StatisticItem 
          icon={<Check className="h-4 w-4 text-green-500" />} 
          text="Momsnumre - valideret" 
          count={validCount} 
        />

        <StatisticItem 
          icon={<XCircle className="h-4 w-4 text-red-500" />} 
          text="Valideret - ugyldige" 
          count={invalidCount} 
        />

        <StatisticItem 
          icon={<AlertTriangle className="h-4 w-4 text-yellow-500" />} 
          text="Validering - mislykkes" 
          count={failedCount} 
        />
      </div>
    </div>
  );
};

export default StatisticsCard;
