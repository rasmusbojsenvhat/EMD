
import React from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import "./styles/SearchBar.css";

interface SearchBarProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({ 
  searchTerm, 
  onSearchChange 
}) => {
  return (
    <div className="search-bar-container">
      <div className="search-input-wrapper">
        <Search className="search-icon" />
        <Input
          type="text"
          className="search-input"
          placeholder="Søg efter momsnummer, virksomhedsnavn eller adresse..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
    </div>
  );
};

export default SearchBar;
