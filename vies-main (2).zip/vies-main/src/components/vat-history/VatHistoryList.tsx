
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Clock, Download, RefreshCw, Loader, ArrowRight } from 'lucide-react';
import type { Batch } from '@/types/vat';
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { useBatchStatusCounts } from '@/hooks/useBatchStatusCounts';

interface VatHistoryListProps {
  batches: Batch[];
  isRefreshing?: boolean;
  onRefresh?: () => void;
}

type FilterView = 'completed' | 'pending';

const VatHistoryList: React.FC<VatHistoryListProps> = ({ 
  batches, 
  isRefreshing = false,
  onRefresh 
}) => {
  const [activeView, setActiveView] = useState<FilterView>('completed');
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const handleRefresh = () => {
    if (onRefresh) {
      onRefresh();
    } else {
      queryClient.invalidateQueries({ queryKey: ['batches'] });
    }
  };

  const handleViewBatchDetails = (batchId: string) => {
    navigate(`/batch/${batchId}`);
  };

  const getValidatedCount = (batch: Batch) => {
    return batch.entries.filter(entry => 
      entry.status.includes('Gyldigt momsnummer')
    ).length;
  };

  const getPendingCount = (batch: Batch) => {
    if (batch.status === 'completed') {
      return 0;
    }
    
    return batch.entries.filter(entry => 
      !entry.status.includes('Gyldigt momsnummer')
    ).length;
  };

  const totalValidatedCount = batches.reduce((acc, batch) => acc + getValidatedCount(batch), 0);
  const totalPendingCount = batches.reduce((acc, batch) => acc + getPendingCount(batch), 0);
  const processingBatches = batches.filter(batch => batch.status === 'processing').length;

  const filteredBatches = batches.filter(batch => {
    if (activeView === 'completed') {
      return batch.status === 'completed' || getValidatedCount(batch) > 0;
    } else {
      return batch.status === 'processing' || (batch.status !== 'completed' && getPendingCount(batch) > 0);
    }
  });

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-4">
        <div className="flex gap-8">
          <Button 
            variant="outline"
            className={`rounded-lg p-4 flex items-center gap-3 h-auto ${activeView === 'completed' ? 'text-brand border-brand border-b-4' : ''}`}
            onClick={() => setActiveView('completed')}
          >
            <div className="bg-green-50 p-2 rounded-full">
              <Check className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Gennemførte VIES valideringer</p>
              <p className="text-2xl font-semibold">{totalValidatedCount}</p>
            </div>
          </Button>
          
          <Button 
            variant="outline"
            className={`rounded-lg p-4 flex items-center gap-3 h-auto ${activeView === 'pending' ? 'text-brand border-brand border-b-4' : ''}`}
            onClick={() => setActiveView('pending')}
          >
            <div className="bg-yellow-50 p-2 rounded-full">
              <Clock className="h-5 w-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Igangværende VIES valideringer</p>
              <p className="text-2xl font-semibold">{totalPendingCount}</p>
            </div>
          </Button>
        </div>

        <Button
          variant="outline"
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="flex items-center gap-2"
        >
          {isRefreshing ? (
            <Loader className="h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4" />
          )}
          Opdater status
        </Button>
      </div>

      {processingBatches > 0 && (
        <div className="bg-blue-50 p-4 rounded-lg flex items-center gap-3 mb-4">
          <Loader className="h-5 w-5 text-blue-500 animate-spin" />
          <div>
            <p className="text-blue-700 font-medium">
              {processingBatches} {processingBatches === 1 ? 'batch' : 'batches'} er ved at blive behandlet
            </p>
            <p className="text-blue-600 text-sm">
              Tryk på opdater for at se den seneste status
            </p>
          </div>
        </div>
      )}

      {filteredBatches.length === 0 ? (
        <div className="bg-white rounded-lg p-8 text-center">
          <p className="text-gray-500">
            {activeView === 'completed' 
              ? 'Ingen gennemførte VIES valideringer' 
              : 'Ingen igangværende VIES valideringer'}
          </p>
        </div>
      ) : (
        filteredBatches.map((batch) => (
          <div key={batch.id} className="bg-white rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm text-gray-600">{batch.name}</h3>
                  {batch.status === 'processing' && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      <Loader className="h-3 w-3 mr-1 animate-spin" />
                      Behandler
                    </span>
                  )}
                  {batch.status === 'completed' && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      <Check className="h-3 w-3 mr-1" />
                      Gennemført
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-400">{batch.period}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleViewBatchDetails(batch.id)}
                className="flex items-center gap-1 p-2 hover:bg-gray-50 rounded-full"
                title="Vis detaljer"
              >
                <ArrowRight className="h-4 w-4 text-gray-600" />
              </Button>
            </div>
            <div className="text-xs text-gray-400">
              {activeView === 'completed' 
                ? `Gennemført (${getValidatedCount(batch)})` 
                : batch.status === 'processing'
                ? `Behandling påbegyndt (${batch.entries.length})`
                : `Igangværende (${getPendingCount(batch)})`}
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default VatHistoryList;
