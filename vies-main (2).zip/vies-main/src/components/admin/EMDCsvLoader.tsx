
import React, { useState, useRef } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Upload, AlertTriangle } from "lucide-react";
import { emdApi } from '@/services/emdApi';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Alert } from "@/components/ui/alert";
import "../dashboard/styles/ExportButton.css";

interface EMDCsvLoaderProps {
  buttonText?: string;
  onSuccess?: () => void;
}

const EMDCsvLoader: React.FC<EMDCsvLoaderProps> = ({ 
  buttonText = "Upload CSV", 
  onSuccess 
}) => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [entriesCount, setEntriesCount] = useState(0);
  const [processingStatus, setProcessingStatus] = useState('');
  const [error, setError] = useState('');

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setError('');
    
    if (!file.name.endsWith('.csv')) {
      toast({
        title: "Error",
        description: "Please select a CSV file",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    
    try {
      console.log("Processing CSV file:", file.name);
      setProcessingStatus('Analyzing CSV file...');
      
      // Preview entities from CSV
      const result = await emdApi.loadEntitiesFromCsv(file);
      
      // Check if result is an array (entities) or a boolean
      if (Array.isArray(result)) {
        console.log("CSV processing successful, found entities:", result.length);
        setEntriesCount(result.length);
        setIsDialogOpen(true);
      } else if (typeof result === 'boolean') {
        // Handle the case where a boolean might be returned
        console.log("CSV processing completed with status:", result);
        setEntriesCount(0);
        setIsDialogOpen(true);
      }
      
      setProcessingStatus('');
    } catch (error) {
      console.error("CSV processing failed:", error);
      setError('Could not process the CSV file. Please check the format.');
      toast({
        title: "Error",
        description: "Failed to process CSV file",
        variant: "destructive",
      });
    }
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleConfirmUpload = async () => {
    if (!selectedFile) return;
    
    setIsLoading(true);
    setProcessingStatus('Loading and processing CSV file...');
    setError('');
    
    try {
      // The entities are already loaded in the preview step
      toast({
        title: "Success",
        description: `Successfully loaded ${entriesCount} entities from CSV`,
      });
      
      // Close dialog and reset state
      setIsDialogOpen(false);
      setSelectedFile(null);
      
      // Callback to inform parent component
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error("CSV processing error:", error);
      setError('An error occurred while processing the file.');
      toast({
        title: "Error",
        description: "Failed to process the file",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setProcessingStatus('');
    }
  };

  return (
    <>
      <input
        type="file"
        accept=".csv"
        onChange={handleFileChange}
        className="hidden"
        ref={fileInputRef}
      />
      <button
        onClick={() => fileInputRef.current?.click()}
        className="export-button"
      >
        <Upload className="h-4 w-4" />
        <span>{buttonText}</span>
      </button>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm CSV Upload</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="text-sm">
              <p>The file contains {entriesCount} entities for the EMD.</p>
              <p className="mt-2">Do you want to proceed with loading this data?</p>
              {processingStatus && (
                <p className="mt-2 font-medium text-brand">{processingStatus}</p>
              )}
              {error && (
                <Alert variant="destructive" className="mt-2">
                  <AlertTriangle className="h-4 w-4" />
                  <span>{error}</span>
                </Alert>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <button 
              onClick={handleConfirmUpload} 
              disabled={isLoading}
              className="export-button"
            >
              {isLoading ? 'Processing...' : 'Confirm Upload'}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default EMDCsvLoader;
