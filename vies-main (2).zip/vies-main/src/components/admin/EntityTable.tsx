
import React, { useState, useEffect } from "react";
import { EntityMetaData, SortConfigEMD } from "@/types/emd";
import { useToast } from "@/hooks/use-toast";
import { emdApi } from "@/services/emdApi";
import { Table, TableBody, TableCell, TableRow } from "@/components/ui/table";
import EntityTableHeader from "./EntityMetaTable/TableHeader";
import EntityTableRow from "./EntityMetaTable/EntityTableRow";
import { ModifyDialog, NoteDialog } from "./EntityMetaTable/DialogComponents";
import { sortEntities, goodsServicesOptions, taxabilityOptions, potOptions, likelyOptions } from "./EntityMetaTable/utils";
import { getCurrentFormattedDate } from "@/utils/dateUtils";

interface EntityTableProps {
  entities: EntityMetaData[];
  sortConfig: SortConfigEMD | null;
  onSort: (key: keyof EntityMetaData) => void;
  onDataChanged: () => void;
  selectedEntities?: string[];
  onSelectEntity?: (entityId: string, isSelected: boolean) => void;
  onResetEntity?: (entityId: string) => void;
  showResetOption?: boolean;
  onFieldEdit?: (entity: EntityMetaData, fieldName: string) => void;
}

const EntityTable: React.FC<EntityTableProps> = ({ 
  entities, 
  sortConfig, 
  onSort,
  onDataChanged,
  selectedEntities = [],
  onSelectEntity,
  onResetEntity,
  showResetOption = false,
  onFieldEdit
}) => {
  const { toast } = useToast();
  const [isModifyDialogOpen, setIsModifyDialogOpen] = useState(false);
  const [currentEntity, setCurrentEntity] = useState<EntityMetaData | null>(null);
  const [modifiedValues, setModifiedValues] = useState({
    goods_services_manual: "",
    taxability_manual: "",
    pot_indicator_manual: "",
    likely_right_deduct_vat_manual: ""
  });
  const [modifyNote, setModifyNote] = useState("");
  const [currentField, setCurrentField] = useState<string>("goods_services_manual");
  const [isNoteDialogOpen, setIsNoteDialogOpen] = useState(false);
  const [pendingChanges, setPendingChanges] = useState<{entity: EntityMetaData, field: keyof EntityMetaData, value: string} | null>(null);
  
  useEffect(() => {
    if (entities.length > 0) {
      console.log(`EntityTable received ${entities.length} entities`);
      const dustinEntity = entities.find(e => e.vat_no === "26092183");
      if (dustinEntity) {
        console.log("Dustin A/S found in EntityTable data:", dustinEntity);
      } else {
        console.log("Dustin A/S not found in EntityTable data");
      }
    } else {
      console.log("EntityTable received empty entities array");
    }
  }, [entities]);
  
  const fieldOrder = [
    "goods_services_manual",
    "taxability_manual",
    "pot_indicator_manual",
    "likely_right_deduct_vat_manual"
  ];
  
  const handleFieldUpdate = async (entity: EntityMetaData, field: keyof EntityMetaData, value: string, note: string) => {
    try {
      const batchName = getCurrentFormattedDate();
      
      await emdApi.updateEntityField(entity.id, field, value, note, "Thomas Svane Jensen", batchName);
      toast({
        title: "Success",
        description: `Updated ${field} for ${entity.vat_no}`,
      });
      onDataChanged();
      
      if (onFieldEdit) {
        onFieldEdit(entity, field as string);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to update field: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  };

  const handleOpenModifyDialog = (entity: EntityMetaData) => {
    setCurrentEntity(entity);
    setModifiedValues({
      goods_services_manual: entity.goods_services_manual || "",
      taxability_manual: entity.taxability_manual || "",
      pot_indicator_manual: entity.pot_indicator_manual || "",
      likely_right_deduct_vat_manual: entity.likely_right_deduct_vat_manual || ""
    });
    setModifyNote("");
    setCurrentField("goods_services_manual");
    setIsModifyDialogOpen(true);
  };
  
  const handleSendToReview = (entity: EntityMetaData) => {
    setCurrentEntity(entity);
    setModifyNote("");
    setIsNoteDialogOpen(true);
  };
  
  const handleFieldValueChange = (field: string, value: string) => {
    setModifiedValues(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  const handleNextField = () => {
    const currentIndex = fieldOrder.indexOf(currentField);
    if (currentIndex < fieldOrder.length - 1) {
      setCurrentField(fieldOrder[currentIndex + 1]);
    }
  };
  
  const handleSkipField = () => {
    handleNextField();
  };
  
  const handleSendToReviewSubmit = async () => {
    if (!currentEntity || !modifyNote.trim()) {
      toast({
        title: "Note Required",
        description: "Please provide a note explaining the changes",
        variant: "destructive",
      });
      return;
    }
    
    try {
      let changesSubmitted = false;
      
      const batchName = getCurrentFormattedDate();
      
      for (const field of Object.keys(currentEntity) as Array<keyof EntityMetaData>) {
        if (field.endsWith('_manual') && currentEntity[field]) {
          const predictionField = field.replace('_manual', '_prediction') as keyof EntityMetaData;
          const oldValue = currentEntity[predictionField] as string;
          const newValue = currentEntity[field] as string;
          
          if (newValue && newValue !== oldValue) {
            await emdApi.updateEntityField(
              currentEntity.id, 
              field, 
              newValue, 
              modifyNote,
              "Thomas Svane Jensen",
              batchName
            );
            changesSubmitted = true;
          }
        }
      }
      
      if (changesSubmitted) {
        toast({
          title: "Success",
          description: `Changes sent to review for ${currentEntity.vat_no}`,
        });
        onDataChanged();
      } else {
        toast({
          title: "No Changes",
          description: "No changes were detected to send to review",
          variant: "destructive",
        });
      }
      
      setIsNoteDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to send to review: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  };
  
  const handleSendToReviewWithModifiedValues = async () => {
    if (!currentEntity) return;
    
    if (!modifyNote) {
      toast({
        title: "Note Required",
        description: "Please provide a note explaining the changes",
        variant: "destructive",
      });
      return;
    }
    
    const hasChanges = Object.entries(modifiedValues).some(([field, value]) => {
      const oldValue = currentEntity[field as keyof EntityMetaData] as string;
      return value && value !== oldValue;
    });
    
    if (!hasChanges) {
      toast({
        title: "No Changes",
        description: "You need to make at least one change to send to review",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const batchName = getCurrentFormattedDate();
      
      for (const field of fieldOrder) {
        const newValue = modifiedValues[field as keyof typeof modifiedValues];
        const oldValue = currentEntity[field as keyof EntityMetaData] as string;
        
        if (newValue && newValue !== oldValue) {
          await emdApi.updateEntityField(
            currentEntity.id, 
            field as keyof EntityMetaData, 
            newValue, 
            modifyNote,
            "Thomas Svane Jensen",
            batchName
          );
        }
      }
      
      toast({
        title: "Success",
        description: `Changes sent to review for ${currentEntity.vat_no}`,
      });
      
      onDataChanged();
      setIsModifyDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to update fields: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  };

  const handleAddNoteLater = () => {
    if (pendingChanges) {
      handleFieldUpdate(
        pendingChanges.entity, 
        pendingChanges.field, 
        pendingChanges.value,
        "No note input"
      );
      setPendingChanges(null);
    }
    setIsNoteDialogOpen(false);
  };
  
  const handleNoteSubmit = () => {
    if (pendingChanges && modifyNote.trim()) {
      handleFieldUpdate(
        pendingChanges.entity, 
        pendingChanges.field, 
        pendingChanges.value,
        modifyNote
      );
      setPendingChanges(null);
      setIsNoteDialogOpen(false);
    } else if (currentEntity && modifyNote.trim()) {
      handleSendToReviewSubmit();
    } else if (!modifyNote.trim()) {
      toast({
        title: "Note Required",
        description: "Please provide a note explaining the changes",
        variant: "destructive",
      });
    }
  };
  
  const sortedEntities = sortEntities(entities, sortConfig);
  
  return (
    <>
      <div className="rounded-lg border overflow-hidden">
        {entities.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-gray-500">No entities found. {sortedEntities.length === 0 ? "Adjust your search or filters." : ""}</p>
          </div>
        ) : (
          <div className="overflow-auto">
            <Table>
              <EntityTableHeader 
                onSort={onSort} 
                sortConfig={sortConfig} 
                onSelectEntity={onSelectEntity} 
              />
              <TableBody>
                {sortedEntities.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={onSelectEntity ? 9 : 8} className="text-center py-6 text-gray-500">
                      No entities found. Adjust your search or filters.
                    </TableCell>
                  </TableRow>
                ) : (
                  sortedEntities.map(entity => (
                    <EntityTableRow
                      key={entity.id}
                      entity={entity}
                      selectedEntities={selectedEntities}
                      onSelectEntity={onSelectEntity}
                      onResetEntity={onResetEntity}
                      showResetOption={showResetOption}
                      handleFieldUpdate={handleFieldUpdate}
                      onSendToReview={handleSendToReview}
                    />
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
      
      <ModifyDialog
        isOpen={isModifyDialogOpen}
        onOpenChange={setIsModifyDialogOpen}
        currentEntity={currentEntity}
        currentField={currentField}
        modifiedValues={modifiedValues}
        modifyNote={modifyNote}
        setModifyNote={setModifyNote}
        goodsServicesOptions={goodsServicesOptions}
        taxabilityOptions={taxabilityOptions}
        potOptions={potOptions}
        likelyOptions={likelyOptions}
        handleFieldValueChange={handleFieldValueChange}
        handleSkipField={handleSkipField}
        handleNextField={handleNextField}
        handleSendToReview={handleSendToReviewWithModifiedValues}
        fieldOrder={fieldOrder}
      />

      <NoteDialog
        isOpen={isNoteDialogOpen}
        onOpenChange={setIsNoteDialogOpen}
        note={modifyNote}
        setNote={setModifyNote}
        onSubmit={handleNoteSubmit}
        onSkip={handleAddNoteLater}
      />
    </>
  );
};

export default EntityTable;
