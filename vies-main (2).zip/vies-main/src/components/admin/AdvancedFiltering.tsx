import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X, Plus, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

// Define filter field options to match table columns exactly
const FILTER_FIELDS = [
  { id: "vat_no", label: "VAT Number" },
  { id: "unique_clients", label: "Unique clients" },
  { id: "company_name", label: "Company" },
  { id: "country_code", label: "Country code" },
  { id: "goods_services_manual", label: "GS_man" },
  { id: "goods_services_prediction", label: "GS_pre" },
  { id: "taxability_manual", label: "Tax_man" },
  { id: "taxability_prediction", label: "Tax_pre" },
  { id: "pot_indicator_manual", label: "POT_man" },
  { id: "pot_indicator_prediction", label: "POT_pre" },
  { id: "likely_right_deduct_vat_manual", label: "Likely_man" },
  { id: "likely_right_deduct_vat_prediction", label: "Likely_pre" },
  { id: "timestamp", label: "Updated" },
  { id: "note", label: "Notes" },
];

// Predefined value options for select fields
const FIELD_OPTIONS = {
  goods_services_manual: ["Goods", "Services", "Both"],
  goods_services_prediction: ["Goods", "Services", "Both"],
  taxability_manual: ["T", "Ex_no_credit", "Ex_w_credit", "Local_RC", "UsedGoods"],
  taxability_prediction: ["T", "Ex_no_credit", "Ex_w_credit", "Local_RC", "UsedGoods"],
  pot_indicator_manual: [
    "Teleservice", "Broadcasting", "Copyrights_etc", "Advertisement", "Consultants",
    "Engineers", "Accountants", "Lawyers", "Data_processing", "Providing_information",
    "Financial_Services", "Staff_hire", "Leasing_movable_property_no_means_of_transport",
    "Transmission_Services", "Real_Estate", "Passenger_Transport", "Access_to_Events",
    "Restaurant_Catering", "Short_term_rent_means_of_transport", "Intermediary",
    "Goods_transport", "Main Rule", "Electronic Services", "OSS"
  ],
  pot_indicator_prediction: [
    "Teleservice", "Broadcasting", "Copyrights_etc", "Advertisement", "Consultants",
    "Engineers", "Accountants", "Lawyers", "Data_processing", "Providing_information",
    "Financial_Services", "Staff_hire", "Leasing_movable_property_no_means_of_transport",
    "Transmission_Services", "Real_Estate", "Passenger_Transport", "Access_to_Events",
    "Restaurant_Catering", "Short_term_rent_means_of_transport", "Intermediary",
    "Goods_transport", "Main Rule", "Electronic Services", "OSS"
  ],
  likely_right_deduct_vat_manual: [
    "LeasingVehicles", "Restaurant", "MealsForStaff", "EstimatePhone", "EstimateEntertainment",
    "FixedPhoneLine", "CarRelatedExpenses", "NoDeductionEntertainment", "BusinessOrPrivateUse",
    "FullDeduction", "NoDeductionExempt", "NoDeductionFringeBenefits", "NoDeductionGifts"
  ],
  likely_right_deduct_vat_prediction: [
    "LeasingVehicles", "Restaurant", "MealsForStaff", "EstimatePhone", "EstimateEntertainment",
    "FixedPhoneLine", "CarRelatedExpenses", "NoDeductionEntertainment", "BusinessOrPrivateUse",
    "FullDeduction", "NoDeductionExempt", "NoDeductionFringeBenefits", "NoDeductionGifts"
  ],
  country_code: ["DK", "DE", "SE", "NO", "FI", "UK", "US", "FR", "ES", "IT"],
};

export type Filter = {
  id: string;
  field: string;
  value: string;
  operator?: string;
};

interface AdvancedFilteringProps {
  filters: Filter[];
  onAddFilter: (filter: Filter) => void;
  onRemoveFilter: (filterId: string) => void;
  onClearFilters: () => void;
  onApplyFilters: () => void;
  showAdvancedFilters: boolean;
  onToggleAdvancedFilters: () => void;
}

const AdvancedFiltering: React.FC<AdvancedFilteringProps> = ({
  filters,
  onAddFilter,
  onRemoveFilter,
  onClearFilters,
  onApplyFilters,
  showAdvancedFilters,
  onToggleAdvancedFilters,
}) => {
  const [selectedField, setSelectedField] = useState("");
  const [selectedValue, setSelectedValue] = useState("");
  const [customValue, setCustomValue] = useState("");

  const handleAddFilter = () => {
    if (!selectedField) return;
    
    // Determine which value to use based on whether the field has predefined options
    const value = hasOptions(selectedField) ? selectedValue : customValue;
    
    if (!value) return;
    
    onAddFilter({
      id: `${selectedField}_${Date.now()}`,
      field: selectedField,
      value: value,
    });
    
    // Reset selection for next filter
    setSelectedField("");
    setSelectedValue("");
    setCustomValue("");
  };

  const getFieldLabel = (fieldId: string) => {
    const field = FILTER_FIELDS.find(f => f.id === fieldId);
    return field ? field.label : fieldId;
  };

  // Determine if the selected field has predefined options
  const hasOptions = (fieldId: string) => {
    return Object.keys(FIELD_OPTIONS).includes(fieldId);
  };

  // Get options for the selected field
  const getOptions = (fieldId: string) => {
    return FIELD_OPTIONS[fieldId as keyof typeof FIELD_OPTIONS] || [];
  };

  return (
    <div className="space-y-4">
      {/* Display active filters */}
      {filters.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {filters.map((filter) => (
            <Badge
              key={filter.id}
              variant="outline"
              className="flex items-center gap-1 px-3 py-1.5"
            >
              <span className="font-medium">{getFieldLabel(filter.field)}:</span>
              <span>{filter.value}</span>
              <X
                className="h-3.5 w-3.5 ml-1 cursor-pointer"
                onClick={() => onRemoveFilter(filter.id)}
              />
            </Badge>
          ))}
          {filters.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearFilters}
              className="h-7 px-2"
            >
              Clear filters
            </Button>
          )}
        </div>
      )}

      {/* Add new filter interface */}
      {showAdvancedFilters && (
        <div className="flex flex-wrap gap-2 items-center">
          <Select value={selectedField} onValueChange={(value) => {
            setSelectedField(value);
            setSelectedValue("");
            setCustomValue("");
          }}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select filter" />
            </SelectTrigger>
            <SelectContent>
              {FILTER_FIELDS.map((field) => (
                <SelectItem key={field.id} value={field.id}>
                  {field.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {selectedField && (
            <>
              {hasOptions(selectedField) ? (
                <Select value={selectedValue} onValueChange={setSelectedValue}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select value" />
                  </SelectTrigger>
                  <SelectContent>
                    {getOptions(selectedField).map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  type="text"
                  value={customValue}
                  onChange={(e) => setCustomValue(e.target.value)}
                  placeholder="Enter value"
                  className="w-[180px]"
                />
              )}

              <Button
                variant="outline"
                size="sm"
                onClick={handleAddFilter}
                disabled={hasOptions(selectedField) ? !selectedValue : !customValue}
                className="flex items-center gap-1"
              >
                <Plus className="h-4 w-4" />
                Add filter
              </Button>
            </>
          )}

          {filters.length > 0 && (
            <Button onClick={onApplyFilters} size="sm">
              Apply filters
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default AdvancedFiltering;
