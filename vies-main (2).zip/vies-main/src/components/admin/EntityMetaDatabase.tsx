import React, { useState, useCallback, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { EntityMetaData, SortConfigEMD, EntityReviewItem } from "@/types/emd";
import { emdApi } from "@/services/emdApi";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Download, 
  Search, 
  Filter, 
  X,
  AlertTriangle,
  Check,
  RotateCcw,
  Stamp,
  Edit,
  ListChecks,
  List,
  ArrowRight,
  CheckCircle,
  XCircle,
  RefreshCw,
  Upload,
  User,
  MessageSquare,
  ChevronDown
} from "lucide-react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import EntityTable from "./EntityTable";
import AdvancedFiltering, { Filter as FilterType } from "./AdvancedFiltering";
import { useNavigate } from "react-router-dom";
import { StatusBadge } from "../ui/StatusBadge";
import { format } from "date-fns";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";

interface EntityMetaDatabaseProps {
  onError: (errorMsg: string) => void;
  onLoadingChange: (loading: boolean) => void;
  initialEntities?: EntityMetaData[];
}

interface ReviewItemsTableProps {
  items: EntityReviewItem[];
  onApprove: (item: EntityReviewItem) => void;
  onReject: (item: EntityReviewItem) => void;
  formatDate: (date: string) => string;
}

const fieldSequence = [
  "goods_services_manual",
  "taxability_manual",
  "pot_indicator_manual",
  "likely_right_deduct_vat_manual"
];

const fieldNameMapping: Record<string, string> = {
  goods_services_manual: "Goods/Services",
  taxability_manual: "Taxability",
  pot_indicator_manual: "Place of Taxation",
  likely_right_deduct_vat_manual: "Deduction Rights"
};

type ManualInputFilter = "all" | "missing" | "with";

const EntityMetaDatabase: React.FC<EntityMetaDatabaseProps> = ({ 
  onError, 
  onLoadingChange,
  initialEntities = []
}) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [localSearchTerm, setLocalSearchTerm] = useState("");
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [filters, setFilters] = useState<FilterType[]>([]);
  const [activeTab, setActiveTab] = useState("database");
  const [sortConfig, setSortConfig] = useState<SortConfigEMD>({ 
    key: "unique_clients", 
    direction: "descending" 
  });
  const [selectedEntities, setSelectedEntities] = useState<string[]>([]);
  const [showChangeDialog, setShowChangeDialog] = useState(false);
  const [currentEntity, setCurrentEntity] = useState<EntityMetaData | null>(null);
  const [currentField, setCurrentField] = useState<string>("");
  const [isSearching, setIsSearching] = useState(false);
  const [manualInputFilter, setManualInputFilter] = useState<ManualInputFilter>("all");
  
  const [reviewItems, setReviewItems] = useState<EntityReviewItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<EntityReviewItem | null>(null);
  const [feedbackNote, setFeedbackNote] = useState("");
  const [isApproving, setIsApproving] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [reviewFilter, setReviewFilter] = useState<"all" | "pending" | "rejected" | "ready-for-push">("all");
  const [currentBatch, setCurrentBatch] = useState<{id: string, name: string} | null>(null);
  const [batches, setBatches] = useState<{id: string, name: string}[]>([]);
  const [pushedBatches, setPushedBatches] = useState<{id: string, datePushed: string, entityCount: number, status: string}[]>([]);
  const [pushDialogOpen, setPushDialogOpen] = useState(false);

  useEffect(() => {
    const fetchBatches = async () => {
      try {
        const response = await fetch(`${emdApi.getApiUrl()}/batches`);
        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data) && data.length > 0) {
            const formattedBatches = data.map((batch: any) => ({
              id: batch.id || `batch-${Math.random().toString(36).substr(2, 9)}`,
              name: batch.name || `Batch ${new Date(batch.created_at || Date.now()).toLocaleDateString()}`
            }));
            setBatches(formattedBatches);
            if (formattedBatches.length > 0) {
              setCurrentBatch(formattedBatches[0]);
            }
          }
        }
      } catch (error) {
        console.error("Error fetching batches:", error);
      }
    };
    
    fetchBatches();
  }, []);

  useEffect(() => {
    const fetchReviewItems = async () => {
      try {
        if (!currentBatch) return;
        
        const response = await fetch(`${emdApi.getApiUrl()}/review-items?batchId=${currentBatch.id}`);
        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data)) {
            setReviewItems(data);
          }
        }
      } catch (error) {
        console.error("Error fetching review items:", error);
      }
    };
    
    if (currentBatch) {
      fetchReviewItems();
    }
  }, [currentBatch]);

  useEffect(() => {
    const fetchPushedBatches = async () => {
      try {
        const response = await fetch(`${emdApi.getApiUrl()}/pushed-batches`);
        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data)) {
            setPushedBatches(data);
          }
        }
      } catch (error) {
        console.error("Error fetching pushed batches:", error);
        setPushedBatches([]);
      }
    };
    
    fetchPushedBatches();
  }, []);

  const goToReviewPanel = () => {
    setActiveTab("review-panel");
  };

  const { 
    data: allEntities = initialEntities, 
    isLoading: isLoadingAll, 
    isError: isErrorAll,
    refetch: refetchAll
  } = useQuery({
    queryKey: ['emd-entities', searchTerm, JSON.stringify(filters)],
    queryFn: () => emdApi.fetchFilteredEntities(searchTerm, filters),
    initialData: initialEntities,
    staleTime: 5 * 60 * 1000,
    retry: 2,
    meta: {
      onError: (err: Error) => {
        toast({
          title: "Error",
          description: `Failed to load entities: ${err.message}`,
          variant: "destructive",
        });
        onError(`Failed to load entities: ${err.message}`);
      }
    }
  });

  useEffect(() => {
    onLoadingChange(isLoadingAll);
  }, [isLoadingAll, onLoadingChange]);

  useEffect(() => {
    if (isErrorAll) {
      onError("Failed to fetch entity data. Please try again later.");
    }
  }, [isErrorAll, onError]);

  const filterByManualInput = useCallback((entities: EntityMetaData[]) => {
    if (manualInputFilter === "all") {
      return entities;
    }
    
    return entities.filter(entity => {
      const hasManualInput = 
        !!entity.goods_services_manual || 
        !!entity.taxability_manual || 
        !!entity.pot_indicator_manual || 
        !!entity.likely_right_deduct_vat_manual;
      
      return manualInputFilter === "with" ? hasManualInput : !hasManualInput;
    });
  }, [manualInputFilter]);

  const entities = React.useMemo(() => {
    let filteredEntities;
    
    switch (activeTab) {
      case "database":
        filteredEntities = allEntities.filter(entity => !entity.pendingReview);
        break;
      case "review-panel":
        filteredEntities = allEntities.filter(entity => entity.pendingReview);
        break;
      case "pushed":
        filteredEntities = allEntities.filter(entity => entity.pushed);
        break;
      default:
        filteredEntities = [];
    }
    
    return filterByManualInput(filteredEntities);
  }, [activeTab, allEntities, filterByManualInput]);

  const pendingReviewCount = allEntities.filter(entity => entity.pendingReview).length;

  const handleSort = (key: keyof EntityMetaData) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    
    if (sortConfig?.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    
    setSortConfig({ key, direction });
  };

  const handleAddFilter = useCallback((filter: FilterType) => {
    setFilters(prev => [...prev, filter]);
  }, []);

  const handleRemoveFilter = useCallback((filterId: string) => {
    setFilters(prev => prev.filter(filter => filter.id !== filterId));
  }, []);

  const clearFilters = useCallback(() => {
    setLocalSearchTerm("");
    setSearchTerm("");
    setFilters([]);
    queryClient.invalidateQueries({ queryKey: ['emd-entities'] });
  }, [queryClient]);

  const applyFilters = useCallback(() => {
    setIsSearching(true);
    setSearchTerm(localSearchTerm);
    console.log("Applying filters:", {
      searchTerm: localSearchTerm,
      advancedFilters: filters
    });
    
    refetchAll().finally(() => {
      setIsSearching(false);
    });
  }, [localSearchTerm, filters, refetchAll]);

  const handleResetEntity = async (entityId: string) => {
    try {
      await emdApi.resetEntityChanges(entityId);
      toast({
        title: "Success",
        description: "Entity changes have been reset",
      });
      
      await queryClient.invalidateQueries({ queryKey: ['emd-entities'] });
      
      if (activeTab === "review-panel") {
        const remainingPending = allEntities.filter(e => 
          e.id !== entityId && e.pendingReview
        );
        
        if (remainingPending.length === 0) {
          setActiveTab("database");
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reset entity changes",
        variant: "destructive",
      });
    }
  };

  const handleSendToReview = () => {
    toast({
      title: "Success",
      description: "Changes have been sent to the Review Panel",
    });
    
    if (currentEntity) {
      queryClient.invalidateQueries({ queryKey: ['emd-entities'] });
    }
    
    setCurrentEntity(null);
    setCurrentField("");
    setShowChangeDialog(false);
  };

  const getNextField = (currentFieldName: string): string | null => {
    const currentIndex = fieldSequence.indexOf(currentFieldName);
    if (currentIndex < 0 || currentIndex >= fieldSequence.length - 1) {
      return null;
    }
    return fieldSequence[currentIndex + 1];
  };

  const handleChangeMore = () => {
    if (!currentEntity || !currentField) return;
    
    const nextField = getNextField(currentField);
    if (nextField) {
      setCurrentField(nextField);
    } else {
      handleSendToReview();
    }
  };

  const handleSkip = () => {
    if (!currentEntity || !currentField) return;
    
    const nextField = getNextField(currentField);
    if (nextField) {
      setCurrentField(nextField);
    } else {
      handleSendToReview();
    }
  };

  const handleFieldEdit = (entity: EntityMetaData, fieldName: string) => {
    setCurrentEntity(entity);
    setCurrentField(fieldName);
    setShowChangeDialog(true);
  };

  const handleExportCsv = async () => {
    try {
      const csvContent = await emdApi.exportEntitiesToCsv(entities);
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `entity-meta-database-${new Date().toISOString().slice(0,10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Success",
        description: `Successfully exported ${entities.length} entities to CSV`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export CSV file",
        variant: "destructive",
      });
    }
  };

  const handleRefreshReviewItems = async () => {
    try {
      if (!currentBatch) return;
      
      const response = await fetch(`${emdApi.getApiUrl()}/review-items?batchId=${currentBatch.id}`);
      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data)) {
          setReviewItems(data);
          toast({
            title: "Success",
            description: "Review items refreshed successfully",
          });
        }
      } else {
        toast({
          title: "Error",
          description: "Failed to refresh review items",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to refresh review items",
        variant: "destructive",
      });
    }
  };

  const handleApprove = (item: EntityReviewItem) => {
    setSelectedItem(item);
    setFeedbackNote("");
    setIsApproving(true);
    setIsRejecting(false);
    setIsDialogOpen(true);
  };
  
  const handleReject = (item: EntityReviewItem) => {
    setSelectedItem(item);
    setFeedbackNote("");
    setIsApproving(false);
    setIsRejecting(true);
    setIsDialogOpen(true);
  };
  
  const submitFeedback = async () => {
    if (!selectedItem) return;
    
    try {
      const action = isApproving ? "approve" : "reject";
      const response = await fetch(`${emdApi.getApiUrl()}/review-items/${selectedItem.entityId}/${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ feedback: feedbackNote }),
      });
      
      if (response.ok) {
        toast({
          title: isApproving ? "Changes Approved" : "Changes Rejected",
          description: `${selectedItem.company_name} (${selectedItem.vat_no}) - ${feedbackNote}`,
        });
        
        setReviewItems(items => 
          items.map(item => {
            if (item.entityId === selectedItem.entityId) {
              return {
                ...item,
                status: isApproving ? "approved" : "rejected",
                feedbackNote: feedbackNote
              };
            }
            return item;
          })
        );
      } else {
        toast({
          title: "Error",
          description: `Failed to ${action} changes`,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to submit feedback: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
    
    setIsDialogOpen(false);
  };
  
  const formatDate = (dateString?: string) => {
    if (!dateString) return "";
    try {
      return format(new Date(dateString), "dd/MM/yyyy HH:mm");
    } catch (error) {
      return dateString;
    }
  };
  
  const filteredReviewItems = reviewItems.filter(item => {
    if (reviewFilter === "all") return true;
    if (reviewFilter === "pending") return item.status === "pending";
    if (reviewFilter === "rejected") return item.status === "rejected";
    if (reviewFilter === "ready-for-push") return item.status === "approved";
    
    return true;
  });
  
  const tabCounts = {
    all: reviewItems.length,
    pending: reviewItems.filter(item => item.status === "pending").length,
    rejected: reviewItems.filter(item => item.status === "rejected").length,
    readyForPush: reviewItems.filter(item => item.status === "approved").length
  };
  
  const handlePush = async () => {
    try {
      const approvedItems = reviewItems.filter(item => item.status === "approved");
      
      const response = await fetch(`${emdApi.getApiUrl()}/push-changes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          items: approvedItems.map(item => item.entityId),
          batchId: currentBatch?.id
        }),
      });
      
      if (response.ok) {
        toast({
          title: "Changes Pushed Successfully",
          description: `${approvedItems.length} changes have been successfully pushed to the database.`,
        });
        
        setReviewItems(items => 
          items.map(item => {
            if (item.status === "approved") {
              return { ...item, status: "pushed" };
            }
            return item;
          })
        );
      } else {
        toast({
          title: "Error",
          description: "Failed to push changes to the database",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to push changes: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
    
    setPushDialogOpen(false);
  };
  
  const handleExport = () => {
    try {
      let csvContent = "data:text/csv;charset=utf-8,";
      csvContent += "Entity ID,VAT Number,Company Name,Field,Old Value,New Value,Note,Status\n";
      
      reviewItems.forEach(item => {
        item.changes.forEach(change => {
          csvContent += `${item.entityId},${item.vat_no},${item.company_name},${change.field},${change.oldValue || ''},${change.newValue || ''},${item.note || ''},${item.status}\n`;
        });
      });
      
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `review-data-${new Date().toISOString().slice(0,10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Exporting Review Data",
        description: "The review data has been exported to CSV.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export review data to CSV.",
        variant: "destructive",
      });
    }
  };
  
  const handleBatchChange = (batchId: string) => {
    const batch = batches.find(b => b.id === batchId);
    if (batch) {
      setCurrentBatch(batch);
    }
  };

  const getFieldLabel = (fieldName: string): string => {
    return fieldNameMapping[fieldName] || fieldName;
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-semibold">Existing entities</h2>
          {pendingReviewCount > 0 && (
            <div className="text-sm text-amber-600 flex items-center mt-1">
              <Edit size={14} className="mr-1" />
              {pendingReviewCount} {pendingReviewCount === 1 ? 'entity' : 'entities'} pending review
            </div>
          )}
        </div>
        <div className="flex gap-2">
          {pendingReviewCount > 0 && (
            <Button
              variant="outline"
              onClick={goToReviewPanel}
              className="flex items-center gap-2"
            >
              <Check className="h-4 w-4" />
              Review Panel
            </Button>
          )}
          <Button 
            onClick={handleExportCsv} 
            variant="outline"
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Export CSV
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="w-full justify-start mb-4">
          <TabsTrigger value="database" className="px-6">Database</TabsTrigger>
          <TabsTrigger value="review-panel" className="px-6">
            Review Panel
            {pendingReviewCount > 0 && (
              <span className="ml-2 bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full text-xs">
                {pendingReviewCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="pushed" className="px-6">
            Pushed Corrections
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="database" className="mt-0">
          <div className="mb-6">
            <div className="flex flex-col gap-3">
              <div className="flex gap-2">
                <div className="relative grow">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input 
                    placeholder="Search by VAT number or company name" 
                    value={localSearchTerm}
                    onChange={(e) => setLocalSearchTerm(e.target.value)}
                    className="pl-10"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        applyFilters();
                      }
                    }}
                  />
                </div>
                <Button 
                  variant="default" 
                  onClick={applyFilters}
                  disabled={isSearching}
                  className="flex items-center gap-2"
                >
                  {isSearching ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  ) : (
                    <Search className="h-4 w-4" />
                  )}
                  Search
                </Button>
                {(searchTerm || filters.length > 0) && (
                  <Button 
                    variant="ghost" 
                    onClick={clearFilters}
                    className="flex items-center gap-2"
                  >
                    <X className="h-4 w-4" />
                    Clear
                  </Button>
                )}
              </div>
              
              <div className="flex justify-between items-center gap-4">
                <ToggleGroup 
                  type="single" 
                  value={manualInputFilter} 
                  onValueChange={(value) => {
                    if (value) setManualInputFilter(value as ManualInputFilter);
                  }}
                  className="border rounded-md"
                >
                  <ToggleGroupItem value="all" className="px-3 py-1.5 text-xs h-auto data-[state=on]:bg-indigo-100 data-[state=on]:text-indigo-800">
                    <List className="h-3.5 w-3.5 mr-1.5" />
                    Show All
                  </ToggleGroupItem>
                  <ToggleGroupItem value="missing" className="px-3 py-1.5 text-xs h-auto data-[state=on]:bg-amber-100 data-[state=on]:text-amber-800">
                    <ListChecks className="h-3.5 w-3.5 mr-1.5" />
                    Missing Manual Input
                  </ToggleGroupItem>
                  <ToggleGroupItem value="with" className="px-3 py-1.5 text-xs h-auto data-[state=on]:bg-green-100 data-[state=on]:text-green-800">
                    <Check className="h-3.5 w-3.5 mr-1.5" />
                    With Manual Input
                  </ToggleGroupItem>
                </ToggleGroup>
                
                <Button 
                  variant="outline" 
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  className="flex items-center gap-2"
                >
                  <Filter className="h-4 w-4" />
                  {showAdvancedFilters ? "Hide Filters" : "Show Advanced Filters"}
                </Button>
              </div>

              <AdvancedFiltering 
                filters={filters}
                onAddFilter={handleAddFilter}
                onRemoveFilter={handleRemoveFilter}
                onClearFilters={() => setFilters([])}
                onApplyFilters={applyFilters}
                showAdvancedFilters={showAdvancedFilters}
                onToggleAdvancedFilters={() => setShowAdvancedFilters(!showAdvancedFilters)}
              />
            </div>
          </div>

          {isLoadingAll && !isSearching ? (
            <div className="flex justify-center py-10">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-500"></div>
            </div>
          ) : isErrorAll ? (
            <div className="p-8 text-center text-red-500 bg-red-50 rounded-lg">
              <AlertTriangle className="mx-auto h-8 w-8 mb-2" />
              <p>Der opstod en fejl under indlæsning af data.</p>
              <p className="text-sm mt-2">Prøv at genindlæse siden, eller kontakt support hvis problemet fortsætter.</p>
            </div>
          ) : entities.length === 0 ? (
            <div className="p-12 text-center bg-gray-50 rounded-lg">
              <p className="text-gray-500">Nothing found. Adjust your filters to see results.</p>
            </div>
          ) : (
            <div className="min-h-[400px]">
              <div className="mb-2 text-right text-sm text-gray-500">
                Showing {entities.length} {entities.length === 1 ? 'entity' : 'entities'}
              </div>
              <EntityTable 
                entities={entities}
                sortConfig={sortConfig}
                onSort={handleSort}
                onDataChanged={() => {
                  queryClient.invalidateQueries({ queryKey: ['emd-entities'] });
                }}
                onResetEntity={handleResetEntity}
                showResetOption={true}
                onFieldEdit={handleFieldEdit}
              />
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="review-panel" className="mt-0">
          <Card>
            <CardHeader className="text-left">
              <CardTitle className="text-xl font-semibold">Review Panel</CardTitle>
              <CardDescription>
                Review and approve or reject changes made to entity classifications
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-3">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="flex items-center gap-2">
                        <span>Batch: {currentBatch?.name || "No batch selected"}</span>
                        <ChevronDown className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      {batches.map(batch => (
                        <DropdownMenuItem 
                          key={batch.id}
                          onClick={() => handleBatchChange(batch.id)}
                        >
                          {batch.name}
                        </DropdownMenuItem>
                      ))}
                      {batches.length === 0 && (
                        <DropdownMenuItem disabled>
                          No batches available
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                  
                  <Button 
                    variant="outline" 
                    onClick={handleRefreshReviewItems} 
                    className="flex items-center gap-2"
                  >
                    <RefreshCw className="h-4 w-4" />
                    Refresh
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={handleExport}
                    className="flex items-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Export
                  </Button>
                </div>
                
                {reviewFilter === "ready-for-push" && (
                  <Button 
                    variant="default" 
                    onClick={() => setPushDialogOpen(true)}
                    className="flex items-center gap-2"
                    disabled={reviewItems.filter(item => item.status === "approved").length === 0}
                  >
                    <Upload className="h-4 w-4" />
                    Push Changes
                  </Button>
                )}
              </div>

              <Tabs defaultValue="all" className="mb-6" value={reviewFilter} onValueChange={(value) => setReviewFilter(value as any)}>
                <TabsList className="grid grid-cols-4 w-full mb-4">
                  <TabsTrigger value="all">
                    All {tabCounts.all > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{tabCounts.all}</span>}
                  </TabsTrigger>
                  <TabsTrigger value="pending">
                    Pending {tabCounts.pending > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{tabCounts.pending}</span>}
                  </TabsTrigger>
                  <TabsTrigger value="rejected">
                    Rejected {tabCounts.rejected > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{tabCounts.rejected}</span>}
                  </TabsTrigger>
                  <TabsTrigger value="ready-for-push">
                    Ready for Push {tabCounts.readyForPush > 0 && <span className="ml-1 text-xs px-1.5 py-0.5 bg-gray-100 rounded-full">{tabCounts.readyForPush}</span>}
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="all">
                  {filteredReviewItems.length === 0 ? (
                    <div className="p-12 text-left bg-gray-50 rounded-lg">
                      <CheckCircle className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500 text-center">No items to review in this batch</p>
                    </div>
                  ) : (
                    <ReviewItemsTable 
                      items={filteredReviewItems} 
                      onApprove={handleApprove} 
                      onReject={handleReject} 
                      formatDate={formatDate}
                    />
                  )}
                </TabsContent>
                
                <TabsContent value="pending">
                  {filteredReviewItems.length === 0 ? (
                    <div className="p-12 text-left bg-gray-50 rounded-lg">
                      <CheckCircle className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500 text-center">No pending items to review in this batch</p>
                    </div>
                  ) : (
                    <ReviewItemsTable 
                      items={filteredReviewItems} 
                      onApprove={handleApprove} 
                      onReject={handleReject} 
                      formatDate={formatDate}
                    />
                  )}
                </TabsContent>
                
                <TabsContent value="rejected">
                  {filteredReviewItems.length === 0 ? (
                    <div className="p-12 text-left bg-gray-50 rounded-lg">
                      <XCircle className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500 text-center">No rejected items to display in this batch</p>
                    </div>
                  ) : (
                    <ReviewItemsTable 
                      items={filteredReviewItems} 
                      onApprove={handleApprove} 
                      onReject={handleReject} 
                      formatDate={formatDate}
                    />
                  )}
                </TabsContent>
                
                <TabsContent value="ready-for-push">
                  {filteredReviewItems.length === 0 ? (
                    <div className="p-12 text-left bg-gray-50 rounded-lg">
                      <Upload className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500 text-center">No items ready to push in this batch</p>
                    </div>
                  ) : (
                    <ReviewItemsTable 
                      items={filteredReviewItems} 
                      onApprove={handleApprove} 
                      onReject={handleReject} 
                      formatDate={formatDate}
                    />
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pushed" className="mt-0">
          <div className="overflow-x-auto rounded-md border">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Batch ID
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date Pushed
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Entities
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {pushedBatches.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                      No pushed batches found.
                    </td>
                  </tr>
                ) : (
                  pushedBatches.map((batch) => (
                    <tr key={batch.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {batch.id}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {batch.datePushed}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {batch.entityCount}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          batch.status === 'Pushed' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {batch.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <Button variant="ghost" size="sm">View Details</Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={showChangeDialog} onOpenChange={setShowChangeDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              Field Edit: {currentEntity?.company_name}
            </DialogTitle>
            <DialogDescription>
              You are editing the {getFieldLabel(currentField)} field.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2 text-left">
            <div className="text-sm">
              <p>What would you like to do next?</p>
            </div>
          </div>
          <DialogFooter className="sm:justify-between flex-wrap gap-2">
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={handleSkip}
                className="flex-1"
              >
                Skip
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={handleChangeMore}
                className="flex-1"
              >
                Change More
                <Edit className="ml-2 h-4 w-4" />
              </Button>
            </div>
            <Button
              type="button"
              variant="brand"
              onClick={handleSendToReview}
              className="flex-1"
            >
              Send to Review
              <Check className="ml-2 h-4 w-4" />
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {isApproving ? "Approve Changes" : "Reject Changes"}
            </DialogTitle>
            <DialogDescription>
              {isApproving 
                ? "The changes will be marked as approved and can be pushed to the database later."
                : "The changes will be rejected and sent back to the editor for review."
              }
            </DialogDescription>
          </DialogHeader>
          
          {selectedItem && (
            <div className="space-y-4 py-2 text-left">
              <div className="flex flex-col space-y-1.5">
                <label className="text-sm font-medium">Company</label>
                <div className="font-medium">{selectedItem.company_name}</div>
                <div className="text-sm text-gray-500">{selectedItem.vat_no}</div>
              </div>
              
              <div className="flex flex-col space-y-1.5">
                <label className="text-sm font-medium">Changes</label>
                <div className="border rounded-md p-2">
                  {selectedItem.changes.map((change, index) => (
                    <div key={index} className="mb-2 last:mb-0">
                      <div className="text-sm">{fieldNameMapping[change.field] || change.field}</div>
                      <div className="flex items-center text-sm">
                        <span className="line-through text-gray-500 mr-2">
                          {change.oldValue || '(empty)'}
                        </span>
                        <ArrowRight className="h-3 w-3 text-gray-400 mx-1" />
                        <span className="text-blue-600 font-medium">
                          {change.newValue || '(empty)'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex flex-col space-y-1.5">
                <label className="text-sm font-medium">Editor's Note</label>
                <div className="text-sm text-gray-700">
                  {selectedItem.note || "(No note provided)"}
                </div>
              </div>
              
              <div className="flex flex-col space-y-1.5">
                <label htmlFor="feedback" className="text-sm font-medium">
                  Your Feedback {isRejecting && <span className="text-red-500">*</span>}
                </label>
                <Textarea
                  id="feedback"
                  placeholder={isRejecting ? "Please provide a reason for rejection..." : "Add your comments here (optional)"}
                  value={feedbackNote}
                  onChange={(e) => setFeedbackNote(e.target.value)}
                  className="min-h-[80px]"
                  required={isRejecting}
                />
                {isRejecting && !feedbackNote && (
                  <p className="text-xs text-red-500">Feedback is required when rejecting changes.</p>
                )}
              </div>
            </div>
          )}
          
          <DialogFooter className="sm:justify-end">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setIsDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant={isApproving ? "default" : "destructive"}
              onClick={submitFeedback}
              disabled={!selectedItem || (isRejecting && !feedbackNote)}
            >
              {isApproving ? "Approve" : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={pushDialogOpen} onOpenChange={setPushDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Push Approved Changes</DialogTitle>
            <DialogDescription>
              This action will push all approved changes to the database. This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 text-left">
            <p className="text-sm text-gray-500">
              {reviewItems.filter(item => item.status === "approved").length} changes will be pushed.
            </p>
          </div>
          
          <DialogFooter>
            <Button
              type="button"
              variant="secondary"
              onClick={() => setPushDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="default"
              onClick={handlePush}
            >
              Push Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const ReviewItemsTable: React.FC<ReviewItemsTableProps> = ({ 
  items, 
  onApprove, 
  onReject, 
  formatDate 
}) => {
  return (
    <div className="rounded-lg border overflow-hidden">
      <div className="overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[300px] text-left">Company</TableHead>
              <TableHead className="min-w-[350px] text-left">Changes</TableHead>
              <TableHead className="w-[120px] text-left">Submitted By</TableHead>
              <TableHead className="w-[200px] text-left">Note</TableHead>
              <TableHead className="w-[100px] text-left">Status</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((item) => (
              <TableRow key={item.entityId}>
                <TableCell className="align-top">
                  <div style={{ fontSize: "10px" }} className="font-medium text-left">{item.company_name}</div>
                  <div className="text-xs text-gray-500 text-left">{item.vat_no}</div>
                </TableCell>
                <TableCell className="align-top">
                  {item.changes.map((change, index) => (
                    <div key={index} className="mb-2 last:mb-0 text-left">
                      <div className="flex items-center justify-between mb-1">
                        <Badge variant="outline" className="mr-1 text-xs">
                          {fieldNameMapping[change.field] || change.field}
                        </Badge>
                      </div>
                      <div className="flex items-center text-sm">
                        <span className="line-through text-gray-500 mr-2">
                          {change.oldValue || '(empty)'}
                        </span>
                        <ArrowRight className="h-3 w-3 text-gray-400 mx-1" />
                        <span className="text-blue-600 font-medium">
                          {change.newValue || '(empty)'}
                        </span>
                      </div>
                    </div>
                  ))}
                </TableCell>
                <TableCell className="align-top">
                  <div className="flex items-center text-left">
                    <User className="h-3 w-3 mr-1 text-gray-400" />
                    <span className="text-xs">{item.vhat_person}</span>
                  </div>
                </TableCell>
                <TableCell className="align-top">
                  <div className="text-xs text-gray-700 text-left">{item.note || "(No note provided)"}</div>
                  {item.feedbackNote && (
                    <div className="mt-1 text-xs text-gray-500 text-left">
                      <span className="font-medium">Feedback:</span> {item.feedbackNote}
                    </div>
                  )}
                </TableCell>
                <TableCell className="align-top text-left">
                  {item.status === "pending" && (
                    <Badge variant="outline" className="bg-yellow-50 text-yellow-700 hover:bg-yellow-50">
                      Pending
                    </Badge>
                  )}
                  {item.status === "rejected" && (
                    <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-50">
                      Rejected
                    </Badge>
                  )}
                  {item.status === "approved" && (
                    <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                      Approved
                    </Badge>
                  )}
                  {item.status === "pushed" && (
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 hover:bg-blue-50">
                      Pushed
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right align-top">
                  <div className="flex justify-end space-x-2">
                    {item.status === "pending" && (
                      <>
                        <Button 
                          onClick={() => onApprove(item)} 
                          variant="ghost" 
                          size="sm"
                          className="h-8 w-8 p-0 text-green-600"
                        >
                          <CheckCircle className="h-4 w-4" />
                          <span className="sr-only">Approve</span>
                        </Button>
                        <Button 
                          onClick={() => onReject(item)} 
                          variant="ghost" 
                          size="sm"
                          className="h-8 w-8 p-0 text-red-600"
                        >
                          <XCircle className="h-4 w-4" />
                          <span className="sr-only">Reject</span>
                        </Button>
                      </>
                    )}
                    {item.status === "rejected" && (
                      <Button 
                        onClick={() => onApprove(item)} 
                        variant="ghost" 
                        size="sm"
                        className="h-8 w-8 p-0 text-blue-600"
                      >
                        <RefreshCw className="h-4 w-4" />
                        <span className="sr-only">Reconsider</span>
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default EntityMetaDatabase;
