
import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Database, FilePlus } from "lucide-react";
import { NavigationMenu, NavigationMenuContent, NavigationMenuItem, NavigationMenuLink, NavigationMenuList, NavigationMenuTrigger, navigationMenuTriggerStyle } from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils";
import StatusBadge from "@/components/ui/StatusBadge";
import { emdApi } from "@/services/emdApi";

const EntityMetaNavigation: React.FC = () => {
  const location = useLocation();
  const [pendingReviewCount, setPendingReviewCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchPendingReviewCount = async () => {
      try {
        setIsLoading(true);
        // Updated to match the signature of fetchFilteredEntities
        const entities = await emdApi.fetchFilteredEntities("", [
          { id: "status-filter", field: "pendingReview", operator: "equals", value: true }
        ]);
        setPendingReviewCount(entities.length);
      } catch (error) {
        console.error("Error fetching pending review count:", error);
        setPendingReviewCount(0);
      } finally {
        setIsLoading(false);
      }
    };
    fetchPendingReviewCount();

    // Refresh the count every 30 seconds
    const intervalId = setInterval(fetchPendingReviewCount, 30000);
    return () => clearInterval(intervalId);
  }, []);

  return <div className="mb-6">
      <NavigationMenu>
        <NavigationMenuList>
          <NavigationMenuItem>
            <NavigationMenuLink asChild>
              <Link to="/admin/emd" className={cn(navigationMenuTriggerStyle(), "flex items-center gap-2", location.pathname === "/admin/emd" && "bg-indigo-50 text-indigo-700 hover:bg-indigo-100")}>
                <Database className="w-4 h-4" />
                <span>Entity meta data</span>
              </Link>
            </NavigationMenuLink>
          </NavigationMenuItem>
          
          <NavigationMenuItem>
            <NavigationMenuLink asChild>
              <Link to="/admin/emd/pre" className={cn(navigationMenuTriggerStyle(), "flex items-center gap-2 relative", location.pathname === "/admin/emd/pre" && "bg-indigo-50 text-indigo-700 hover:bg-indigo-100")}>
                <FilePlus className="w-4 h-4" />
                <span>New entities</span>
                {pendingReviewCount > 0 && !isLoading && <StatusBadge variant="count" className="ml-1 absolute -top-1 -right-1">
                    {pendingReviewCount}
                  </StatusBadge>}
                {isLoading && <span className="ml-1 w-5 h-5 rounded-full bg-gray-200 animate-pulse"></span>}
              </Link>
            </NavigationMenuLink>
          </NavigationMenuItem>
        </NavigationMenuList>
      </NavigationMenu>
    </div>;
};

export default EntityMetaNavigation;
