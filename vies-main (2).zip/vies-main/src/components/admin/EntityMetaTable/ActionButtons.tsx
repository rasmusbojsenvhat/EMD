
import React from "react";
import { EntityMetaData } from "@/types/emd";
import { Button } from "@/components/ui/button";
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { CheckCircle, RotateCcw, FileText } from "lucide-react";

interface ActionButtonsProps {
  entity: EntityMetaData;
  hasChanges: boolean;
  showResetOption: boolean;
  pendingReview: boolean;
  hasNote: boolean;
  onSendToReview?: (entity: EntityMetaData) => void;
  onResetEntity?: (entityId: string) => void;
  noTooltip?: boolean;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({
  entity,
  hasChanges,
  showResetOption,
  pendingReview,
  hasNote,
  onSendToReview,
  onResetEntity,
  noTooltip = false
}) => {
  if (noTooltip) {
    return (
      <div className="flex flex-col gap-2">
        {hasChanges && onSendToReview && !pendingReview && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => onSendToReview(entity)}
            className="h-8 w-8 p-0 text-green-500 hover:text-green-700"
          >
            <CheckCircle className="h-4 w-4" />
            <span className="sr-only">Send to Review</span>
          </Button>
        )}
        {showResetOption && hasChanges && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => onResetEntity && onResetEntity(entity.id)}
            className="h-8 w-8 p-0 text-gray-500 hover:text-red-500"
          >
            <RotateCcw className="h-4 w-4" />
            <span className="sr-only">Reset</span>
          </Button>
        )}
        {hasNote && (
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 w-8 p-0 text-purple-500 hover:text-purple-700"
          >
            <FileText className="h-4 w-4" />
            <span className="sr-only">View Notes</span>
          </Button>
        )}
      </div>
    );
  }
  
  return (
    <div className="flex flex-col gap-2">
      {hasChanges && onSendToReview && !pendingReview && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => onSendToReview(entity)}
                className="h-8 w-8 p-0 text-green-500 hover:text-green-700"
              >
                <CheckCircle className="h-4 w-4" />
                <span className="sr-only">Send to Review</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Send to Review</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
      {showResetOption && hasChanges && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => onResetEntity && onResetEntity(entity.id)}
                className="h-8 w-8 p-0 text-gray-500 hover:text-red-500"
              >
                <RotateCcw className="h-4 w-4" />
                <span className="sr-only">Reset</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Reset Manual Values</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
      {hasNote && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0 text-purple-500 hover:text-purple-700"
              >
                <FileText className="h-4 w-4" />
                <span className="sr-only">View Notes</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>View Notes</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  );
};

export default ActionButtons;
