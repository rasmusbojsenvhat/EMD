
import React from "react";
import { X, CheckCircle, FileText, Send } from "lucide-react";
import { EntityMetaData } from "@/types/emd";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface ModifyDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  currentEntity: EntityMetaData | null;
  currentField: string;
  modifiedValues: Record<string, string>;
  modifyNote: string;
  setModifyNote: (note: string) => void;
  goodsServicesOptions: string[];
  taxabilityOptions: string[];
  potOptions: string[];
  likelyOptions: string[];
  handleFieldValueChange: (field: string, value: string) => void;
  handleSkipField: () => void;
  handleNextField: () => void;
  handleSendToReview: () => void;
  fieldOrder: string[];
}

export const ModifyDialog: React.FC<ModifyDialogProps> = ({
  isOpen,
  onOpenChange,
  currentEntity,
  currentField,
  modifiedValues,
  modifyNote,
  setModifyNote,
  goodsServicesOptions,
  taxabilityOptions,
  potOptions,
  likelyOptions,
  handleFieldValueChange,
  handleSkipField,
  handleNextField,
  handleSendToReview,
  fieldOrder
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            <div className="flex items-center">
              <FileText className="h-5 w-5 mr-2 text-purple-600" />
              Modify Entity Fields
            </div>
          </DialogTitle>
          <DialogDescription>
            {currentEntity && (
              <span>{currentEntity.company_name} ({currentEntity.country_code}{currentEntity.vat_no})</span>
            )}
          </DialogDescription>
        </DialogHeader>
        
        {currentEntity && (
          <div className="space-y-4 py-2 text-left">
            <div className="flex flex-col space-y-1.5">
              <label className="text-sm font-medium">
                {currentField === "goods_services_manual" && "Goods/Services Manual"}
                {currentField === "taxability_manual" && "Taxability Manual"}
                {currentField === "pot_indicator_manual" && "Place of Taxation Indicator"}
                {currentField === "likely_right_deduct_vat_manual" && "Likely Right to Deduct VAT"}
              </label>
              
              {currentField === "goods_services_manual" && (
                <select 
                  className="w-full p-2 text-sm border rounded"
                  value={modifiedValues.goods_services_manual}
                  onChange={(e) => handleFieldValueChange("goods_services_manual", e.target.value)}
                >
                  <option value="">Select...</option>
                  {goodsServicesOptions.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              )}
              
              {currentField === "taxability_manual" && (
                <select 
                  className="w-full p-2 text-sm border rounded"
                  value={modifiedValues.taxability_manual}
                  onChange={(e) => handleFieldValueChange("taxability_manual", e.target.value)}
                >
                  <option value="">Select...</option>
                  {taxabilityOptions.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              )}
              
              {currentField === "pot_indicator_manual" && (
                <select 
                  className="w-full p-2 text-sm border rounded"
                  value={modifiedValues.pot_indicator_manual}
                  onChange={(e) => handleFieldValueChange("pot_indicator_manual", e.target.value)}
                >
                  <option value="">Select...</option>
                  {potOptions.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              )}
              
              {currentField === "likely_right_deduct_vat_manual" && (
                <select 
                  className="w-full p-2 text-sm border rounded"
                  value={modifiedValues.likely_right_deduct_vat_manual}
                  onChange={(e) => handleFieldValueChange("likely_right_deduct_vat_manual", e.target.value)}
                >
                  <option value="">Select...</option>
                  {likelyOptions.map(option => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              )}
              
              <div className="flex items-center justify-between mt-2">
                <div className="text-xs text-gray-500">
                  Current field: {currentField === "goods_services_manual" ? 1 : 
                                  currentField === "taxability_manual" ? 2 :
                                  currentField === "pot_indicator_manual" ? 3 : 4} of 4
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleSkipField}
                    className="h-7 text-xs"
                    disabled={currentField === "likely_right_deduct_vat_manual"}
                  >
                    Skip
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleNextField}
                    className="h-7 text-xs"
                    disabled={currentField === "likely_right_deduct_vat_manual"}
                  >
                    Change More
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col space-y-1.5">
              <label className="text-sm font-medium">
                Note <span className="text-red-500">*</span>
              </label>
              <Textarea
                className={`w-full text-xs min-h-[60px] ${modifyNote.trim().length > 0 ? 'border-green-400 focus-visible:ring-green-400' : 'border-gray-300'}`}
                rows={2}
                placeholder="Explain reason for changes"
                value={modifyNote}
                onChange={(e) => setModifyNote(e.target.value)}
              />
              {!modifyNote && (
                <p className="text-xs text-red-500">Note is required</p>
              )}
            </div>
          </div>
        )}
        
        <DialogFooter className="sm:justify-end">
          <Button
            type="button"
            variant="secondary"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="default"
            onClick={handleSendToReview}
            disabled={!modifyNote}
            className={!modifyNote ? 'opacity-50' : ''}
          >
            <Send className="h-4 w-4 mr-2" />
            Submit for Review
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

interface NoteDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  note: string;
  setNote: (note: string) => void;
  onSubmit: () => void;
  onSkip: () => void;
}

export const NoteDialog: React.FC<NoteDialogProps> = ({
  isOpen,
  onOpenChange,
  note,
  setNote,
  onSubmit,
  onSkip
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            <div className="flex items-center">
              <FileText className="h-5 w-5 mr-2 text-purple-600" />
              Add a Note
            </div>
          </DialogTitle>
          <DialogDescription>
            Please provide a note explaining why you made changes to this entity.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-2 text-left">
          <div className="relative">
            <Textarea
              className={`w-full min-h-[100px] ${note.trim().length > 0 ? 'border-green-400 focus-visible:ring-green-400' : 'border-gray-300'}`}
              placeholder="Enter your note explaining the changes..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
            {note.trim().length > 0 ? (
              <span className="absolute right-3 top-3 text-green-500">
                <CheckCircle className="h-4 w-4" />
              </span>
            ) : (
              <span className="absolute right-3 top-3 text-gray-400">
                <X className="h-4 w-4" />
              </span>
            )}
          </div>
        </div>
        
        <DialogFooter className="flex justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={onSkip}
            className="text-amber-700 border-amber-300 hover:bg-amber-50"
          >
            Skip Note
          </Button>
          <Button
            type="button"
            onClick={onSubmit}
            variant="default"
            className={`bg-purple-600 hover:bg-purple-700 ${!note.trim() ? 'opacity-50' : ''}`}
            disabled={!note.trim()}
          >
            <Send className="h-4 w-4 mr-2" />
            Submit for Review
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
