
import React from "react";
import { ArrowUp, ArrowDown } from "lucide-react";
import { EntityMetaData, SortConfigEMD } from "@/types/emd";
import { TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface EntityTableHeaderProps {
  onSort: (key: keyof EntityMetaData) => void;
  sortConfig: SortConfigEMD | null;
  onSelectEntity?: (entityId: string, isSelected: boolean) => void;
}

const EntityTableHeader: React.FC<EntityTableHeaderProps> = ({ 
  onSort, 
  sortConfig, 
  onSelectEntity 
}) => {
  const renderSortHeader = (label: string, key: keyof EntityMetaData) => {
    const isSorted = sortConfig?.key === key;
    
    return (
      <div className="flex items-center gap-1 cursor-pointer text-left text-xs" onClick={() => onSort(key)}>
        {label}
        {isSorted && (
          <span className="ml-1">
            {sortConfig.direction === 'ascending' 
              ? <ArrowUp size={14} className="text-gray-600" /> 
              : <ArrowDown size={14} className="text-gray-600" />
            }
          </span>
        )}
      </div>
    );
  };

  return (
    <TableHeader>
      <TableRow>
        {onSelectEntity && (
          <TableHead className="w-[40px] min-w-[40px]">
            <span className="sr-only">Select</span>
          </TableHead>
        )}
        <TableHead className="min-w-[80px]">
          <div className="text-left">
            {renderSortHeader("VAT Number", "vat_no")}
            <div className="text-xs text-gray-500 mt-1" style={{ fontSize: '10px' }}>Unique clients</div>
          </div>
        </TableHead>
        <TableHead className="min-w-[160px]">
          <div className="text-left">
            {renderSortHeader("Company", "company_name")}
            <div className="text-xs text-gray-500 mt-1" style={{ fontSize: '10px' }}>Country code</div>
          </div>
        </TableHead>
        <TableHead className="w-[70px] min-w-[70px]">
          <div className="text-left">
            <div className="text-xs">GS_man</div>
            <div className="text-xs text-gray-500 mt-1" style={{ fontSize: '10px' }}>GS_pre</div>
          </div>
        </TableHead>
        <TableHead className="w-[70px] min-w-[70px]">
          <div className="text-left">
            <div className="text-xs">Tax_man</div>
            <div className="text-xs text-gray-500 mt-1" style={{ fontSize: '10px' }}>Tax_pre</div>
          </div>
        </TableHead>
        <TableHead className="w-[70px] min-w-[70px]">
          <div className="text-left">
            <div className="text-xs">POT_man</div>
            <div className="text-xs text-gray-500 mt-1" style={{ fontSize: '10px' }}>POT_pre</div>
          </div>
        </TableHead>
        <TableHead className="w-[70px] min-w-[70px]">
          <div className="text-left">
            <div className="text-xs">Likely_man</div>
            <div className="text-xs text-gray-500 mt-1" style={{ fontSize: '10px' }}>Likely_pre</div>
          </div>
        </TableHead>
        <TableHead className="min-w-[120px]">
          <div className="text-left">
            {renderSortHeader("Updated", "timestamp")}
            <div className="text-xs text-gray-500 mt-1" style={{ fontSize: '10px' }}>Notes</div>
          </div>
        </TableHead>
        <TableHead className="w-[100px]">
          <span className="sr-only">Actions</span>
        </TableHead>
      </TableRow>
    </TableHeader>
  );
};

export default EntityTableHeader;
