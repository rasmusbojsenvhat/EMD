
import React from "react";
import { Clock } from "lucide-react";
import { EntityMetaData } from "@/types/emd";
import { TableCell, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import FieldCell from "./FieldCell";
import ActionButtons from "./ActionButtons";
import { formatDate, hasManualInput, goodsServicesOptions, taxabilityOptions, potOptions, likelyOptions } from "./utils";

interface EntityTableRowProps {
  entity: EntityMetaData;
  onSelectEntity?: (entityId: string, isSelected: boolean) => void;
  selectedEntities?: string[];
  onResetEntity?: (entityId: string) => void;
  showResetOption?: boolean;
  handleFieldUpdate: (entity: EntityMetaData, field: keyof EntityMetaData, value: string, note: string) => void;
  onSendToReview?: (entity: EntityMetaData) => void;
}

const EntityTableRow: React.FC<EntityTableRowProps> = ({
  entity,
  selectedEntities = [],
  onSelectEntity,
  onResetEntity,
  showResetOption = false,
  handleFieldUpdate,
  onSendToReview
}) => {
  const hasChanges = hasManualInput(entity);
  
  return (
    <TableRow 
      key={entity.id}
      className={entity.pendingReview ? 'bg-amber-50 hover:bg-amber-100' : ''}
    >
      {onSelectEntity && (
        <TableCell className="p-2 align-top text-center">
          <Checkbox 
            checked={selectedEntities.includes(entity.id)}
            onCheckedChange={(checked) => {
              onSelectEntity(entity.id, checked === true);
            }}
            className="mt-1"
          />
        </TableCell>
      )}
      <TableCell className="align-top">
        <div className="font-medium text-left text-xs">{entity.country_code}{entity.vat_no}</div>
        <div className="text-xs text-gray-500 text-left" style={{ fontSize: '10px' }}>{entity.unique_clients || "-"}</div>
      </TableCell>
      <TableCell className="align-top">
        <div className="font-medium text-left text-xs">{entity.company_name}</div>
        <div className="text-xs text-gray-500 text-left" style={{ fontSize: '10px' }}>{entity.country_code}</div>
      </TableCell>
      
      {/* Goods/Services Field */}
      <TableCell className="align-top w-[70px] min-w-[70px]">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="w-full">
                <FieldCell 
                  entity={entity} 
                  field="goods_services_manual" 
                  dropdownOptions={goodsServicesOptions}
                  onValueChange={(value, note) => 
                    handleFieldUpdate(entity, "goods_services_manual", value, note)
                  }
                />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Goods/Services Manual Classification</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <div className="text-xs text-gray-500 mt-1 italic text-left truncate" style={{ fontSize: '10px' }}>
          {entity.goods_services_prediction || "-"}
        </div>
      </TableCell>
      
      {/* Taxability Field */}
      <TableCell className="align-top w-[70px] min-w-[70px]">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="w-full">
                <FieldCell 
                  entity={entity} 
                  field="taxability_manual" 
                  dropdownOptions={taxabilityOptions}
                  onValueChange={(value, note) => 
                    handleFieldUpdate(entity, "taxability_manual", value, note)
                  }
                />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Taxability Manual Classification</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <div className="text-xs text-gray-500 mt-1 italic text-left truncate" style={{ fontSize: '10px' }}>
          {entity.taxability_prediction || "-"}
        </div>
      </TableCell>
      
      {/* POT Indicator Field */}
      <TableCell className="align-top w-[70px] min-w-[70px]">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="w-full">
                <FieldCell 
                  entity={entity} 
                  field="pot_indicator_manual" 
                  dropdownOptions={potOptions}
                  onValueChange={(value, note) => 
                    handleFieldUpdate(entity, "pot_indicator_manual", value, note)
                  }
                />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Place of Taxation Indicator Manual</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <div className="text-xs text-gray-500 mt-1 italic text-left truncate" style={{ fontSize: '10px' }}>
          {entity.pot_indicator_prediction || "-"}
        </div>
      </TableCell>
      
      {/* Likely Right Deduct VAT Field */}
      <TableCell className="align-top w-[70px] min-w-[70px]">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="w-full">
                <FieldCell 
                  entity={entity} 
                  field="likely_right_deduct_vat_manual" 
                  dropdownOptions={likelyOptions}
                  onValueChange={(value, note) => 
                    handleFieldUpdate(entity, "likely_right_deduct_vat_manual", value, note)
                  }
                />
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Likely Right to Deduct VAT Manual</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <div className="text-xs text-gray-500 mt-1 italic text-left truncate" style={{ fontSize: '10px' }}>
          {entity.likely_right_deduct_vat_prediction || "-"}
        </div>
      </TableCell>
      
      {/* Timestamp and Note Field */}
      <TableCell className="align-top">
        <div className="text-xs text-left">
          {formatDate(entity.timestamp)}
        </div>
        <div className="text-xs text-gray-500 truncate max-w-[180px] text-left" style={{ fontSize: '10px' }} title={entity.note || ""}>
          {entity.note || "-"}
        </div>
        {entity.pendingReview && (
          <div className="mt-1 inline-flex items-center px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-xs">
            <Clock size={12} className="mr-1" />
            Pending Review
          </div>
        )}
      </TableCell>
      
      {/* Action Buttons */}
      <TableCell className="align-top">
        <ActionButtons
          entity={entity}
          hasChanges={hasChanges}
          showResetOption={showResetOption}
          pendingReview={!!entity.pendingReview}
          hasNote={!!entity.note}
          onSendToReview={onSendToReview}
          onResetEntity={onResetEntity}
        />
      </TableCell>
    </TableRow>
  );
};

export default EntityTableRow;
