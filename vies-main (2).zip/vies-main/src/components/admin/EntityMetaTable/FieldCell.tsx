
import React, { useState } from "react";
import { X, CheckCircle, Send } from "lucide-react";
import { EntityMetaData } from "@/types/emd";
import { useToast } from "@/hooks/use-toast";

import { 
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface FieldCellProps {
  entity: EntityMetaData;
  field: keyof EntityMetaData;
  type?: "manual" | "prediction";
  dropdownOptions?: string[];
  onValueChange?: (value: string, note: string) => void;
}

const FieldCell: React.FC<FieldCellProps> = ({ 
  entity, 
  field, 
  type = "manual",
  dropdownOptions = [],
  onValueChange
}) => {
  const { toast } = useToast();
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [newValue, setNewValue] = useState<string>((entity[field] as string) || "");
  const [note, setNote] = useState<string>(entity.note || "");
  const [isNoteDialogOpen, setIsNoteDialogOpen] = useState(false);
  
  const isReadOnly = type === "prediction";
  const value = (entity[field] as string) || "";
  const hasChanged = value !== "" && value !== (entity[`${field.toString().replace('_manual', '')}_prediction`] as string || "");
  
  const handleValueChange = (selectedValue: string) => {
    if (onValueChange && selectedValue !== value) {
      setNewValue(selectedValue);
      // Apply the value immediately with a default note instead of showing the dialog
      onValueChange(selectedValue, "Update from dropdown");
    }
    setIsPopoverOpen(false);
  };
  
  return (
    <>
      <div 
        className={`flex items-center justify-between w-full group cursor-pointer p-1 rounded hover:bg-gray-50 ${hasChanged ? 'bg-purple-50' : ''}`}
        onClick={() => !isReadOnly && setIsPopoverOpen(true)}
      >
        <HoverCard>
          <HoverCardTrigger asChild>
            <span className={`${type === 'prediction' ? 'text-gray-500 italic' : ''} text-left text-xs truncate max-w-[90%] ${hasChanged ? 'text-purple-700 font-medium' : ''}`}>
              {value || <span className="text-gray-300">-</span>}
            </span>
          </HoverCardTrigger>
          {value && (
            <HoverCardContent className="w-auto max-w-[300px] p-2">
              <p className="text-xs">{value}</p>
            </HoverCardContent>
          )}
        </HoverCard>
      </div>

      {!isReadOnly && (
        <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
          <PopoverTrigger asChild>
            <div className="sr-only">Select {field}</div>
          </PopoverTrigger>
          <PopoverContent className="w-56 p-2" align="start">
            <div className="space-y-2">
              <div className="text-sm font-medium mb-1">Select {field.toString().replace(/_/g, ' ')}</div>
              <Select
                value={newValue}
                onValueChange={handleValueChange}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value=" ">Clear selection</SelectItem>
                  {dropdownOptions.map(option => (
                    <SelectItem key={option} value={option}>{option}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </PopoverContent>
        </Popover>
      )}
    </>
  );
};

export default FieldCell;
