
import { EntityMetaData } from "@/types/emd";
import { format, isValid } from "date-fns";

export const hasManualInput = (entity: EntityMetaData): boolean => {
  return !!(
    entity.goods_services_manual || 
    entity.taxability_manual || 
    entity.pot_indicator_manual || 
    entity.likely_right_deduct_vat_manual
  );
};

export const formatDate = (dateString: string): string => {
  if (!dateString) return "-";
  
  const date = new Date(dateString);
  if (isValid(date)) {
    return format(date, "dd/MM/yyyy");
  }
  
  if (/^\d{2}\.\d{2}\.\d{4}$/.test(dateString)) {
    return dateString.replace(/\./g, '/');
  }
  
  return dateString;
};

export const goodsServicesOptions = ["Goods", "Services", "Both"];

export const taxabilityOptions = ["T", "Ex_no_credit", "Ex_w_credit", "Local_RC", "UsedGoods"];

export const potOptions = [
  "Teleservice", "Broadcasting", "Copyrights_etc", "Advertisement", "Consultants",
  "Engineers", "Accountants", "Lawyers", "Data_processing", "Providing_information",
  "Financial_Services", "Staff_hire", "Leasing_movable_property_no_means_of_transport",
  "Transmission_Services", "Real_Estate", "Passenger_Transport", "Access_to_Events",
  "Restaurant_Catering", "Short_term_rent_means_of_transport", "Intermediary",
  "Goods_transport", "valuation, reparation  of movable property",
  "AccesstoEvents, i.e. activitites connected to events, also as facilitator etc",
  "long term rent not leisure_means_of_transport", "long term rent leisure_means_of_transport",
  "Electronic Services", "Activities connected to transport", "New_Means_of_Transport",
  "Manual", "Main Rule", "OSS"
];

export const likelyOptions = [
  "LeasingVehicles", "Restaurant", "MealsForStaff", "EstimatePhone", "EstimateEntertainment",
  "FixedPhoneLine", "CarRelatedExpenses", "NoDeductionEntertainment", "BusinessOrPrivateUse",
  "FullDeduction", "NoDeductionExempt", "NoDeductionFringeBenefits", "NoDeductionGifts"
];

export const sortEntities = (
  entities: EntityMetaData[],
  sortConfig: { key: keyof EntityMetaData; direction: 'ascending' | 'descending' } | null
): EntityMetaData[] => {
  if (!sortConfig) return entities;
  
  return [...entities].sort((a, b) => {
    if (sortConfig.key === 'unique_clients') {
      const aValue = parseInt(a[sortConfig.key] as string) || 0;
      const bValue = parseInt(b[sortConfig.key] as string) || 0;
      
      return sortConfig.direction === 'ascending'
        ? aValue - bValue
        : bValue - aValue;
    }
    
    const aValue = (a[sortConfig.key] as string) || '';
    const bValue = (b[sortConfig.key] as string) || '';
    
    if (sortConfig.direction === 'ascending') {
      return aValue.localeCompare(bValue);
    } else {
      return bValue.localeCompare(aValue);
    }
  });
};
